# Historical 94-output follow-up return

This is the original file returned on 28 October, preserved without edits. Use the parent folder's corrected provenance and primary review analyses for current interpretation. Howard had not seen automated judge scores before finalizing the historical ratings, as subsequently clarified by the corresponding author. Original date, reviewer and draft-status fields remain as received and do not override that correction. Do not treat this follow-up as 94 additional independent observations.
