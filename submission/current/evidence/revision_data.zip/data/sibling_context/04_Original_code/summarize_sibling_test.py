from pathlib import Path
import json,csv,re,random,hashlib,shutil
import numpy as np
R=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021');O=R/'outputs/sibling_context_answer_test_20261028';raw=[json.loads(x) for x in (O/'results_checkpoint.jsonl').read_text().splitlines()];results={x['call_id']:x for x in raw};assert len(results)==132 and all(x.get('judge') and not x['error'] for x in results.values())
contexts={x['id']:x for x in map(json.loads,(O/'selected_26_contexts.jsonl').read_text().splitlines())};membership=list(csv.DictReader((O/'condition_membership_156.csv').open()));rows=[]
def norm(x):return re.sub(r'\s+',' ',x).strip().lower()
for m in membership:
 x=results[m['call_id']];q=contexts[m['question_id']];cp=q['conditions'][m['condition']];labels={norm(c) for c,t in cp['context_pairs']};answer=x['answer'];brackets=re.findall(r'\[([^\[\]]+)\]',answer);citations=[c for c in brackets if re.search(r'\b(?:RDC|IN)\s*\d+/\d{4}',c,re.I)];refusal=bool(re.fullmatch(r'(?:The retrieved documents do not provide enough information to answer\.?|Os documentos recuperados n[aã]o fornecem informa[cç][aã]o suficiente para responder\.?)',answer.strip(),re.I));valid=sum(norm(c) in labels for c in citations)/len(citations) if citations else None
 rows.append({**m,'prompt_changed':q['prompt_changed'],'question':q['question'],'answer':answer,**{k:x['judge'][k] for k in ['faithfulness','citation_correctness','completeness','refusal_correctness']},'judge_rationale':x['judge'].get('rationale',''),'raw_refusal':refusal,'citation_present':bool(citations),'strict_citation_label_validity':valid,'language_flag':bool((q['language']=='pt' and re.match(r'^No\b',answer)) or (q['language']=='en' and re.match(r'^(?:N[aã]o|Os documentos recuperados)\b',answer))),'modelVersion':x['generation']['modelVersion'],'generation_raw':x['generation']['raw_file'],'judge_raw':x['judge_metadata']['raw_file']})
with (O/'all_condition_results_156.csv').open('w',newline='') as f:w=csv.DictWriter(f,rows[0]);w.writeheader();w.writerows(rows)
means=[]
for ident,q in contexts.items():
 a=[x for x in rows if x['question_id']==ident];d={'id':ident,'pair_id':q['pair_id'],'language':q['language'],'prompt_changed':q['prompt_changed']}
 for metric in ['completeness','faithfulness','citation_correctness','raw_refusal']:
  for cond in ['siblings_on','siblings_off']:d[metric+'_'+cond]=np.mean([float(x[metric]) for x in a if x['condition']==cond])
  d[metric+'_on_minus_off']=d[metric+'_siblings_on']-d[metric+'_siblings_off']
 means.append(d)
with (O/'question_means_26.csv').open('w',newline='') as f:w=csv.DictWriter(f,means[0]);w.writeheader();w.writerows(means)
summ=[]
for population in ['changed','unchanged','all']:
 for language in ['all','pt','en']:
  rr=[x for x in means if (population=='all' or x['prompt_changed']==(population=='changed')) and (language=='all' or x['language']==language)]
  if not rr:continue
  pairs=sorted({x['pair_id'] for x in rr})
  for metric in ['completeness','faithfulness','citation_correctness','raw_refusal']:
   diffs=np.array([np.mean([x[metric+'_on_minus_off'] for x in rr if x['pair_id']==p]) for p in pairs]);rng=np.random.default_rng(20261028);boot=diffs[rng.integers(0,len(diffs),size=(10000,len(diffs)))].mean(axis=1);lo,hi=np.quantile(boot,[.025,.975]);summ.append({'population':population,'language':language,'metric':metric,'n_questions':len(rr),'n_pairs':len(pairs),'equal_pair_weighted_on':np.mean([np.mean([x[metric+'_siblings_on'] for x in rr if x['pair_id']==p]) for p in pairs]),'equal_pair_weighted_off':np.mean([np.mean([x[metric+'_siblings_off'] for x in rr if x['pair_id']==p]) for p in pairs]),'on_minus_off':np.mean(diffs),'ci_low':lo,'ci_high':hi,'question_weighted_difference':np.mean([x[metric+'_on_minus_off'] for x in rr]),'improved_questions':sum(x[metric+'_on_minus_off']>0 for x in rr),'worsened_questions':sum(x[metric+'_on_minus_off']<0 for x in rr),'unchanged_questions':sum(x[metric+'_on_minus_off']==0 for x in rr)})
with (O/'paired_answer_summary.csv').open('w',newline='') as f:w=csv.DictWriter(f,summ[0]);w.writeheader();w.writerows(summ)
primary=next(x for x in summ if x['population']=='changed' and x['language']=='all' and x['metric']=='completeness')
# Reserve first-repeat answers for a human assessment with condition and scores concealed.
h=O/'HUMAN_REVIEW_FIRST_REPEAT';h.mkdir(exist_ok=True);ev=h/'selected_evidence';ev.mkdir(exist_ok=True);unique={x['call_id']:x for x in rows if int(x['repeat'])==1};assert len(unique)==44;items=list(unique.values());random.Random(20261029).shuffle(items);review=[];key=[]
for i,x in enumerate(items,1):
 rid=f'SIB_{i:03}';q=contexts[x['question_id']];cp=q['conditions'][x['condition']];(ev/(rid+'.txt')).write_text('\n\n'.join(f'[{c}]\n{t}' for c,t in cp['context_pairs'])+'\n');review.append({'review_id':rid,'language':q['language'],'question':q['question'],'answer':x['answer'],'evidence_file':'selected_evidence/'+rid+'.txt','selected_evidence_sufficiency':'','supported_information_complete':'','material_claims_supported':'','citations_support_claims':'','refusal_of_unavailable_detail_appropriate':'','language_compliant':'','rationale':'','reviewer':'','review_date':''});key.append({'review_id':rid,'call_id':x['call_id'],'question_id':x['question_id'],'condition':x['condition'],'repeat':1,'prompt_changed':x['prompt_changed']})
for p,rr in [(h/'Howard_sibling_first_repeat_UNRATED.csv',review),(O/'PRIVATE_human_review_mapping.csv',key)]:
 with p.open('w',newline='') as f:w=csv.DictWriter(f,rr[0]);w.writeheader();w.writerows(rr)
(h/'README.txt').write_text('UNRATED author-assessment pack.44unique first-repeat answers:36fromchanged-conditionarms and8unchanged counterpart answers. Condition and automated scores concealed; selected passages may permit inference. Assess exact selected evidence, completeness of supported information and justified refusal separately. Do not infer correct behavior from whole-corpus answerability alone. Do not change original Howard94ratings. This is author review,not independent validation. Original archived references have status/label limitations; flag uncertainty. Nothing has been sent.\n')
manifest={'status':'complete automated sibling diagnostic; human review pending','unique_generations':132,'unique_evaluations':132,'logical_condition_records':156,'changed_questions':18,'changed_pairs':13,'unchanged_counterpart_questions':8,'primary':primary,'score_provenance':'same-model automated,conditional on archived gold','human_review_pack_answers':44,'human_reviews_completed':0,'independent_validation_completed':False,'refusal_metric_limit':'Archived corpus-label refusal scores retained in raw results but not interpreted as safety given exact selected passages.','control_limit':'Identical-prompt arm responses are reused,not stochastic-noise controls.'};(O/'answer_test_summary.json').write_text(json.dumps(manifest,indent=2,default=lambda x:x.item())+'\n');shutil.copy2('/private/tmp/summarize_sibling_test.py',O/'summarize_sibling_test.py');print(json.dumps(manifest,indent=2,default=lambda x:x.item()))
