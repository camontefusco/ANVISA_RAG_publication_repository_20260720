from pathlib import Path
import json,csv,time,datetime,hashlib,threading,concurrent.futures,re,sys,shutil
import requests
from dotenv import dotenv_values
R=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021');O=R/'outputs/sibling_context_answer_test_20261028';RAW=O/'raw_calls';RAW.mkdir(exist_ok=True);MODEL='gemini-3.5-flash-lite'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();protocol=json.loads((O/'protocol_before_calls.json').read_text());scope=json.loads((O/'approval_scope.json').read_text());assert sha(O/'protocol_before_calls.json')==scope['protocol_sha256'];assert all(sha(O/n)==h for n,h in protocol['payload_hashes'].items())
auth={'date':now(),'user_reply':'Authorize this sibling-context test','scope':scope,'protocol_sha256':scope['protocol_sha256']};(O/'human_authorization.json').write_text(json.dumps(auth,indent=2)+'\n');shutil.copy2('/private/tmp/run_sibling_approved.py',O/'executed_run_sibling_approved.py')
KEY=dotenv_values('/Users/cmontefusco/projects/Codex/2026-06-16/files-mentioned-by-the-user-rag/Rag_project/.env').get('GOOGLE_API_KEY','');assert KEY,'Missing local credential'
inputs={x['input_id']:x for x in map(json.loads,(O/'generation_inputs_44.jsonl').read_text().splitlines())};templates={x['input_id']:x for x in map(json.loads,(O/'judge_templates_44.jsonl').read_text().splitlines())};plan=list(csv.DictReader((O/'execution_plan_132.csv').open()));LOCK=threading.Lock();RATE=threading.Lock();STOP=threading.Event();NEXT=[0.0];endpoint=f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent'
def pace():
 with RATE:
  delay=max(0,NEXT[0]-time.monotonic())
  if delay:time.sleep(delay)
  NEXT[0]=time.monotonic()+4.3

def call(prompt,temp,stem):
 digest=hashlib.sha256(prompt.encode()).hexdigest();previous=sorted(RAW.glob(stem+'_attempt*.json'))
 for p in previous:
  x=json.loads(p.read_text());assert x['prompt_sha256']==digest
  if x.get('http_status')==200 and x.get('answer') and x.get('modelVersion')==MODEL:return x['answer'],{'raw_file':str(p.relative_to(O)),'modelVersion':x['modelVersion'],'prompt_sha256':digest,'responseId':x.get('responseId'),'reused':True}
 for attempt in range(len(previous)+1,4):
  if STOP.is_set():raise RuntimeError('run_stopped')
  pace();p=RAW/(stem+f'_attempt{attempt}.json');record={'call_id':stem,'attempt':attempt,'started_utc':now(),'prompt_sha256':digest,'temperature':temp}
  try:
   response=requests.post(endpoint,headers={'x-goog-api-key':KEY,'Content-Type':'application/json'},json={'contents':[{'role':'user','parts':[{'text':prompt}]}],'generationConfig':{'temperature':temp}},timeout=120)
   record['http_status']=response.status_code
   try:raw=response.json()
   except ValueError:raw={'non_json_response':response.text[:1000]}
   record['response']=raw;record['finished_utc']=now()
   if response.status_code==200:
    answer=''.join(y.get('text','') for c in raw.get('candidates',[])[:1] for y in c.get('content',{}).get('parts',[]) if not y.get('thought'));record.update(answer=answer,modelVersion=raw.get('modelVersion'),responseId=raw.get('responseId'));p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    if raw.get('modelVersion')!=MODEL:STOP.set();raise RuntimeError('model_version_mismatch')
    if not answer:raise RuntimeError('empty_generation')
    return answer,{'raw_file':str(p.relative_to(O)),'modelVersion':raw.get('modelVersion'),'prompt_sha256':digest,'responseId':raw.get('responseId'),'reused':False}
   p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');err=raw.get('error',{});daily=any('perday' in str(v.get('quotaId','')).lower() for d in err.get('details',[]) for v in d.get('violations',[]))
   if daily:STOP.set();raise RuntimeError('daily_quota_exhausted')
   if response.status_code in [400,401,403,404]:STOP.set();raise RuntimeError('non_retryable_http_'+str(response.status_code))
   if response.status_code not in [429,500,502,503,504]:raise RuntimeError('unexpected_http_'+str(response.status_code))
   for d in err.get('details',[]):
    if d.get('@type','').endswith('RetryInfo'):
     delay=float(re.sub('[^0-9.]','',d.get('retryDelay','0s')) or 0)
     with RATE:NEXT[0]=max(NEXT[0],time.monotonic()+delay+1)
  except requests.RequestException as e:
   record.update(finished_utc=now(),error_type=type(e).__name__);p.write_text(json.dumps(record,indent=2)+'\n')
  if attempt<3:time.sleep(min(15,5*attempt))
 raise RuntimeError('attempts_exhausted')

def task(t):
 stem=t['call_id'];inp=inputs[t['input_id']];out={'call_id':stem,'input_id':t['input_id'],'repeat':int(t['repeat']),'question_id':inp['question_id'],'pair_id':inp['pair_id'],'language':inp['language'],'error':''}
 try:
  answer,meta=call(inp['prompt'],.2,stem+'_generation');out.update(answer=answer,generation=meta);jp=templates[t['input_id']]['judge_prompt_template'].replace('__GENERATED_ANSWER__',answer);judgetext,jmeta=call(jp,0,stem+'_judge');out.update(judge_text=judgetext,judge_metadata=jmeta);clean=re.sub(r'^```(?:json)?\s*|\s*```$','',judgetext.strip());judge=json.loads(clean)
  for k in ['faithfulness','citation_correctness','completeness','refusal_correctness']:assert isinstance(judge[k],(int,float)) and not isinstance(judge[k],bool) and 0<=judge[k]<=1
  out['judge']=judge
 except Exception as e:out['error']=str(e) if isinstance(e,(RuntimeError,AssertionError,json.JSONDecodeError)) else type(e).__name__
 with LOCK:
  with (O/'results_checkpoint.jsonl').open('a') as f:f.write(json.dumps(out,ensure_ascii=False)+'\n')
  current={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())};complete=sum(bool(x.get('judge')) and not x['error'] for x in current.values());(O/'run_status.json').write_text(json.dumps({'status':'stopped' if STOP.is_set() else 'running','updated_utc':now(),'complete_unique_answers_and_scores':complete,'total_unique_calls':132,'saved_results':len(current),'stop_trigger':out['error'] if STOP.is_set() else None},indent=2)+'\n');print('saved',stem,'complete',complete,'error',out['error'],flush=True)
 return out
existing={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())} if (O/'results_checkpoint.jsonl').exists() else {};todo=[t for t in plan if not (existing.get(t['call_id'],{}).get('judge') and not existing[t['call_id']]['error'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 iterator=iter(todo);pending={}
 for _ in range(4):
  t=next(iterator,None)
  if t:pending[ex.submit(task,t)]=t
 while pending:
  done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
  for f in done:
   pending.pop(f);f.result()
   if not STOP.is_set():
    t=next(iterator,None)
    if t:pending[ex.submit(task,t)]=t
current={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())};complete=sum(bool(x.get('judge')) and not x['error'] for x in current.values());status={'status':'complete' if complete==132 else 'blocked' if STOP.is_set() else 'incomplete','updated_utc':now(),'complete_unique_answers_and_scores':complete,'total_unique_calls':132,'saved_results':len(current),'new_external_scope':'132generations+132judges,max3attemptseach,no repairs','errors':{k:x['error'] for k,x in current.items() if x['error']}};(O/'run_status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
