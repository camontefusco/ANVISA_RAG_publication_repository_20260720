from pathlib import Path
import json,csv,re,shutil
import numpy as np
R=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021');O=R/'outputs/sibling_context_answer_test_20261028';contexts=[json.loads(x) for x in (O/'selected_26_contexts.jsonl').read_text().splitlines()];bad55={9,15,18,27,30,43,46,49};screen=[]
for x in contexts:
 reasons=[]
 for c in x['gold_citations']:
  if 'RDC 9/2015' in c:reasons.append('archived gold cites revoked RDC9/2015')
  m=re.search(r'RDC 55/2010, Art\. (\d+)',c)
  if m and int(m.group(1)) in bad55:reasons.append('archived gold cites known wholly revoked RDC55article '+m.group(1))
 screen.append({'id':x['id'],'pair_id':x['pair_id'],'prompt_changed':x['prompt_changed'],'flagged_gold':bool(reasons),'reason':'; '.join(reasons),'gold_citations':';'.join(x['gold_citations'])})
with (O/'known_revoked_gold_screen_26.csv').open('w',newline='') as f:w=csv.DictWriter(f,screen[0]);w.writeheader();w.writerows(screen)
exclude={x['pair_id'] for x in screen if x['flagged_gold']};rr=[x for x in csv.DictReader((O/'question_means_26.csv').open()) if x['prompt_changed']=='True' and x['pair_id'] not in exclude];pairs=sorted({x['pair_id'] for x in rr});diffs=np.array([np.mean([float(x['completeness_on_minus_off']) for x in rr if x['pair_id']==p]) for p in pairs]);rng=np.random.default_rng(20261028);boot=diffs[rng.integers(0,len(diffs),size=(10000,len(diffs)))].mean(axis=1);lo,hi=np.quantile(boot,[.025,.975]);out={'label':'Post hoc known-revoked-gold exclusion sensitivity; primary unchanged','excluded_pairs':sorted(exclude),'remaining_changed_questions':len(rr),'remaining_pairs':len(pairs),'equal_pair_weighted_off':float(np.mean([np.mean([float(x['completeness_siblings_off']) for x in rr if x['pair_id']==p]) for p in pairs])),'equal_pair_weighted_on':float(np.mean([np.mean([float(x['completeness_siblings_on']) for x in rr if x['pair_id']==p]) for p in pairs])),'on_minus_off':float(diffs.mean()),'ci_low':float(lo),'ci_high':float(hi),'limits':'Not prespecified;screen only previously documented revoked gold,not fullsource/currentlaw verification. Remaining references are not certified valid. Development questions and same-model judging remain.'};(O/'known_revoked_gold_sensitivity.json').write_text(json.dumps(out,indent=2)+'\n');shutil.copy2('/private/tmp/sibling_source_sensitivity.py',O/'sibling_source_sensitivity.py');print(json.dumps(out,indent=2))
