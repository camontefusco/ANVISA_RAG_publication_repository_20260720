# Sibling-context experiment

Start with the existing all_condition_results_156.csv and paired_answer_summary.csv. There are 156 logical condition records from 132 distinct generated answers/evaluations; identical-prompt counterparts were reused. Do not count the 156 logical records as independent generation calls.

01_Frozen_inputs adds the protocol, questions/contexts, model inputs, judge templates, execution plan and condition membership. 03_Human_review contains Howard's original 44-row first-repeat return, the public analytical condition join, and cohort-specific current provenance. That review is AI-draft-assisted unblinded coauthor review, distinct from the historical 94-output review. The original confirmation is retained as historical evidence; its wording must be interpreted with the cohort-specific correction described in CURRENT_REVIEW_PROVENANCE.json. 04_Original_code preserves the original scripts, which retain historical paths and are not portable entry points.

Historical summary JSON fields stating human review was pending describe creation-time status. The completed 44-row return and current provenance document its later approval. Do not add the 44 first-repeat reviews to the 156 automated records as additional generated answers.
