from pathlib import Path
import json,csv,collections,random,zipfile
import numpy as np
R=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021');O=R/'outputs/DR11_answer_results_20261025';rows=list(map(json.loads,(O/'answer_results.jsonl').read_text().splitlines()));expected={(x['question_id'],x['condition'],int(x['repeat'])) for x in csv.DictReader((O/'execution_plan_300.csv').open())};assert {(x['id'],x['condition'],x['repeat']) for x in rows}==expected and len(rows)==300
if any(x['error'] for x in rows):raise RuntimeError('Unresolved errors: cannot present complete pilot')
def write(name,records):
 with (O/name).open('w') as f:w=csv.DictWriter(f,records[0]);w.writeheader();w.writerows(records)
http=collections.Counter();versions=collections.Counter();kinds=collections.Counter();times=[];usage=collections.Counter()
for p in (O/'raw_calls').glob('*.json'):
 r=json.loads(p.read_text());http[str(r.get('http_status',r.get('error_type','unknown')))]+=1
 if r.get('http_status')==200:
  versions[r['response'].get('modelVersion','missing')]+=1;kinds['generation' if '_generation_' in p.name else 'judge' if '_judge_' in p.name else 'repair']+=1;times.append((r['started_utc'],r['finished_utc']))
  for k,v in r['response'].get('usageMetadata',{}).items():
   if isinstance(v,(int,float)):usage[k]+=v
assert set(versions)=={'gemini-3.5-flash-lite'}
metrics=['completeness','faithfulness','citation_correctness','refusal_correctness','strict_retrieved_citation_validity','refusal_detected'];qrows=[]
for id in sorted({r['id'] for r in rows}):
 rr=[r for r in rows if r['id']==id];q={k:rr[0][k] for k in ['id','pair_id','language','stratum','context_changed']}
 for c in ['prefix512','fullcoverage']:
  rs=[r for r in rr if r['condition']==c];assert {r['repeat'] for r in rs}=={1,2,3}
  for m in metrics:q[c+'_'+m]=float(np.mean([float(r['judge'][m] if m in r['judge'] else r[m]) for r in rs]))
  q[c+'_unique_answer_hashes']=len({r['answer_sha256'] for r in rs});q[c+'_repairs']=sum('repair' in r['calls'] for r in rs)
 for m in metrics:q['delta_'+m]=q['fullcoverage_'+m]-q['prefix512_'+m]
 qrows.append(q)
write('question_mean_results_50.csv',qrows);rng=np.random.default_rng(20261025);summ=[]
for group in ['affected_gold','control','all','context_changed','context_identical','affected_changed','affected_identical']:
 ss=[r for r in qrows if group=='all' or r['stratum']==group or group=='context_changed' and r['context_changed'] or group=='context_identical' and not r['context_changed'] or group=='affected_changed' and r['stratum']=='affected_gold' and r['context_changed'] or group=='affected_identical' and r['stratum']=='affected_gold' and not r['context_changed']];pairs=sorted({r['pair_id'] for r in ss});counts=np.array([sum(r['pair_id']==p for r in ss) for p in pairs]);ix=rng.integers(0,len(pairs),size=(10000,len(pairs)))
 for m in metrics:
  sums=np.array([sum(r['delta_'+m] for r in ss if r['pair_id']==p) for p in pairs]);boot=sums[ix].sum(1)/counts[ix].sum(1);ds=np.array([r['delta_'+m] for r in ss]);summ.append({'group':group,'metric':m,'n_questions':len(ss),'n_pairs':len(pairs),'n_outputs_per_condition':len(ss)*3,'prefix512_mean':float(np.mean([r['prefix512_'+m] for r in ss])),'fullcoverage_mean':float(np.mean([r['fullcoverage_'+m] for r in ss])),'difference':float(ds.mean()),'ci_low':float(np.quantile(boot,.025)),'ci_high':float(np.quantile(boot,.975)),'improved_question_means':int((ds>1e-9).sum()),'worsened_question_means':int((ds< -1e-9).sum()),'unchanged_question_means':int((abs(ds)<=1e-9).sum())})
write('paired_answer_summary.csv',summ);counts=[]
for group in ['affected_gold','control','all','context_changed','context_identical']:
 ss=[r for r in rows if group=='all' or r['stratum']==group or group=='context_changed' and r['context_changed'] or group=='context_identical' and not r['context_changed']]
 for c in ['prefix512','fullcoverage']:
  rr=[r for r in ss if r['condition']==c];non=[r for r in rr if not r['refusal_detected']];counts.append({'group':group,'condition':c,'n_outputs':len(rr),'refusals':sum(r['refusal_detected'] for r in rr),'non_refusals':len(non),'perfect_strict_validity_nonrefusals':sum(r['strict_retrieved_citation_validity']==1 for r in non),'mean_strict_validity_nonrefusals':float(np.mean([r['strict_retrieved_citation_validity'] for r in non])) if non else None,'citation_repair_calls':sum('repair' in r['calls'] for r in rr),'wrapper_fallback_refusals':sum(bool(r.get('wrapper_fallback_refusal')) for r in rr),'judge_completeness_below_one':sum(r['judge']['completeness']<1 for r in rr)})
write('answer_counts.csv',counts);neg=[]
for r in rows:
 flags=[]
 if r['refusal_detected']:flags.append('refusal_on_archived_answerable_row')
 if any(r['judge'][m]<1 for m in ['completeness','faithfulness','citation_correctness']):flags.append('automatic_score_below_one')
 if not r['refusal_detected'] and r['strict_retrieved_citation_validity']<1:flags.append('strict_citation_failure')
 if r['judge']['citation_correctness']==1 and not r['refusal_detected'] and r['strict_retrieved_citation_validity']<1:flags.append('judge_perfect_citation_despite_strict_failure')
 if flags:neg.append({**{k:r[k] for k in ['id','pair_id','condition','repeat','stratum','context_changed']},'flags':'; '.join(flags),'completeness':r['judge']['completeness'],'faithfulness':r['judge']['faithfulness'],'citation_correctness':r['judge']['citation_correctness'],'strict_retrieved_citation_validity':r['strict_retrieved_citation_validity'],'human_status':'not_reviewed'})
if neg:write('negative_and_disputed_outputs.csv',neg)
primary=next(r for r in summ if r['group']=='affected_gold' and r['metric']=='completeness');control=next(r for r in summ if r['group']=='control' and r['metric']=='completeness');report={'date':'2026-10-25','status':'complete','question_count':50,'pairs':25,'output_count':300,'repeats_per_condition':3,'primary_endpoint':primary,'control_completeness':control,'successful_calls_by_kind':dict(kinds),'http_attempt_counts':dict(http),'resolved_versions_all_successful_calls':dict(versions),'usage_all_successful_calls':dict(usage),'first_successful_call_utc':min(a for a,b in times),'last_successful_call_utc':max(b for a,b in times),'unresolved_output_errors':0,'negative_or_disputed_outputs':len(neg),'human_ratings_completed':0,'limits':'Enriched retrospective pilot;40/50prompts identical; same-model automated judge; archived gold/source validity concerns. Intervals resample bilingual pairs after averaging three observed repeats, conditional on calls/gold/judge. No multiplicity correction or independent human validation. No deployed setting changed.'};(O/'answer_effect_summary.json').write_text(json.dumps(report,indent=2))
# Blank human review packet, conditions and automatic scores masked; original Howard94 pack untouched.
review=O/'human_review_unrated';review.mkdir(exist_ok=True);shuffled=list(rows);random.Random(20261026).shuffle(shuffled);blind=[];mapping=[];ev=[];contexts={r['id']:r for r in map(json.loads,(O/'frozen_contexts.jsonl').read_text().splitlines())}
for i,r in enumerate(shuffled,1):
 code='D11_'+str(i).zfill(3);blind.append({'review_id':code,'language':r['language'],'question':r['question'],'answer':r['answer'],'evidence_record':code,'faithfulness_0_to_1':'','citation_correctness_0_to_1':'','completeness_0_to_1':'','refusal_assessment':'','source_status_concern':'','comments':'','reviewer':'','date':''});mapping.append({'review_id':code,'id':r['id'],'condition':r['condition'],'repeat':r['repeat']});ev.append({'review_id':code,'retrieved_contexts':contexts[r['id']]['conditions'][r['condition']]['retrieved_contexts'],'archived_reference_answer':r['expected_answer'],'reference_status':'not_human_revalidated; assess evidence and flag source/reference problems'})
with (review/'blank_ratings_300.csv').open('w') as f:w=csv.DictWriter(f,blind[0]);w.writeheader();w.writerows(blind)
write('human_review_private_unblinding_map.csv',mapping);(review/'evidence_300.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in ev));(review/'README.txt').write_text('All human ratings are blank. Conditions, repeat numbers and automated scores are masked. Assess against supplied evidence and flag uncertain archived reference/source validity; this is not current-law validation. Original Howard94-output pack is separate and unchanged. This additional packet has not been sent.\n')
with zipfile.ZipFile(O/'DR11_blinded_human_review_UNRATED.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in review.iterdir():z.write(p,p.name)
print(json.dumps(report,indent=2))
