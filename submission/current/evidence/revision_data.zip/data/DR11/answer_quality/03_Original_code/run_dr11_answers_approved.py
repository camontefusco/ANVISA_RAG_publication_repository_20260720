from pathlib import Path
import json,csv,time,datetime,hashlib,threading,concurrent.futures,ast,re,unicodedata,shutil,sys
import requests
from dotenv import dotenv_values
ROOT=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720');R=ROOT/'revisions/reviewer_2_20261021';P=R/'outputs/DR11_answer_effect_20261025';O=R/'outputs/DR11_answer_results_20261025';O.mkdir(exist_ok=True);RAW=O/'raw_calls';RAW.mkdir(exist_ok=True)
MODEL='gemini-3.5-flash-lite';KEY=dotenv_values('/Users/cmontefusco/projects/Codex/2026-06-16/files-mentioned-by-the-user-rag/Rag_project/.env').get('GOOGLE_API_KEY','');LOCK=threading.Lock();STOP=threading.Event();RATELOCK=threading.Lock();NEXT_SEND=[0.0]
def pace():
 with RATELOCK:
  wait=max(0,NEXT_SEND[0]-time.monotonic())
  if wait:time.sleep(wait)
  NEXT_SEND[0]=time.monotonic()+4.3
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
plan=list(csv.DictReader((P/'execution_plan_300.csv').open()));inputs={x['input_id']:x for x in map(json.loads,(P/'generation_inputs_100.jsonl').read_text().splitlines())};templates={x['input_id']:x for x in map(json.loads,(P/'judge_templates_100.jsonl').read_text().splitlines())};contexts={x['id']:x for x in map(json.loads,(P/'frozen_contexts.jsonl').read_text().splitlines())}
assert len(plan)==300 and len(contexts)==50 and len(inputs)==len(templates)==100
for x in inputs.values():assert hashlib.sha256(x['prompt'].encode()).hexdigest()==x['prompt_sha256']
(O/'operational_rate_limit_amendment.json').write_text(json.dumps({'date':'2026-10-25','reason':'Google free-tier15requests/minute produced429 failures in initial parallel batch; run stopped, successful raw calls preserved and reused','shared_request_spacing_seconds':4.3,'retry_change':'At most8totalHTTPattempts per logical call including the initial failed attempts; no additional statistical replicates or settings changed','api_prompt_scope':'Same user-approved fixed50question payload and300answer/300judge plan; no extra benchmark inputs'},indent=2))
(O/'human_authorization.json').write_text(json.dumps({'date':'2026-10-25','user_message':'approved','authorized_scope':json.loads((P/'approval_scope.json').read_text()),'interpretation':'Direct user approval of sending the prepared fifty-question pilot and references/contexts to Google for300 answer generations and300 automated evaluations, including conditional citation repair and bounded retries.'},indent=2))
for name in ['execution_plan_300.csv','generation_inputs_100.jsonl','judge_templates_100.jsonl','frozen_contexts.jsonl','selected_questions.jsonl','protocol_before_answers.json','final_context_comparison_50.csv','reranker_summary.json']:shutil.copy2(P/name,O/name)
shutil.copy2('/private/tmp/run_dr11_answers_approved.py',O/'run_dr11_answers_approved.py')
module=ast.parse((ROOT/'src/model_loader.py').read_text());ns={'re':re,'unicodedata':unicodedata};defs=[x for x in module.body if isinstance(x,ast.FunctionDef) and x.name in ['_is_grounding_refusal','_allows_preamble_only']];exec(compile(ast.Module(body=defs,type_ignores=[]),'wrapper_helpers','exec'),ns)
jmod=ast.parse((ROOT/'evaluation/answer_quality.py').read_text());jns={'re':re};body=[x for x in jmod.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['CITATION_RE','BRACKET_RE'] for t in x.targets)]+[x for x in jmod.body if isinstance(x,ast.FunctionDef) and x.name in ['extract_citations','normalize_citation','citation_validity']];exec(compile(ast.Module(body=body,type_ignores=[]),'citation_metric','exec'),jns)
pmodule=ast.parse((ROOT/'evaluation/publication_eval.py').read_text());parts=[x for x in pmodule.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REFUSAL_PATTERNS' for t in x.targets)]+[x for x in pmodule.body if isinstance(x,ast.FunctionDef) and x.name in ['normalize_text','detect_refusal']];exec(compile(ast.Module(body=parts,type_ignores=[]),'refusal_metric','exec'),ns)
def output_text(raw):return ''.join(p.get('text','') for c in raw.get('candidates',[])[:1] for p in c.get('content',{}).get('parts',[]) if not p.get('thought'))
def call(prompt,temp,stem):
 # Reuse a previously successful exact-prompt call when resuming an interrupted task.
 ph=hashlib.sha256(prompt.encode()).hexdigest()
 for existing in sorted(RAW.glob(stem+'_attempt*.json')):
  r=json.loads(existing.read_text())
  if r.get('http_status')==200 and r.get('prompt_sha256')==ph and r.get('response',{}).get('modelVersion')==MODEL and output_text(r['response']):
   return output_text(r['response']),{'raw_call':str(existing.relative_to(O)),'modelVersion':MODEL,'responseId':r['response'].get('responseId'),'usageMetadata':r['response'].get('usageMetadata',{}),'started_utc':r['started_utc'],'finished_utc':r['finished_utc'],'reused_saved_response':True}
 offset=len(list(RAW.glob(stem+'_attempt*.json')))
 for attempt in range(1,max(1,9-offset)):
  if STOP.is_set():raise RuntimeError('run_stopped')
  started=now();record={'model_requested':MODEL,'generation_config':{'temperature':temp},'prompt_sha256':ph,'started_utc':started,'attempt':offset+attempt};path=RAW/(stem+'_attempt'+str(offset+attempt)+'.json')
  try:
   pace();response=requests.post('https://generativelanguage.googleapis.com/v1beta/models/'+MODEL+':generateContent',headers={'x-goog-api-key':KEY},json={'contents':[{'parts':[{'text':prompt}]}],'generationConfig':{'temperature':temp}},timeout=150);record.update(http_status=response.status_code,finished_utc=now())
   if response.status_code==200:
    raw=response.json();record['response']=raw;path.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    if raw.get('modelVersion')!=MODEL:STOP.set();raise RuntimeError('model_version_mismatch')
    text=output_text(raw)
    if not text:raise ValueError('empty_model_output')
    return text,{'raw_call':str(path.relative_to(O)),'modelVersion':raw.get('modelVersion'),'responseId':raw.get('responseId'),'usageMetadata':raw.get('usageMetadata',{}),'started_utc':started,'finished_utc':record['finished_utc'],'reused_saved_response':False}
   try:
    err=response.json().get('error',{});record['error_status']=err.get('status');record['quota_details']=err.get('details',[])
    daily=any('PerDay' in v.get('quotaId','') for d in err.get('details',[]) for v in d.get('violations',[]))
    if daily:
     path.write_text(json.dumps(record,indent=2));STOP.set();raise RuntimeError('daily_quota_exhausted')
    delays=[d.get('retryDelay','0s') for d in err.get('details',[]) if d.get('@type','').endswith('RetryInfo')]
    if delays:
     delay=max(float(re.sub('[^0-9.]','',d) or 0) for d in delays)
     with RATELOCK:NEXT_SEND[0]=max(NEXT_SEND[0],time.monotonic()+delay+2)
   except ValueError:record['error_status']='non_json_error'
   path.write_text(json.dumps(record,indent=2))
   if response.status_code in [400,401,403,404]:STOP.set();raise RuntimeError('non_retryable_http_'+str(response.status_code))
   if response.status_code not in [429,500,502,503,504]:raise RuntimeError('http_'+str(response.status_code))
  except requests.RequestException as e:
   record.update(finished_utc=now(),error_type=type(e).__name__);path.write_text(json.dumps(record,indent=2))
  if offset+attempt<8:time.sleep(min(30,5*attempt))
 raise RuntimeError('attempts_exhausted')
def task_run(task):
 id=task['question_id'];condition=task['condition'];repeat=int(task['repeat']);row=contexts[id];cp=row['conditions'][condition];inp=inputs[task['generation_input_id']];stem=id+'_'+condition+'_r'+str(repeat);answer='';out={'id':id,'pair_id':row['pair_id'],'language':row['language'],'stratum':row['stratum'],'condition':condition,'repeat':repeat,'context_changed':row['context_changed'],'prompt_sha256':inp['prompt_sha256'],'question':row['question'],'expected_answer':row['expected_answer'],'gold_citations':row['gold_citations'],'error':'','calls':{}}
 try:
  answer,metadata=call(inp['prompt'],.2,stem+'_generation');out['initial_answer']=answer;out['calls']['generation']=metadata;prompt=inp['prompt']
  if 'Final validation:' in prompt and not ns['_allows_preamble_only'](prompt) and not ns['_is_grounding_refusal'](answer) and ', Art.' not in answer:
   repair=(f'{prompt}\n\nInvalid draft:\n{answer}\n\n'+'The draft is invalid because it lacks a retrieved article citation. '+'Return a corrected grounded answer containing at least one exact '+'[RDC or IN ..., Art. ...] citation from the context. If no article '+'supports the answer, return only the Portuguese refusal sentence. '+'Never attach an article citation to a claim that article does not '+'directly support; instead, revise the claim to match the article.')
   answer,metadata=call(repair,.2,stem+'_repair');out['calls']['repair']=metadata
   if not ns['_is_grounding_refusal'](answer) and ', Art.' not in answer:answer='Os documentos recuperados nao fornecem informacao suficiente para responder.';out['wrapper_fallback_refusal']=True
  out['answer']=answer;labels=[c for c,t in cp['retrieved_contexts']];out['canonical_refusal_detected']=ns['_is_grounding_refusal'](answer);out['refusal_detected']=ns['detect_refusal'](answer);out['citation_present'],out['strict_retrieved_citation_validity']=jns['citation_validity'](answer,labels);out['context_article_recall_at5']=cp['article_recall_at5'];out['answer_sha256']=hashlib.sha256(answer.encode()).hexdigest()
  jp=templates[task['judge_template_input_id']]['judge_prompt_template'].replace('{{GENERATED_SYSTEM_ANSWER}}',answer);out['judge_prompt_sha256']=hashlib.sha256(jp.encode()).hexdigest();(O/'judge_prompts').mkdir(exist_ok=True);(O/'judge_prompts'/(stem+'.txt')).write_text(jp)
  judged,metadata=call(jp,0,stem+'_judge');out['calls']['judge']=metadata;out['judge_raw_text']=judged;clean=re.sub(r'^```(?:json)?\s*','',judged.strip());clean=re.sub(r'\s*```$','',clean);j=json.loads(clean)
  for field in ['faithfulness','citation_correctness','completeness','refusal_correctness']:
   if field not in j or not 0<=float(j[field])<=1:raise ValueError('invalid_judge_score')
  out['judge']={field:float(j[field]) for field in ['faithfulness','citation_correctness','completeness','refusal_correctness']};out['judge']['rationale']=str(j.get('rationale',''))
 except Exception as e:out['error']=str(e) if isinstance(e,RuntimeError) else type(e).__name__
 with LOCK:
  with (O/'answers_checkpoint.jsonl').open('a') as f:f.write(json.dumps(out,ensure_ascii=False)+'\n')
  print(stem,'OK' if not out['error'] else out['error'],flush=True)
 return out
previous={}
if (O/'answers_checkpoint.jsonl').exists():
 for r in map(json.loads,(O/'answers_checkpoint.jsonl').read_text().splitlines()):previous[(r['id'],r['condition'],r['repeat'])]=r
jobs=[t for t in plan if (t['question_id'],t['condition'],int(t['repeat'])) not in previous or previous[(t['question_id'],t['condition'],int(t['repeat']))]['error']]
manifest={'status':'running','date':'2026-10-25','started_utc':now(),'user_approval':'approved,25October2026,after explicit Google transfer scope','model_requested':MODEL,'temperature_generation':.2,'temperature_judge':0,'n_questions':50,'n_pairs':25,'repeats_per_condition':3,'outputs_planned':300,'judge_calls_planned':300,'condition_masked_scoring':True,'human_review':'not performed; same-model judge provisional','input_hashes':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ['protocol_before_answers.json','execution_plan_300.csv','generation_inputs_100.jsonl','judge_templates_100.jsonl','frozen_contexts.jsonl']}}
(O/'run_manifest.json').write_text(json.dumps(manifest,indent=2));print('START approved fixed pilot; jobs',len(jobs),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(task_run,t):t for t in jobs};finished=0
 for future in concurrent.futures.as_completed(futures):
  if future.cancelled():continue
  row=future.result();previous[(row['id'],row['condition'],row['repeat'])]=row;finished+=1
  if STOP.is_set():
   for f in futures:f.cancel()
  if finished%5==0 or STOP.is_set():
   status={'status':'service_stopped' if STOP.is_set() else 'running','finished_this_session':finished,'records':len(previous),'successful':sum(not r['error'] for r in previous.values()),'errors':sum(bool(r['error']) for r in previous.values()),'updated_utc':now()};(O/'progress.json').write_text(json.dumps(status,indent=2))
results=[previous[k] for k in sorted(previous)];(O/'answer_results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in results));manifest.update(status='complete' if len(results)==300 and not any(r['error'] for r in results) else 'complete_with_errors',finished_utc=now(),n_outputs=len(results),n_errors=sum(bool(r['error']) for r in results),n_answer_outputs=sum('answer' in r for r in results),n_judge_outputs=sum('judge' in r for r in results),n_repairs=sum('repair' in r['calls'] for r in results),n_wrapper_fallback_refusals=sum(bool(r.get('wrapper_fallback_refusal')) for r in results));(O/'run_manifest.json').write_text(json.dumps(manifest,indent=2));print('FINISHED',json.dumps({k:v for k,v in manifest.items() if k not in ['input_hashes']}),flush=True)
