from pathlib import Path
import csv,json,hashlib,collections
root=Path(__file__).resolve().parent
for r in csv.DictReader((root/'FILE_INDEX.csv').open()):
 p=root/r['path'];b=p.read_bytes();assert len(b)==int(r['bytes']) and hashlib.sha256(b).hexdigest()==r['sha256'],str(p)
r=[json.loads(l) for l in (root/'data/DR11/answer_quality/02_Results/answer_results.jsonl').read_text().splitlines() if l.strip()]
assert len(r)==300 and all(not x['error'] for x in r)
plan=list(csv.DictReader((root/'data/DR11/answer_quality/01_Frozen_inputs/execution_plan_300.csv').open()))
assert {(x['id'],x['condition'],int(x['repeat'])) for x in r}=={(x['question_id'],x['condition'],int(x['repeat'])) for x in plan}
assert len({x['id'] for x in r})==50 and len({x['pair_id'] for x in r})==25
summary=list(csv.DictReader((root/'data/DR11/paired_answer_summary.csv').open()))
for group in ['affected_gold','control','all']:
 for condition in ['prefix512','fullcoverage']:
  rr=[x for x in r if x['condition']==condition and (group=='all' or x['stratum']==group)]
  mean=sum(x['judge']['completeness'] for x in rr)/len(rr)
  expected=next(x for x in summary if x['group']==group and x['metric']=='completeness')
  assert len(rr)==int(expected['n_outputs_per_condition']) and abs(mean-float(expected[condition+'_mean']))<1e-12
  print('DR11',group,condition,'n=',len(rr),'automated completeness=',mean)
s=list(csv.DictReader((root/'data/sibling_context/03_Human_review/original_return/Howard_sibling_first_repeat_completed.csv').open(encoding='utf-8-sig')));assert len(s)==44
p=list(csv.DictReader((root/'data/sibling_context/03_Human_review/ratings_linked_to_study_conditions.csv').open()));assert len(p)==44
for a,b in zip(s,p):
 assert (root/'data/sibling_context/03_Human_review/original_return'/a['evidence_file']).is_file()
 for k in ['review_id','supported_information_complete','selected_evidence_sufficiency','language_compliant','rationale']:assert a[k]==b[k],(a['review_id'],k)
print('PASS: payload hashes, 300 DR11 records, frozen-plan coverage, 44 original and linked sibling ratings.')
