"""Recalculate saved S16 counts without changing inputs or calling a model."""
from pathlib import Path
import csv,tempfile,runpy,hashlib
root=Path(__file__).resolve().parents[1]
with (root/'ORIGINAL_PATH_MAP.csv').open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
with tempfile.TemporaryDirectory(prefix='anvisa_s16_',dir='/private/tmp') as temp:
 stage=Path(temp)
 for r in rows:
  src=root/Path(r['organized_archive_path']).relative_to('Supplementary_Data_S16')
  data=src.read_bytes()
  assert hashlib.sha256(data).hexdigest()==r['organized_sha256'],str(src)
  dest=stage/r['original_archive_path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 runpy.run_path(str(stage/'Supplementary_Data_S16/recompute_S16_counts.py'),run_name='__main__')
