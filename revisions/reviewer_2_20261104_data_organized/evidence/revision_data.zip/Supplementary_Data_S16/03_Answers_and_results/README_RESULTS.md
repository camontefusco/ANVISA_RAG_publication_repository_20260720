# Dated corpus comparison provisional AI results

All new output assessments below are provisional AI assessments. The author approved references, not these output ratings. No new human verification is inferred.

376 logical answer records from 366 distinct prompts; 366 HTTP attempts. Frozen inputs and raw response linkage verified.

- language_items: historical 144/188; updated 172/188; difference 14.9 percentage points; pair bootstrap 95% interval 7.4 to 22.9; article-family sensitivity 7.1 to 23.1; gains 31, losses 3.
- bilingual_pairs: historical 69/94; updated 83/94; difference 14.9 percentage points; pair bootstrap 95% interval 6.4 to 24.5; article-family sensitivity 5.4 to 24.5; gains 17, losses 3.

These descriptive intervals retain bilingual pairing and include a shared-article dependence sensitivity. Residual topical dependence remains. This comparison does not establish a fresh held-out or independently validated benefit.

Citation pinpoint/combined syntax deviations are reported separately from substantive errors. A legally supported pinpoint citation can fail the exact software-label format.

## Limits

- Development-exposed reused questions, six pairs excluded before generation
- Shared downstream pipeline with author-provided Portuguese retrieval queries for both languages
- Corpus updating and structural curation bundled; not isolated removal of RDC9
- New-source availability separate from shared-source performance
- Incorporated cross-references can themselves be obsolete
- Single generation per distinct prompt; ten exact cross-condition reuse records
- No comprehensive current-law certification, fresh independent validation or human workflow outcome
- Correction flags describe outputs, not measured human verification time

The intervals are conditional on the provisional AI judgments and sampled question families. They do not include uncertainty from scoring disagreements, legal-reference errors or model-to-model variability. Bootstrap intervals can be degenerate in a tiny subgroup with identical observed differences; this does not establish population certainty.

These results are integrated into the revised manuscript and response letter. Figure 6, Supplementary Section S12 and Tables S23-S25 report the corpus comparison and dependency audit. The final response crosswalk supplies the rendered manuscript locations. This organization-only update does not change any scientific result or assessment.
