# Data entry point

The archive-level 00_READ_ME_FIRST.md and MANUSCRIPT_DATA_MAP.csv are the active navigation guides. Existing data/ paths are preserved for reproducibility. Consult the experiment-specific records and corrected provenance; historical pending-review notes do not replace the final author assessment layers. Howard had not seen automated judge scores before finalizing the historical 94 ratings; AI-draft assistance remains disclosed. Dated-corpus component scores remain provisional AI assessments.
