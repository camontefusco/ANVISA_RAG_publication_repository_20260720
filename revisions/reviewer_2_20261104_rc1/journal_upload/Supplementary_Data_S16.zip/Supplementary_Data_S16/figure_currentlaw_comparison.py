from pathlib import Path
import json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
F=Path(__file__).resolve().parent;O=F;S=json.loads((O/'RESULTS_PROVISIONAL_AI.json').read_text())
font='/System/Library/Fonts/Supplemental/Arial.ttf';assert Path(font).exists();font_manager.fontManager.addfont(font)
plt.rcParams.update({'font.family':'Arial','font.size':10,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','svg.fonttype':'none','pdf.fonttype':42})
fig,axs=plt.subplots(2,2,figsize=(12.4,9.5));fig.subplots_adjust(left=.17,right=.96,bottom=.13,top=.89,wspace=.52,hspace=.55)
colors=['#bbbbbb','#315974'];names=['Historical corpus','Updated corpus'];cs=['historical_corpus','updated_corpus'];w=.34
M={(x['condition'],x['metric']):x for x in S['metrics']};C={(x['subgroup'],x['unit']):x for x in S['comparisons']}
ax=axs[0,0];r=C['all_94_pairs','language_items'];vals=[r['historical_passes'],r['updated_passes']];bars=ax.bar(names,vals,color=colors,width=.56)
for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+3,f'{v}/188',ha='center')
ax.set_ylim(0,205);ax.set_ylabel('Successful language answers');ax.set_title('A  Full task success on the same 188 questions',loc='left',fontweight='bold',fontsize=11)
ax.text(.5,.97,'Paired change +14.9 points; 95% interval +7.4 to +22.9',transform=ax.transAxes,ha='center',va='top',fontsize=9)
ax=axs[0,1];r=C['all_94_pairs','bilingual_pairs'];vals=[r['historical_passes'],r['updated_passes']];bars=ax.bar(names,vals,color=colors,width=.56)
for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+1.5,f'{v}/94',ha='center')
ax.set_ylim(0,103);ax.set_ylabel('Pairs passing in both languages');ax.set_title('B  Both languages must pass',loc='left',fontweight='bold',fontsize=11)
ax.text(.5,.97,'Paired change +14.9 points; 95% interval +6.4 to +24.5',transform=ax.transAxes,ha='center',va='top',fontsize=9)
ax=axs[1,0];topics=[('clinical_trials','Clinical trials'),('biological_medicines','Biological medicines'),('general_medicine_registration','Medicine registration'),('medical_devices','Medical devices'),('pharmacovigilance','Pharmacovigilance'),('outside_bounded_reference_scope','Outside reference scope')];topics=[(t,l) for t,l in topics if ('topic_'+t,'language_items') in C];assert sum(C['topic_'+t,'language_items']['denominator'] for t,l in topics)==188;y=np.arange(len(topics))
for i,c in enumerate(cs):
 vals=[];den=[]
 for t,l in topics:r=C['topic_'+t,'language_items'];vals.append(r['historical_passes' if i==0 else 'updated_passes']);den.append(r['denominator'])
 ax.barh(y+(i-.5)*w,np.array(vals)/np.array(den)*100,height=w,color=colors[i],label=names[i])
 for j,(v,n) in enumerate(zip(vals,den)):ax.text(v/n*100+1,y[j]+(i-.5)*w,f'{v}/{n}',va='center',fontsize=9)
ax.set_yticks(y,[l for t,l in topics]);ax.invert_yaxis();ax.set_xlim(0,125);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Full task success (%)');ax.set_title('C  Same topic denominators in both conditions',loc='left',fontweight='bold',fontsize=11)
ax=axs[1,1];ms=[('omission','Omission'),('no_material_error','Material error'),('source_supported','Unsupported claim'),('applicability_correct','Applicability error'),('language_correct','Wrong language'),('substantive_correction_required','Substantive correction')];y=np.arange(len(ms))
for i,c in enumerate(cs):
 vals=[(188-M[c,m]['count']) if m in ['no_material_error','source_supported','applicability_correct','language_correct'] else M[c,m]['count'] for m,l in ms]
 ax.barh(y+(i-.5)*w,vals,height=w,color=colors[i])
 for j,v in enumerate(vals):ax.text(v+.4,y[j]+(i-.5)*w,f'{v}/188',va='center',fontsize=9)
ax.set_yticks(y,[l for m,l in ms]);ax.invert_yaxis();ax.set_xlim(0,max(50,max(M[c,'substantive_correction_required']['count'] for c in cs)+15));ax.set_xlabel('Answers flagged (overlapping categories)');ax.set_title('D  Failure and correction flags',loc='left',fontweight='bold',fontsize=11)
for ax in axs.ravel():ax.spines[['top','right']].set_visible(False)
fig.suptitle('Dated corpus comparison with provisional AI assessment',fontsize=16,color='black',y=.97)
fig.text(.5,.92,'94 development-exposed bilingual pairs | 188 questions per condition | 376 logical records from 366 distinct prompts',ha='center',fontsize=10)
handles=[plt.Rectangle((0,0),1,1,color=c) for c in colors];fig.legend(handles,names,loc='lower center',bbox_to_anchor=(.5,.055),ncol=2,frameon=False)
fig.text(.5,.026,'No new human output confirmation. Corpus updating and structural curation are bundled. Correction flags do not measure professional review time.',ha='center',fontsize=9)
fig.savefig(O/'Figure_currentlaw_provisional.svg');fig.savefig(O/'Figure_currentlaw_provisional.pdf');fig.savefig(O/'Figure_currentlaw_provisional.png',dpi=160)
fig.savefig(O/'Figure_currentlaw_provisional_600dpi.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
im=Image.open(O/'Figure_currentlaw_provisional_600dpi.tiff');assert im.info['dpi']==(600.,600.);print(im.size,im.info['dpi'])
