# DR8 dependency audit completed 4 November 2026

The audit improves source verification but does not certify comprehensive current-law accuracy. All seven indexed source regulations still display active status (with amendments where shown). Their first-level visible links identify 111 distinct instruments: 70 active, 26 revoked, five amending instruments and ten unresolved endpoints reporting that the act is being processed. Preambles, repeal lists, transition provisions and historical amendment links are included in this catalogue count. Twenty-six revoked linked instruments are not 26 answer errors.

The frozen operative-article text contains 128 explicit RDC reference occurrences involving 86 RDCs. Nine operative/scope occurrences name eight revoked instruments. Two are the previously identified RDC 36/2015 and RDC 305/2019 references in RDC 751 Article 2. Six additional instruments occur in RDC 948: RDCs 327/2019, 204/2017, 31/2014, 26/2014, 469/2021 and 940/2024. Official successors and their commencement/transition clauses were captured. RDC 940's successor expressly permits adaptation periods; a revoked citation alone does not prove unlawful conduct or product inapplicability.

Exact gold-citation matching links these flags only to the already failed COMPLEX_09 bilingual pair. Some other stale references reached selected contexts as surrounding evidence, so answer exposure was checked separately. A number-only citation screen also catches English date-style references. Explicit obsolete references occur only in already failed COMPLEX_09 answers. The remaining inspected questions concern other requirements or unavailable details and do not adopt those additional obsolete authorities. This is a targeted AI-assisted secondary audit, not new human confirmation or proof that every possible indirect dependency is absent. Original 144/188 and 172/188 provisional outcomes and all initial notes remain unchanged.

## Files

- first_level_linked_instrument_registry_111.csv: status, source URL, UTC and hash for every first-level instrument.
- frozen_article_reference_occurrences_128.csv: exact parent provisions, roles, gold matches and context exposure.
- revoked_operative_reference_flags.csv: the nine occurrences requiring temporal checks.
- successor_verification_evidence.json: eight replacement instruments, cited clauses, excerpts and transition cautions.
- explicit_obsolete_reference_answer_screen.csv: candidate output references, including English date-style citations.
- CANDIDATE_DEPENDENCY_WARNINGS_NOT_APPLIED.json: warning metadata for a separately frozen future branch, not a retrospective repair.
- The blank human review pack is retained separately in the local project and is not included in this curated subset.

Full official-page captures are retained locally in official_captures_local_only and are excluded from the curated submission data. They resolve the earlier RDC 830/925 full-capture failure. The catalogue cannot presently supply ten linked full texts; their status remains unresolved rather than presumed active. Some long captures are clipped, as marked in the registry. The audit is first-level plus targeted successor tracing, not recursive closure of all Brazilian legislation. It excludes implied unnamed dependencies and does not establish individual-product or filing-date applicability. No Google calls, human ratings or scientific-score changes were made.
