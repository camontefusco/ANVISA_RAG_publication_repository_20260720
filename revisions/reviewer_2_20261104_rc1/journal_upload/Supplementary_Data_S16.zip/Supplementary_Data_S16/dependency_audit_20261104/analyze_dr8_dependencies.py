from pathlib import Path
import json,re,csv,collections,hashlib,shutil,datetime
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');F=B/'current_law_candidate_20261103/comparison_preparation_20261103';O=B/'dependency_audit_20261104';O.mkdir(exist_ok=True);(O/'official_captures_local_only').mkdir(exist_ok=True)
ds=json.loads((F/'local_assets/current_documents.json').read_text());targets=json.loads(Path('/private/tmp/DR8_link_targets.json').read_text());occ=json.loads(Path('/private/tmp/DR8_extracted_dependencies.json').read_text());answers=list(csv.DictReader((F/'analysis_provisional/answer_level_provisional_AI_assessments_376.csv').open(encoding='utf-8-sig')));refs=list(csv.DictReader((F/'references_188_author_approved.csv').open(encoding='utf-8-sig')));contexts=[json.loads(l) for l in (F/'contexts_188_pairs_376_answers.jsonl').read_text().splitlines()]
def dumpcsv(path,rows):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def norm(t):return ' '.join(t.split())
registry=[];bydep={}
for t in targets:
 p=Path(f'/private/tmp/DR8_dependency_{t["type"]}_{int(t["number"])}_{t["year"]}.json');d=json.loads(p.read_text());head=d['text'][:500];status=re.search(r'(VIGENTE COM ALTERAÇÕES|VIGENTE|REVOGADO|ALTERADOR)',head);dep=f'{t["type"]} {int(t["number"])}/{t["year"]}';rep=re.search(r'Revogad[ao] pela[^\n]+',d['text'],re.I)
 row=dict(instrument=dep,displayed_status=status[1] if status else 'unresolved_source_processing',access_utc=d['access_utc'],official_url=d['url'],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),characters=len(d['text']),full_text_capture_limited=len(d['text'])>=200000,revocation_note=rep[0] if rep else '',scope='first-level linked instrument; includes preamble, amendment, history and operative links; not all are current operative requirements')
 registry.append(row);bydep[dep]=row
for p in Path('/private/tmp').glob('DR8_*.json'):
 if any(p.name.startswith('DR8_'+s) for s in ['parent_','dependency_','detail_','alternate_','successor_']):shutil.copy2(p,O/'official_captures_local_only'/p.name)
# Mechanical reference-role screen, with exact parent-article mapping for targeted manual review.
def role(r):
 key=(r['parent_regulation'],r['parent_article'])
 if key in {('RDC 406/2020','Art. 50'),('RDC 945/2024','Art. 98'),('RDC 751/2022','Art. 66'),('RDC 948/2024','Art. 59'),('RDC 875/2024','Art. 11'),('RDC 55/2010','Art. 48')}:return 'repeal_or_partial_repeal'
 if key in {('RDC 751/2022','Art. 64'),('RDC 751/2022','Art. 65'),('RDC 948/2024','Art. 58')}:return 'amending_instruction'
 if key==('RDC 751/2022','Art. 61'):return 'dated_transitional_reference'
 return 'operative_or_scope_reference'
rows=[];flagged=[]
for r in occ:
 key=(r['parent_regulation'],r['parent_article']);label=', '.join(key);dep=r['dependency'];st=bydep.get(dep,{}).get('displayed_status','not_in_link_inventory');rrole=role(r)
 # Exact citation comparison avoids confusing Art. 1 with Art. 19.
 gold=[q['candidate_id'] for q in refs if label in json.loads(q['gold_citations'])]
 selected=[c['pair_id']+' '+c['condition'] for c in contexts if norm(next(d['text'] for d in ds if (d['metadata']['regulation_id'],d['metadata']['article'])==key)) in norm(c['context'])]
 pat=re.compile(r'RDC\s*(?:n[ºo°.]?\s*)?'+dep.split()[1].replace('/',r'\s*/\s*'),re.I)
 hits=[a['answer_id'] for a in answers if pat.search(a['answer'])]
 rr={**r,'reference_role':rrole,'displayed_dependency_status':st,'exact_gold_question_ids':';'.join(gold),'full_parent_article_context_records':';'.join(selected),'reference_text_context_records':';'.join(c['pair_id']+' '+c['condition'] for c in contexts if norm(r['matched_text']) in norm(c['context'])),'explicit_answer_reference_ids':';'.join(hits),'interpretation':'status exposure does not alone establish an answer error'};rows.append(rr)
 if st=='REVOGADO' and rrole=='operative_or_scope_reference':flagged.append(rr)
dumpcsv(O/'first_level_linked_instrument_registry_111.csv',registry);dumpcsv(O/'frozen_article_reference_occurrences_128.csv',rows);dumpcsv(O/'revoked_operative_reference_flags.csv',flagged)
summary=dict(date='2026-11-04',indexed_source_regulations=7,linked_instruments=len(registry),displayed_status_counts=dict(collections.Counter(x['displayed_status'] for x in registry)),frozen_RDC_reference_occurrences=len(rows),distinct_frozen_RDC_targets=len(set(r['dependency'] for r in rows)),revoked_operative_occurrences=len(flagged),distinct_revoked_operative_targets=sorted(set(r['dependency'] for r in flagged)),exact_gold_question_ids=sorted(set(q for r in flagged for q in r['exact_gold_question_ids'].split(';') if q)),limits=['First-level visible links and explicit RDC references, not a recursively closed graph of all Brazilian law.','Status labels are catalogue observations; transitional applicability, partial repeal and amendments require provision-level interpretation.','Ten full-text endpoints report processing; status not inferred as current.','Long captures may be clipped; status evidence and complete legal-text validation are separate.','Original 376 answer scores and frozen corpora are preserved. No new Google calls or human ratings.'])
(O/'AUDIT_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));shutil.copy2('/private/tmp/analyze_dr8_dependencies.py',O/'analyze_dr8_dependencies.py');print(json.dumps(summary,indent=2));print('FLAGS',[(r['dependency'],r['parent_regulation'],r['parent_article'],r['exact_gold_question_ids'],r['explicit_answer_reference_ids']) for r in flagged])
