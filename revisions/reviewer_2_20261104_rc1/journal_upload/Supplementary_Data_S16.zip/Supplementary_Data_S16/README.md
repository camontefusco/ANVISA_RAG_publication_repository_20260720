# Supplementary Data S16

This dated corpus comparison completed on 3 November 2026. It contains 376 condition records for the same 188 questions (94 bilingual pairs), produced by 366 distinct Google Gemini calls and ten exact-prompt reuses. All 376 output assessments are provisional local Codex AI judgments. Author approval of references before generation is separate from human review of generated outputs, which remains pending. See Supplementary Section S12, Tables S23 and S24 and Figure 6.

## Reading order

1. `README_RESULTS.md` and `RESULTS_PROVISIONAL_AI.json`: findings and limitations.
2. `answer_level_provisional_AI_assessments_376.csv`: complete answers, component decisions, notes and provenance.
3. `paired_results_94.csv`, `metric_counts_denominators.csv` and `paired_comparisons_descriptive_intervals.csv`: paired results and denominators.
4. Frozen questions, author-approved references, contexts, common prompt, analysis plan and exact-prompt reuse map: experiment inputs.
5. `source_registry_12.csv` and `postfreeze_linked_source_verification.json`: source versions and subsequent dependency checks. Not all 12 registry entries were indexed; seven regulations supplied the updated index.
6. `HYPOTHESIS_AND_NEGATIVE_RESULTS.md`: failed explanations, regressions and retained limitations.

`FROZEN_INPUT_HASHES.json` reproduces matching hashes for the distributed subset of the original pre-generation manifest. `FINAL_RESEARCH_QA.json` is preserved from the research-completion stage before manuscript integration; its statement about unchanged journal files is historical, not the status of this editorial revision. Original assessment decisions remain preserved.

## Recalculation and code

Run `python recompute_S16_counts.py` with NumPy installed to independently recalculate the primary counts and bilingual-pair bootstrap intervals from the two distributed CSVs. The original `summarize_currentlaw_comparison.py` is retained as research execution provenance; it requires the full local research layout and private coordination records and is not standalone in this subset. The figure script is configured for this directory and requires Matplotlib, NumPy, Pillow and an installed Arial font.

Raw provider metadata files, full corpus snapshots/index vectors, credentials, provider account metadata and private coordination keys are excluded. Full answer text is included; local raw-file paths in preserved records identify provenance and are not packaged download links. Historical outputs and public v0.2.1 remain separate. Confidence intervals are conditional on AI labels and development-exposed question families; they do not establish independent validation, comprehensive legal accuracy or human workflow benefit. No Google judge calls were made.

## Dependency audit added on 4 November 2026

The dependency_audit_20261104 subfolder provides first-level status and targeted successor checks, including Table S25 evidence. It is a post hoc source audit and does not replace the frozen references, original outcome labels or initial AI assessments. Raw official-page captures and the blank human review pack remain local. The earlier failed captures of RDC 830/925 have now been resolved; their historical failure records remain preserved.
