from pathlib import Path
import csv,json
import numpy as np
p=Path(__file__).resolve().parent
with (p/'answer_level_provisional_AI_assessments_376.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
with (p/'paired_results_94.csv').open(encoding='utf-8-sig',newline='') as f:pairs=list(csv.DictReader(f))
assert len(rows)==376 and len(pairs)==94
counts={c:sum(int(r['primary_success']) for r in rows if r['condition']==c) for c in ['historical_corpus','updated_corpus']}
assert counts=={'historical_corpus':144,'updated_corpus':172}
rng=np.random.default_rng(20261103);sample=rng.integers(0,94,size=(20000,94))
result={'answer_successes':counts,'denominator_per_condition':188,'bilingual_pair_successes':{c:sum(int(r[c+'_bilingual_pass']) for r in pairs) for c in counts}}
for column in ['language_rate_difference','bilingual_difference']:
 values=np.array([float(r[column]) for r in pairs]);ci=np.quantile(values[sample].mean(axis=1),[.025,.975]);result[column]={'difference':float(values.mean()),'pair_bootstrap_95_percent_interval':ci.tolist()}
print(json.dumps(result,indent=2))
