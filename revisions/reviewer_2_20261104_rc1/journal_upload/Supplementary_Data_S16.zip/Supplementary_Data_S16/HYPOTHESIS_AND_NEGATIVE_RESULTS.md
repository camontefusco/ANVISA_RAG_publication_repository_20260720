# Completed dated corpus comparison

The fixed comparison completed on 3 November 2026 with 376 logical answer records from 366 distinct prompts and 366 successful API calls. No provider retries, judge, translation or repair calls were needed. The six prespecified excluded bilingual pairs remain excluded.

Initial direct Codex assessment gives 144/188 historical-corpus successes and 172/188 updated-corpus successes. Both languages pass in 69/94 versus 83/94 pairs. The language-answer difference is 14.9 percentage points (bilingual-pair bootstrap 95% interval 7.4 to 22.9; shared-article-family sensitivity 7.1 to 23.1). These are provisional AI assessments, not newly human-confirmed results.

The shared-source subset rises from 118/148 to 133/148. Newly supplied sources rise from 0/10 to 10/10; this is evidence availability under the supplied-context design, not improved reasoning. Bounded negative controls rise from 26/30 to 29/30. Three individual answers regress: imported-device renewal answered in the wrong language, omission of a partial-data response option, and an unsupported mandatory dual ethical-review interpretation. The last two include reference-scope/interpretation issues requiring human confirmation.

The fixed batch tests a combined change in corpus currency and structural curation. It does not isolate removal ofRDC9/2015. Remaining failures include missing second provisions, overgeneralizing an individual biological-product pathway, a false-premise correction without the positive timing rule, and obsolete incorporated references inside the otherwise active RDC751/2022. No additional tuning or new generation has been performed after inspecting these outcomes.

The approved current references do not make every retrieved passage sufficient, every incorporated cross-reference current, or every new model answer correct. Earlier human reviews and the current reference approval are preserved separately from these new AI output assessments. Human confirmation is still needed before describing the new scores as author-reviewed.
