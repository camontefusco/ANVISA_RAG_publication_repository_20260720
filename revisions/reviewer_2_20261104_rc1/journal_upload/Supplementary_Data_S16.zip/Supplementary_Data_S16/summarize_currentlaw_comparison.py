"""Local, provisional analysis; no provider calls and no change to frozen inputs."""
from pathlib import Path
import json,csv,hashlib,re,datetime,collections,sys
import numpy as np
F=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/current_law_candidate_20261103/comparison_preparation_20261103')
O=F/'analysis_provisional';O.mkdir(exist_ok=True)
readjl=lambda p:[json.loads(x) for x in p.read_text().splitlines()]
inputs=readjl(F/'generation_inputs_376_FROZEN.jsonl');results=readjl(F/'results_checkpoint.jsonl')
key=json.loads((F/'assessment_private/COORDINATOR_KEY_PRIVATE.json').read_text())['coordinator_key'];keys={x['answer_id']:x for x in key};bycall={x['call_id']:x for x in results};initial=readjl(F/'assessment_private/AI_INITIAL_RATINGS.jsonl');ratings={x['answer_id']:x for x in initial}
assert len(ratings)==len(initial)
sub={x['pair_id']:x for x in json.loads((F/'ANALYSIS_SUBGROUPS_BEFORE_GENERATION.json').read_text())}
assert len(results)==376 and len(ratings)==376,'Complete generation and assessment required; no missing calls scored as failures'
assert len({x['call_id'] for x in results})==376 and len({x['prompt_sha256'] for x in results})==366
manifest=json.loads((F/'EXPERIMENT_FROZEN_BEFORE_GENERATION.json').read_text())
for name,digest in manifest['input_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
for r in results:
 raw=json.loads((F/r['raw_file']).read_text());assert raw['answer']==r['answer'] and raw['modelVersion']==r['model']=='gemini-3.5-flash-lite' and raw['prompt_sha256']==r['prompt_sha256']
rows=[]
for aid,r in ratings.items():
 k=keys[aid];out=bycall[k['call_id']];s=sub[k['pair_id']]
 rows.append(k|s|r|{'answer':out['answer'],'raw_file':out['raw_file'],'prompt_sha256':out['prompt_sha256'],'exact_prompt_reused_from':out.get('exact_prompt_reused_from')})
rows.sort(key=lambda x:x['answer_id'])
def csvout(name,rs,fields=None):
 fields=fields or list(dict.fromkeys(k for r in rs for k in r))
 with (O/name).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in rs)
csvout('answer_level_provisional_AI_assessments_376.csv',rows)
conds=['historical_corpus','updated_corpus'];metrics=['primary_success','complete_requested_information','source_supported','no_material_error','applicability_correct','unavailable_information_handled','language_correct','omission','unjustified_refusal','substantive_correction_required','citation_present','citation_supported','citation_exact_label_format','citation_format_correction_required','any_correction_required','revoked_current_reliance']
totals=[]
for c in conds:
 rs=[x for x in rows if x['condition']==c]
 for m in metrics:
  valid=[x.get(m,0 if m=='revoked_current_reliance' else None) for x in rs];valid=[v for v in valid if v is not None]
  totals.append(dict(condition=c,metric=m,count=sum(valid),denominator=len(valid),proportion=sum(valid)/len(valid) if valid else None))
csvout('metric_counts_denominators.csv',totals)
lookup={(x['pair_id'],x['language'],x['condition']):x for x in rows};paired=[]
for pid in sorted(sub):
 d={'pair_id':pid,**sub[pid]}
 for c in conds:
  rs=[lookup[pid,l,c] for l in ['pt','en']]
  d[c+'_language_passes']=sum(x['primary_success'] for x in rs);d[c+'_bilingual_pass']=int(all(x['primary_success'] for x in rs))
  for l in ['pt','en']:d[c+'_'+l+'_success']=lookup[pid,l,c]['primary_success']
 d['language_rate_difference']=(d['updated_corpus_language_passes']-d['historical_corpus_language_passes'])/2
 d['bilingual_difference']=d['updated_corpus_bilingual_pass']-d['historical_corpus_bilingual_pass'];paired.append(d)
csvout('paired_results_94.csv',paired)
def boot(rs,field,family=False):
 groups=collections.defaultdict(list)
 for r in rs:groups[r['shared_article_family'] if family else r['pair_id']].append(r[field])
 vals=list(groups.values());a=np.array([sum(v) for v in vals]);n=np.array([len(v) for v in vals]);rng=np.random.default_rng(20261103);idx=rng.integers(0,len(a),size=(20000,len(a)));b=a[idx].sum(axis=1)/n[idx].sum(axis=1)
 return [float(v) for v in np.quantile(b,[.025,.975])]
comparisons=[]
filters={'all_94_pairs':lambda r:True,'shared_source_provisions':lambda r:r['reference_source_group']=='shared_source_provisions','newly_added_source_required':lambda r:r['reference_source_group']=='newly_added_source_required','bounded_negative_control':lambda r:r['reference_source_group']=='bounded_negative_control'}
for topic in sorted({r['topic'] for r in paired}):filters['topic_'+topic]=lambda r,t=topic:r['topic']==t
for label,predicate in filters.items():
 rs=[r for r in paired if predicate(r)]
 if not rs:continue
 for unit,field,suffix,denom in [('language_items','language_rate_difference','language_passes',2),('bilingual_pairs','bilingual_difference','bilingual_pass',1)]:
  c={'subgroup':label,'unit':unit,'denominator':len(rs)*denom,'historical_passes':sum(r['historical_corpus_'+suffix] for r in rs),'updated_passes':sum(r['updated_corpus_'+suffix] for r in rs),'difference':sum(r[field] for r in rs)/len(rs),'pair_bootstrap_95CI':boot(rs,field),'article_family_bootstrap_95CI':boot(rs,field,True)}
  if unit=='language_items':
   c['gains']=sum(r['updated_corpus_'+l+'_success']>r['historical_corpus_'+l+'_success'] for r in rs for l in ['pt','en']);c['losses']=sum(r['updated_corpus_'+l+'_success']<r['historical_corpus_'+l+'_success'] for r in rs for l in ['pt','en'])
  else:c['gains']=sum(r[field]>0 for r in rs);c['losses']=sum(r[field]<0 for r in rs)
  comparisons.append(c)
csvout('paired_comparisons_descriptive_intervals.csv',comparisons)
summary={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'complete generation and provisional AI assessment; no new human output confirmation','logical_records':376,'distinct_prompts':366,'http_attempts':len(list((F/'raw_calls').glob('*.json'))),'model':'gemini-3.5-flash-lite','temperature':.2,'assessment':'Direct local Codex provisional AI assessment with masked labels and development/study awareness; not independent or confirmed human review','all_inputs_hash_verified':True,'comparisons':comparisons,'metrics':totals,'limitations':['Development-exposed reused questions, six pairs excluded before generation','Shared downstream pipeline with author-provided Portuguese retrieval queries for both languages','Corpus updating and structural curation bundled; not isolated removal of RDC9','New-source availability separate from shared-source performance','Incorporated cross-references can themselves be obsolete','Single generation per distinct prompt; ten exact cross-condition reuse records','No comprehensive current-law certification, fresh independent validation or human workflow outcome','Correction flags describe outputs, not measured human verification time']}
(O/'RESULTS_PROVISIONAL_AI.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
main=[r for r in comparisons if r['subgroup']=='all_94_pairs'];lines=['# Dated corpus comparison provisional AI results','','All new output assessments below are provisional AI assessments. The author approved references, not these output ratings. No new human verification is inferred.','',f'376 logical answer records from 366 distinct prompts; {summary["http_attempts"]} HTTP attempts. Frozen inputs and raw response linkage verified.','']
for r in main:lines.append(f'- {r["unit"]}: historical {r["historical_passes"]}/{r["denominator"]}; updated {r["updated_passes"]}/{r["denominator"]}; difference {100*r["difference"]:.1f} percentage points; pair bootstrap 95% interval {100*r["pair_bootstrap_95CI"][0]:.1f} to {100*r["pair_bootstrap_95CI"][1]:.1f}; article-family sensitivity {100*r["article_family_bootstrap_95CI"][0]:.1f} to {100*r["article_family_bootstrap_95CI"][1]:.1f}; gains {r["gains"]}, losses {r["losses"]}.')
lines+=['','These descriptive intervals retain bilingual pairing and include a shared-article dependence sensitivity. Residual topical dependence remains. This comparison does not establish a fresh held-out or independently validated benefit.','','Citation pinpoint/combined syntax deviations are reported separately from substantive errors. A legally supported pinpoint citation can fail the exact software-label format.','','## Limits','']+['- '+x for x in summary['limitations']]
(O/'README_RESULTS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'complete':True,'logical_records':376,'comparisons':main},indent=2))
