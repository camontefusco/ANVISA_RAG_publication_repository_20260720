# Current integrated submission package, 3 November 2026

Use manuscript_clean.docx and its line-numbered PDF, manuscript_tracked.docx with cumulative real Word revisions against the September submission, and response_to_reviewers.docx. response_to_reviewer_2.docx is an identical compatibility copy. All 32 supplied attachment comments are preserved verbatim, with locations verified against clean PDF lines 1 to 487. All 32 figure/table assets are cited in the main text.

Howard's completed coauthor ratings now lead the separate common-prompt comparison: hybrid 39/40 successful answers and 19/20 bilingual pairs; BM25 38/40 and 18/20; model-only 9/40 and 4/20. The hybrid-minus-BM25 interval spans zero; superiority/equivalence is not established. Table 4, Figure 5, Supplementary Table S21 and Supplementary Figure S1 use these same author outcomes. Earlier AI judgments, secondary disagreements and the earlier repair comparison (Table 3/Figure 4) remain separate.

The actual new review date is 2 November 2026, received 3 November; Howard personally drafted and approved 118 distinct records representing 120 condition outputs. Prior project/question exposure and limited condition masking remain disclosed. This is not independent external validation. Current-law accuracy remains unestablished. Web-search superiority and human workflow benefit are outside this technical evaluation.

Abstract: 218 words. Conservative pre-reference count including title-page material: 4972 words. See INTEGRATION_AND_QA_REPORT.md for completed checks and research limits. Six canonical document types have current PDF previews. The data ZIP preserves raw generations and historical scores, updates its active guide with exact old-guide preservation, and adds author ratings/provenance/disagreements and reproducible figure sources. Full corpus/index files, credentials and concealed review keys remain excluded.

This is the current local revision, not a published release or journal submission. The prior 2 November package remains intact. No DOI, GitHub release or final author approval is asserted.

Final quality review completed on 3 November: one DR13 wording/location ambiguity corrected; no new numerical discrepancies detected. See FINAL_QUALITY_REVIEW_20261103.md.
