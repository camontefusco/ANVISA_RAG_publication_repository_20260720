# Quality review of revised reference answers

Three revised pairs change task scope. Adding a broader PK exception is not evidence that the earlier Arts2–3-only reference was wrong. Refreshed tasks require a fresh evaluation; do not rescore historical answers against a changed question.

All eight reviewed rows are accepted for a versioned working candidate after source, completeness, conditions, Portuguese-English equivalence and task-comparability checks. Reviewer: Codex; AI review, not human review. The separate working collection has 50 rows: 42 unchanged replacement drafts, two revised replacement pairs and two additional pairs. No production index, historical gold or score changed.
