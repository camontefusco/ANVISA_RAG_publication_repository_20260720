# Completed fresh integrated repair comparison

All 20 question-only translations and 80 paired answer generations completed. Eight translations from 31 October were reused. No judge or repair calls were made; model, temperature, questions, references, pipeline and prompts remained fixed.

Primary frozen-rubric success required both languages. Baseline passed 14/20 pairs (70.0%; exact 95% CI 45.7 to 88.1%); repair passed 18/20 (90.0%; 68.3 to 98.8%). Difference +20 points, paired percentile bootstrap interval +5 to +40. Four improved and none worsened, but exact two-sided discordant-pair p = 0.125. The small sample and observed-pattern bootstrap do not establish a reliable population benefit.

Raw/raw success was 14/20 versus 15/20 (difference +5 points; interval -20 to +30). Common citation formatting yielded 15/20 versus 18/20 (difference +15; interval 0 to +30; exact paired p = 0.250). Formatting contributes materially; do not describe the primary contrast as a generator-only accuracy gain.

Primary category counts were 10/12 versus 12/12 answerable, 0/4 versus 2/4 partly answerable and 4/4 versus 4/4 unanswerable. All 32 positive language rows had complete frozen reference passages in both conditions. Mean context length was 5736.5 versus 16487.5 characters. No retrieval gain was observed at this coverage ceiling.

Four repaired failures remain: both languages of FV_014 and FV_016. They refused despite supported staffing/EET information and did not identify the unavailable requested detail. Wrong-language outputs were two versus zero. Raw citation-format violations were one baseline and four repaired non-refusal outputs. No unsupported value was identified in local inspection; this is not a safety certification.

FV_012 has a possible broader reference-scope issue involving Articles 30 and 31 beyond the frozen Article 17 core. The frozen gold is unchanged. Excluding the pair gives primary 13/19 versus 17/19 and common-format 14/19 versus 17/19. Grouping FV_011/FV_019 addresses their shared Article 53 only; all tasks still depend on four named archived regulations.

These inputs were AI-authored after development exposure, and all 80 assessments were local, AI-assisted and unblinded. New gold and outcomes await human confirmation. Earlier author confirmations and Howard ratings are not extended to them. No current-law or independent-validation claim is made.

## Stopping and remaining work

This bounded validation is finished. Do not tune the frozen pipeline or relabel its gold in response to these outcomes. A partial-answer/false-premise/exact-subject rule interaction is a plausible remaining explanation, not an isolated mechanism result. Further testing on these questions would be development work and require a new frozen evaluation for a generalization claim. Human confirmation of the new gold and 80 ratings is the next dependency. A separate private review template is prepared; no message or file has been sent to anyone.
