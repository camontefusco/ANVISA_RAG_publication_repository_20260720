from pathlib import Path
import json,csv,hashlib,re,importlib.util,datetime,collections,shutil
import numpy as np
from scipy.stats import beta,binomtest
O=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/integrated_repair_validation_20261031');G=O/'answer_generations_80';A=O/'analysis_20261101';A.mkdir(exist_ok=True)
load=lambda p:[json.loads(x) for x in p.read_text().splitlines() if x.strip()]
I={x['call_id']:x for x in load(G/'generation_inputs_80.jsonl')};X={x['call_id']:x for x in load(G/'results_checkpoint.jsonl')};R={x['id']:x for x in load(O/'fresh_references_40_FROZEN.jsonl')};V=json.loads((A/'local_AI_review_80.json').read_text());assert len(I)==len(X)==len(V)==80 and all(x.get('answer') and not x['error'] for x in X.values())
spec=importlib.util.spec_from_file_location('pp',O/'frozen_validation_postprocessing.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fp=json.loads((O/'POSTPROCESSING_FROZEN_BEFORE_ANSWERS.json').read_text());assert hashlib.sha256((O/'frozen_validation_postprocessing.py').read_bytes()).hexdigest()==fp['postprocessor_sha256'];assert hashlib.sha256((O.parents[3]/'evaluation/answer_quality.py').read_bytes()).hexdigest()==fp['existing_formatter_source_sha256']
rows=[]
def literal(a,allowed):
 labs=re.findall(r'\[([^\]\n]+)\]',a)
 return not labs if m.canonical_refusal(a) else bool(labs) and all(l in allowed for l in labs)
for cid,i in sorted(I.items()):
 a=X[cid]['answer'];v=V[cid];r=R[i['id']];assert hashlib.sha256(a.encode()).hexdigest()==v['answer_sha256'];assert len(v['required_components_met'])==len(r['required_components']);allowed=[z['citation'] for z in i['selected_evidence']];p=m.processed_answer(a,i['condition'],i['language'],allowed);common=m.common_citation_overlay(a,allowed)
 core=all(v['required_components_met']) and v['unavailable_detail_handled'] and v['no_unsupported_assertions'];ref=m.canonical_refusal(a)
 if r['category']=='unanswerable':core=core and ref and v['appropriate_full_abstention']
 rows.append({k:i[k] for k in ['call_id','id','pair_id','condition','language']}|{'category':r['category'],'raw_answer':a,'primary_answer':p,'common_citation_answer':common,'answer_sha256':v['answer_sha256'],'components_met':json.dumps(v['required_components_met']),'missing_detail_handled':v['unavailable_detail_handled'],'no_unsupported_assertions':v['no_unsupported_assertions'],'requested_language':v['requested_language'],'blanket_refusal':ref,'content_and_boundary':core,'content_language':core and v['requested_language'],'raw_citation_format':literal(a,allowed),'primary_citation_format':literal(p,allowed),'raw_full_task':core and v['requested_language'] and literal(a,allowed),'primary_full_task':core and v['requested_language'] and literal(p,allowed),'common_citation_full_task':core and v['requested_language'] and literal(common,allowed),'rationale':v['rationale'],'assessment_provenance':v['assessment_provenance']})
def save(name,rs):
 with (A/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
save('answer_quality_80.csv',rows)
keys=['content_and_boundary','content_language','raw_full_task','primary_full_task','common_citation_full_task'];pairs=[]
for c in ['original_baseline','integrated_repair']:
 for pair in sorted({x['pair_id'] for x in rows}):
  z=[x for x in rows if x['pair_id']==pair and x['condition']==c];assert len(z)==2
  pairs.append({'pair_id':pair,'condition':c,'category':z[0]['category']}|{k:all(x[k] for x in z) for k in keys})
save('pair_quality_40.csv',pairs)
def exact(k,n):return [float(beta.ppf(.025,k,n-k+1)) if k else 0.,float(beta.ppf(.975,k+1,n-k)) if k<n else 1.]
def metric(z,k):
 n=len(z);v=sum(x[k] for x in z);return {'successes':v,'n':n,'proportion':v/n,'exact_95_CI':exact(v,n)}
cells={}
for c in ['original_baseline','integrated_repair']:
 z=[x for x in rows if x['condition']==c];p=[x for x in pairs if x['condition']==c];cells[c]={'language_rows':{k:metric(z,k) for k in keys},'pairs':{k:metric(p,k) for k in keys},'category_pairs':{cat:metric([x for x in p if x['category']==cat],'primary_full_task') for cat in ['answerable','partly_answerable','unanswerable']},'category_language_rows':{cat:metric([x for x in z if x['category']==cat],'primary_full_task') for cat in ['answerable','partly_answerable','unanswerable']},'wrong_language_rows':sum(not x['requested_language'] for x in z),'unsupported_assertion_rows':sum(not x['no_unsupported_assertions'] for x in z),'positive_blanket_refusals':sum(x['blanket_refusal'] and x['category']!='unanswerable' for x in z),'raw_citation_failures_nonrefusals':sum(not x['raw_citation_format'] and not x['blanket_refusal'] for x in z),'postprocessing_changed_rows':sum(x['raw_answer']!=x['primary_answer'] for x in z)}
rng=np.random.default_rng(20261101);N=100000;comparisons={}
for key in keys:
 pids=sorted({x['pair_id'] for x in pairs});lookup={(x['condition'],x['pair_id']):int(x[key]) for x in pairs};b=np.array([lookup['original_baseline',p] for p in pids]);f=np.array([lookup['integrated_repair',p] for p in pids]);d=f-b;boot=d[rng.integers(0,len(d),size=(N,len(d)))].mean(axis=1);groups=[[j for j,p in enumerate(pids) if p in ['FV_011','FV_019']]]+[[j] for j,p in enumerate(pids) if p not in ['FV_011','FV_019']];sums=np.array([d[g].sum() for g in groups]);sizes=np.array([len(g) for g in groups]);idx=rng.integers(0,len(groups),size=(N,len(groups)));source=sums[idx].sum(axis=1)/sizes[idx].sum(axis=1);keep=[j for j,p in enumerate(pids) if p!='FV_012'];de=d[keep];be=de[rng.integers(0,len(de),size=(N,len(de)))].mean(axis=1)
 comparisons[key]={'paired_difference':float(d.mean()),'pair_cluster_percentile_95_CI':list(map(float,np.quantile(boot,[.025,.975]))),'improved_pairs':int((d==1).sum()),'worsened_pairs':int((d==-1).sum()),'unchanged_pairs':int((d==0).sum()),'exact_two_sided_discordant_pair_p':float(binomtest(int((d==1).sum()),int((d!=0).sum()),.5).pvalue) if (d!=0).sum() else 1.,'source_group_19_cluster_95_CI':list(map(float,np.quantile(source,[.025,.975]))),'posthoc_FV012_exclusion_sensitivity':{'n_pairs':19,'baseline_successes':int(b[keep].sum()),'repair_successes':int(f[keep].sum()),'paired_difference':float(de.mean()),'pair_cluster_95_CI':list(map(float,np.quantile(be,[.025,.975])))}}
for c in cells.values():
 for group in ['language_rows','category_language_rows']:
  for value in c[group].values():value.pop('exact_95_CI',None)
summary={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'answer_calls':80,'translation_successes':20,'judge_calls':0,'conditions':cells,'comparisons':comparisons,'bootstrap_replicates':N,'bootstrap_seed':20261101,'endpoint':'Success of both languages against frozen component rubric, language, source support and exact citation-label format','provenance':'All 80 answers inspected locally with AI assistance, unblinded, pending human confirmation. AI-authored fresh inputs after development exposure; not independent external validation.','source_scope':'Archived text only; current law not established.','posthoc_reference_scope_issue':'FV012 wording may encompass Article31 site data and Article30 GMP documentation beyond Article17 frozen core. Original references/scores unchanged; exclude this pair in separately labelled sensitivity.','retrieval':json.loads((A/'retrieval_summary.json').read_text())};(A/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));shutil.copy2('/private/tmp/summarize_fresh_validation.py',O/'summarize_fresh_validation.py');shutil.copy2('/private/tmp/audit_fresh_completed.py',O/'audit_fresh_completed.py');print(json.dumps(summary,indent=2))
