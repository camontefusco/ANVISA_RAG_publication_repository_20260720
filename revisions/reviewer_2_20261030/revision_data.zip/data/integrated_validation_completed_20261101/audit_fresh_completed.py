from pathlib import Path
import json,csv,re,unicodedata,hashlib,datetime
O=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/integrated_repair_validation_20261031')
G=O/'answer_generations_80'; A=O/'analysis_20261101';A.mkdir(exist_ok=True)
I={x['call_id']:x for x in map(json.loads,(G/'generation_inputs_80.jsonl').read_text().splitlines())}
R={x['id']:x for x in map(json.loads,(O/'fresh_references_40_FROZEN.jsonl').read_text().splitlines())}
def grams(s):
 s=''.join(c for c in unicodedata.normalize('NFD',s.lower()) if not unicodedata.combining(c));w=re.findall(r'\w+',s);return set(tuple(w[i:i+5]) for i in range(len(w)-4))
rows=[]
for x in I.values():
 r=R[x['id']]; gold=set(r['gold_citations']);labels={z['citation'] for z in x['selected_evidence']};positive=r['category']!='unanswerable';g=set().union(*(grams(t) for t in r['source_evidence'])) if positive else set();t=grams(x['context']);rows.append({k:x[k] for k in ['id','pair_id','condition','language']}|{'category':r['category'],'all_reference_article_labels':gold<=labels if positive else '', 'reference_5gram_coverage':len(g&t)/len(g) if g else '', 'context_characters':len(x['context']),'selected_passages':len(x['selected_evidence'])})
with (A/'retrieval_80.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
summary={}
for c in ['original_baseline','integrated_repair']:
 z=[x for x in rows if x['condition']==c and x['category']!='unanswerable'];summary[c]={'n_positive_language_rows':len(z),'all_reference_article_labels':sum(x['all_reference_article_labels'] for x in z),'complete_reference_5gram_coverage':sum(x['reference_5gram_coverage']==1 for x in z),'mean_context_characters':sum(x['context_characters'] for x in rows if x['condition']==c)/40}
(A/'retrieval_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if (G/'results_checkpoint.jsonl').exists():
 answers={x['call_id']:x for x in map(json.loads,(G/'results_checkpoint.jsonl').read_text().splitlines())}
 for pair in sorted({x['pair_id'] for x in I.values()}):
  text=[]
  for cid,i in sorted(I.items()):
   if i['pair_id']!=pair or not answers.get(cid,{}).get('answer'):continue
   x=answers[cid];text.append(json.dumps({'call_id':cid,'question':i['question'],'reference_components':R[i['id']]['required_components'],'unavailable_detail':R[i['id']]['unavailable_detail'],'reference_source':R[i['id']]['source_evidence'],'answer':x['answer']},ensure_ascii=False))
  (A/(pair+'_review.jsonl')).write_text('\n'.join(text)+'\n')
