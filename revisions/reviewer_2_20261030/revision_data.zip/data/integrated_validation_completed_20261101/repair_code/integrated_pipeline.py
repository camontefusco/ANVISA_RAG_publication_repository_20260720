from pathlib import Path
from typing import Any
import os,sys,json,ast,re,types,hashlib,importlib.util,collections
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4');sys.dont_write_bytecode=True
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');ROOT=B/'repository';R=ROOT/'revisions/reviewer_2_20261021';O=R/'outputs/integrated_repair_validation_20261031';C=O/'repair_code';L=O/'local_assets';sys.path.insert(0,str(ROOT))
import numpy as np,torch
from transformers import AutoTokenizer,AutoModel
from llama_index.core.schema import TextNode,NodeWithScore,MetadataMode,QueryBundle
from src.retrieval import HybridRetriever,extract_document_reference
M=B/'historical_workspace/Rag_project/embedding_cache/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/c9745ed1d9f207416be6d2e6f8de32d1f16199bf';CACHE=R/'outputs/DR8_clinical_pilot_20261024/model_cache/hub/models--cross-encoder--mmarco-mMiniLMv2-L12-H384-v1/snapshots/1427fd652930e4ba29e8149678df786c240d8825'
class Pipeline:
 def __init__(self):
  torch.set_num_threads(4);self.tok=AutoTokenizer.from_pretrained(str(M),local_files_only=True);self.model=AutoModel.from_pretrained(str(M),local_files_only=True).eval()
  old=json.loads((B/'historical_workspace/Rag_project/vector_store/docstore.json').read_text())['docstore/data'];oldnodes={i:TextNode(**v['__data__']) for i,v in old.items()};oldvectors=json.loads((B/'historical_workspace/Rag_project/vector_store/default__vector_store.json').read_text())['embedding_dict'];new=[TextNode(**x) for x in json.loads((L/'repaired_nodes_LOCAL_ONLY.json').read_text())];newvec=np.load(L/'repaired_vectors_LOCAL_ONLY.npy');self.sets={}
  for name,nodes,vec in [('original_baseline',oldnodes,oldvectors),('integrated_repair',{n.node_id:n for n in new},{n.node_id:v for n,v in zip(new,newvec)})]:
   ids=sorted(nodes);matrix=np.array([vec[i] for i in ids],dtype=np.float32);matrix/=np.linalg.norm(matrix,axis=1,keepdims=True);owner=self
   class Dense:
    def __init__(self,ids,nodes,matrix):self.ids=ids;self.nodes=nodes;self.matrix=matrix
    def retrieve(self,q):
     q=q.query_str if isinstance(q,QueryBundle) else q;scores=self.matrix@owner.encode([q])[0];rank=sorted(range(len(self.ids)),key=lambda n:(-float(scores[n]),self.ids[n]))[:100];return [NodeWithScore(node=self.nodes[self.ids[n]],score=float(scores[n])) for n in rank]
   dense=Dense(ids,nodes,matrix)
   class Index:
    def __init__(self,nodes,dense):self.docstore=types.SimpleNamespace(docs=nodes);self.dense=dense
    def as_retriever(self,**kw):return self.dense
   retr=HybridRetriever(Index(nodes,dense),100,100,100,60,str(CACHE),5,8);self.sets[name]={'nodes':nodes,'retriever':retr}
  module=ast.parse((ROOT/'src/model_loader.py').read_text());tr=next(x for x in module.body if isinstance(x,ast.ClassDef) and x.name=='Translator');gl=next(x for x in module.body if isinstance(x,ast.ClassDef) and x.name=='GlossaryQueryRewriter');assignment=lambda c:next(x for x in c.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REGULATORY_GLOSSARY' for t in x.targets));base=ast.literal_eval(assignment(tr).value);scope={'Translator':types.SimpleNamespace(REGULATORY_GLOSSARY=base)};gloss=eval(compile(ast.Expression(assignment(gl).value),'glossary','eval'),scope);method=next(x for x in gl.body if isinstance(x,ast.FunctionDef) and x.name=='rewrite');scope={'re':re};exec(compile(ast.Module(body=[method],type_ignores=[]),'rewrite','exec'),scope);self.rewrite=lambda q:scope['rewrite'](types.SimpleNamespace(REGULATORY_GLOSSARY=gloss),q)
  source=ast.parse((ROOT/'evaluation/publication_eval.py').read_text());wanted=['metadata_value_from_node','node_text','should_expand_article_context','expanded_context_pairs'];expr=next(x for x in source.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTEXT_EXPANSION_RE' for t in x.targets));ns={'Any':Any,'HybridRetriever':object,'MetadataMode':MetadataMode,'re':re};exec(compile(ast.Module(body=[expr]+[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in wanted],type_ignores=[]),'context_functions','exec'),ns);self.old_context=ns['expanded_context_pairs']
  prompttree=ast.parse((ROOT/'src/prompts.py').read_text());assign=next(x for x in prompttree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REGULATORY_QA_TEMPLATE' for t in x.targets));self.original_template=ast.literal_eval(assign.value.args[0].func.value).strip()
 @torch.inference_mode()
 def encode(self,texts):
  inp=self.tok(texts,padding=True,truncation=True,max_length=512,return_tensors='pt');inp.pop('token_type_ids',None);v=self.model(**inp).last_hidden_state[:,0];return torch.nn.functional.normalize(v,p=2,dim=1).cpu().numpy()
 def prepare(self,x,condition,translation=None):
  s=self.sets[condition];r=s['retriever'];q=x['question'];query=self.rewrite(q) if condition=='original_baseline' and x['language']=='en' else translation if x['language']=='en' else q;assert query;candidates=r.retrieve_fused(query)
  if condition=='integrated_repair':
   requested=extract_document_reference(q)
   if requested:candidates=[z for z in candidates if z.node.metadata.get('regulation_id')==requested]
  ranked=r.rerank(q if condition=='original_baseline' else query,candidates)
  if condition=='original_baseline':pairs=self.old_context(r,ranked,q);context='\n\n'.join('['+c+']\n'+t for c,t in pairs);prompt=self.original_template.format(context_str=context,query_str=q);selected=[{'citation':c,'text':t} for c,t in pairs]
  else:
   nodes=s['nodes'];lookup=collections.defaultdict(list)
   for n in nodes.values():lookup[(n.metadata['source_document'],n.metadata['source_block_index'])].append(n)
   selectednodes=[];seen=set()
   for z in ranked:
    m=z.node.metadata;key=(m['source_document'],m['source_block_index'])
    for offset in [0,-1,1]:
     neighbors=lookup.get((key[0],key[1]+offset),[])
     if offset and neighbors:
      a=re.search(r'Art\. (\d+)',m['article']);b=re.search(r'Art\. (\d+)',neighbors[0].metadata['article'])
      if not(a and b and abs(int(a[1])-int(b[1]))==1):continue
     for n in sorted(neighbors,key=lambda n:int(n.metadata['article_chunk_index'])):
      if n.node_id not in seen:selectednodes.append(n);seen.add(n.node_id)
   selected=[{'citation':n.metadata['citation_label'],'text':n.text,'node_id':n.node_id,'source_block_index':n.metadata['source_block_index']} for n in selectednodes];context='\n\n'.join('['+z['citation']+']\ncitation_label: '+z['citation']+'\n'+z['text'] for z in selected);lang='English' if x['language']=='en' else 'Portuguese';refusal='The retrieved documents do not provide enough information to answer.' if x['language']=='en' else 'Os documentos recuperados nao fornecem informacao suficiente para responder.';prompt=(C/'answer_prompt_prefix.txt').read_text()+'Retrieved context:\n---------------------\n'+context+'\n---------------------\n\nQuestion: '+q+'\nAnswer:\nFinal response language: '+lang+'. Quoted source text is evidence, not a response-language instruction. If no requested fact is supported, output exactly: '+refusal
  return {'id':x['id'],'pair_id':x['pair_id'],'language':x['language'],'question':q,'condition':condition,'retrieval_query':query,'candidate_ids':[z.node.node_id for z in candidates],'ranked_node_ids':[z.node.node_id for z in ranked],'selected_evidence':selected,'context':context,'context_sha256':hashlib.sha256(context.encode()).hexdigest(),'prompt':prompt,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest()}
