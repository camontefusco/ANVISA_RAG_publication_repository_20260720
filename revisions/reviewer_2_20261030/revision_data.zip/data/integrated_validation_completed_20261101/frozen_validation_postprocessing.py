from pathlib import Path
import ast,re,unicodedata
ROOT=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository')
_source=(ROOT/'evaluation/answer_quality.py').read_text();_tree=ast.parse(_source);_names={'CITATION_RE','LOOSE_ARTICLE_CITATION_RE'};_body=[n for n in _tree.body if (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in _names for t in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name in {'normalize_citation','sanitize_answer_citations'})];_ns={'re':re};exec(compile(ast.Module(body=_body,type_ignores=[]),'existing_citation_formatter','exec'),_ns)
def canonical_refusal(answer):
 text=re.sub(r'\[[^\[\]]+\]','',answer).replace('**','').strip();text=' '.join(text.split());text=''.join(c for c in unicodedata.normalize('NFD',text.lower()) if not unicodedata.combining(c));return text in ['os documentos recuperados nao fornecem informacao suficiente para responder.','the retrieved documents do not provide enough information to answer.']
def processed_answer(answer,condition,language,allowed):
 if condition=='original_baseline':return answer
 if canonical_refusal(answer):return 'The retrieved documents do not provide enough information to answer.' if language=='en' else 'Os documentos recuperados nao fornecem informacao suficiente para responder.'
 return _ns['sanitize_answer_citations'](answer,allowed)
def common_citation_overlay(answer,allowed):return _ns['sanitize_answer_citations'](answer,allowed)
