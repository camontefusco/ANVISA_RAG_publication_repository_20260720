from pathlib import Path
import csv,json,re,unicodedata
R=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021');O=R/'outputs/ethics_prompt_control_test_20261028';P=R/'outputs/four_refusal_context_test_20261028'
members=list(csv.DictReader((O/'condition_membership_54.csv').open()));new={x['call_id']:x for x in map(json.loads,(O/'generations_36_new.jsonl').read_text().splitlines())};old={x['call_id']:x for x in map(json.loads,(P/'generations_39.jsonl').read_text().splitlines())};inputs={x['input_id']:x for x in map(json.loads,(O/'frozen_inputs_18.jsonl').read_text().splitlines())}
def norm(t):return ''.join(c for c in unicodedata.normalize('NFKD',t.lower()) if not unicodedata.combining(c))
out=[]
for m in members:
 source=old if m['reuse_previous_call']=='True' else new
 if m['call_id'] not in source:continue
 x=source[m['call_id']];a=x['answer'];n=norm(a).strip();canonical=n.rstrip('.!') in ['os documentos recuperados nao fornecem informacao suficiente para responder','the retrieved documents do not provide enough information to answer'];neg=bool(re.match(r'^(?:\*\*)?(?:no|nao)\b',n));cites=re.findall(r'\[([^\[\]]+)\]',a)
 out.append(dict(m,answer=a,canonical_refusal=canonical,negative_opening=neg,citations=';'.join(cites),cited_negative_candidate=neg and bool(cites),modelVersion=x['modelVersion'],raw_file=x['raw_file'],raw_root=str(P if source is old else O),AI_support_assessment='pending full-text inspection',inspection_reason='',language_flag=''))
with (O/'all_condition_answers_54.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
summary=[]
for iid,inp in inputs.items():
 rr=[x for x in out if x['input_id']==iid];summary.append({'id':inp['id'],'variant':inp['variant'],'prompt_condition':inp['prompt_condition'],'context_condition':inp['context_condition'],'outputs':len(rr),'canonical_refusals':sum(x['canonical_refusal'] for x in rr),'cited_negative_candidates':sum(x['cited_negative_candidate'] for x in rr),'reused_outputs':sum(x['reuse_previous_call']=='True' for x in rr)})
with (O/'per_condition_counts.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
(O/'answer_inspection.txt').write_text('\n\n'.join(x['id']+' '+x['variant']+' '+x['prompt_condition']+' '+x['context_condition']+' r'+x['repeat']+'\n'+x['answer'] for x in out))
print('records',len(out),'new',len(new));print(json.dumps(summary,indent=2))
