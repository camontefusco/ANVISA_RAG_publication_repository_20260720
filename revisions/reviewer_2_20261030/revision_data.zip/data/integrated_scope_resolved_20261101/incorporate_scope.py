from pathlib import Path
import ast,datetime,re,difflib,json,shutil
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/integrated_validation_completed_20261101';N=R/'outputs/integrated_scope_resolved_20261101';D=N/'documents';shutil.copytree(O/'documents',D,dirs_exist_ok=True)
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=17000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
review='The corresponding author personally confirmed 44 outputs from 11 bilingual pairs in an unblinded review on 1 November 2026. The remaining 36 outputs from nine pairs received local AI quality review only. The new comparison therefore lacks complete human confirmation and independent external validation.'
scope='A post hoc reference-scope audit established that FV_012\'s broad manufacturer/site and GMP question requires Articles 30 VIII-IX and 31 I-III as well as Article 17 of archived RDC 55/2010. These additional requirements cover cell-bank manufacturer/storage and batch-certificate issuer details, together with Anvisa and manufacturing-country authority GMP certificate copies. Only the repaired English answer supplied the expanded scope. Applying this scope reduced bilingual success to 13/20 baseline and 17/20 repaired pairs, retaining a four-pair difference. This is an output-informed sensitivity analysis; the frozen references and primary 14/20 versus 18/20 results remain unchanged.'
limits='Current-law verification and reevaluation remain incomplete; these experiments support archived-corpus findings rather than current regulatory accuracy. Independent external validation and no-retrieval or official-site answer-quality baselines remain absent. The repaired staffing and ruminant-derived-documentation questions still failed in both languages despite supported evidence. These retained failures limit the repair rather than requiring successful correction of every case before reporting.'
changed=[]
for name in ['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_integrated_validation_S40.docx','supplementary_information_revised.docx']:
 d=Document(D/name);tracked=name=='manuscript_tracked.docx'
 for p in d.paragraphs:
  old=acc(p._p);new=old
  new=new.replace('These new references and assessments await human confirmation; this is a prospective AI-authored comparison, not independent external validation (S40).',review+' This is a prospective AI-authored comparison (S40).')
  new=new.replace('The new assessments are provisional and unblinded. A post hoc FV_012 scope concern and a shared-source sensitivity are documented in S40; no frozen reference, historical score or Howard rating was replaced.','The assessments are unblinded and only partly human-confirmed. '+scope+' Shared-source sensitivity is documented in S40; no historical score or Howard rating was replaced.')
  new=new.replace('AI-authored inputs and unconfirmed local assessments limit generalization.','AI-authored inputs and incomplete human confirmation limit generalization.')
  if name.startswith('manuscript') and old.startswith('The integrated repair showed a favorable descriptive result'):new+=' '+limits
  if name=='response_to_reviewer_2.docx' and 'These new references and locally AI-assisted assessments are unblinded and still require human confirmation;' in old:
   new=old.replace('These new references and locally AI-assisted assessments are unblinded and still require human confirmation; we do not describe this as independent validation.',review)
  if name=='response_to_reviewer_2.docx' and old.startswith('We retain the negative results'):
   new+=' '+scope+' '+limits
  if name=='supplementary_integrated_validation_S40.docx':
   new=new.replace('All new reference and answer assessments remain provisional, unblinded and pending human confirmation.',review)
   if old.startswith('A post hoc source review identified'):new=scope+' Excluding the entire disputed pair yields 13/19 versus 17/19 under the primary endpoint; the previously reported exclusion sensitivity is retained separately.'
   new=new.replace('The earlier author confirmation and Howard ratings do not cover these newly generated answers or newly authored references. All 80 outputs have local AI-assisted, unblinded component assessments; human confirmation remains pending.',review)
   if old.startswith('The new experiment supports a favorable descriptive bundled-pipeline result'):new+=' '+limits
   new=new.replace('These new references and assessments await human confirmation; this is a prospective AI-authored comparison, not independent external validation.',review)
  if name=='supplementary_information_revised.docx':new=new.replace('New references and local AI-assisted assessments await human confirmation; no independent external validation is claimed.',review+' The expanded FV_012 sensitivity gives 13/20 versus 17/20; frozen results are preserved. Current-law reevaluation and additional baselines remain incomplete.')
  if new!=old:
   if tracked:redline(p._p,rej(p._p),new)
   else:p.text=new
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 assert not any('\u2013' in acc(p._p) or '\u2014' in acc(p._p) for p in d.paragraphs)
 d.save(D/name);changed.append(name)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True)
assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(N/'document_projection_QA.json').write_text(json.dumps(dict(accept_matches_clean=True,reject_matches_original_submission=True,changed=changed),indent=2))
shutil.copytree(O/'bulk_quality_review_20261101',N/'scope_review',dirs_exist_ok=True)
(N/'REVISION_STATUS.md').write_text('# Scope-resolved revision\n\nThe five cumulative Word files incorporate expanded FV012 scope as a post hoc sensitivity (13/20 versus 17/20), frozen primary results (14/20 versus 18/20), 44 author-confirmed versus 36 AI-only reviewed outputs, retained refusal failures, and explicit current-law, independent-validation and baseline limitations. Prior version preserved in integrated_validation_completed_20261101. Rendering QA and promotion pending.\n')
print(N)
