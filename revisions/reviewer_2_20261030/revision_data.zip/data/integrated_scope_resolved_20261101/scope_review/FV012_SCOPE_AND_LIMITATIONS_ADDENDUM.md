# FV_012 scope resolution and retained limitations

1 November 2026

## Scope decision

For the broad archived-corpus question, the reference should include RDC 55/2010 Articles 17, 30 VIII-IX and 31 I-III. Article 17 provides the manufacturer categories, batch-release site and GMP compliance/Anvisa certificate requirements. Article 31 adds the cell-bank manufacturer and storage site and the issuer of the finished-batch release certificate. Article 30 adds copies of both Anvisa and competent manufacturing-country authority GMP certificates. Limiting the reference to Article 17 is insufficient for this broad wording.

This is a post hoc analytical scope correction made after observing the answers. It is not a change to the frozen primary endpoint and is not a new claim of personal human review. The prior 44 personal assessments remain distinct from the remaining 36 AI quality assessments.

Under the expanded scope, only IRH_051 is complete. IRH_032 and IRH_074 omit the manufacturing-country authority certificate; IRH_052 additionally omits the Article 31 site/issuer details. Missing information in selected baseline passages is an evidence-selection limitation, not evidence of unsupported generation. Frozen question wording, references, answers and scores remain preserved.

## Manuscript insertion

A post hoc reference-scope audit identified one broadly worded registration question (FV_012) whose frozen reference covered Article 17 but omitted relevant manufacturer/site and GMP documentation requirements in Articles 30 and 31 of archived RDC 55/2010. Requiring these additional elements reduced bilingual task success from 14/20 to 13/20 for the baseline and from 18/20 to 17/20 for the integrated repair. The difference remained four pairs (20 percentage points). The frozen-reference results remain the primary analysis; the expanded-scope results are a sensitivity analysis informed by inspection of the completed outputs. Neither analysis establishes current regulatory accuracy.

The integrated repair continued to refuse supported information in two partly answerable bilingual questions: the staffing criterion compatible with pharmacovigilance activities and the requirement for documentation controlling transmissible spongiform encephalopathy when ruminant-derived materials are used. Both questions also requested an unavailable exact detail. These failures demonstrate that complete selected evidence and revised instructions did not eliminate blanket refusal of supported content.

Current-law verification and reevaluation remain incomplete. All experimental conclusions concern the archived corpus. The validation was author-led and does not constitute independent external validation; the remaining bulk quality review was AI-assisted rather than personal human confirmation. No no-retrieval or official-site comparison was performed, so the contribution of retrieval relative to those baselines remains unmeasured.

## Reviewer response insertion

We audited reference scope and retained unresolved failures rather than interpreting the repair as uniformly successful. For FV_012, Articles 30 and 31 add relevant requirements beyond the original Article 17 reference. We preserve the frozen analysis (14/20 baseline versus 18/20 repaired bilingual pairs) and report a post hoc expanded-scope sensitivity (13/20 versus 17/20). We explicitly report the persistent staffing and ruminant-derived-documentation refusal failures. We also state that current-law verification and reevaluation are incomplete, that these results concern the archived corpus, and that independent external validation and additional no-retrieval/official-site baselines are absent. These limitations have not been resolved by the experiment. Human and AI review provenance is reported separately.

## Publication handling

Use both results with their scope and timing labels. Do not replace frozen gold, relabel the post hoc analysis as prespecified, attribute the bulk review to Howard or the corresponding author, describe the test as independent, or claim verified current law. Further failure correction is not required to report this bounded experiment. This addendum supplies manuscript and response-letter wording; incorporation into the cumulative Word submission package and its tracked version is still pending.
