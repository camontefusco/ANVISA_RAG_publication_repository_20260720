# Bulk quality review of FV_012 to FV_020

Date: 1 November 2026. Reviewer: Codex AI. All nine remaining bilingual pairs and 36 primary pipeline outputs were inspected against their questions, archived source quotations, frozen components and selected evidence. This is an unblinded AI quality review, not personal human confirmation. The author's 44 prior assessments remain unchanged. Original references, raw answers, formatter outputs and frozen scores remain unchanged.

## Findings

| Pair | Finding |
|---|---|
| FV_012 | All four satisfy the narrow frozen Article 17 core. The broad question also calls for Article 31 I-III site/issuer details and Article 30 VIII-IX certificate copies. Only IRH_051 supplies the full expanded scope. Treat the expanded interpretation as a post hoc sensitivity, pending author adjudication. |
| FV_013 | IRH_034, IRH_039 and IRH_062 provide supported sponsor/distribution/disposal information and identify the unavailable reserve percentage. IRH_022 gives an incomplete blanket refusal. |
| FV_014 | All four fail completeness: the staffing criterion is supported, but each refuses the whole question and does not identify the unavailable exact minimum. |
| FV_015 | IRH_041 and IRH_047 correctly separate supported responsibility from the unavailable algorithm. IRH_031 and IRH_045 refuse supported content; IRH_031 also answers an English question in Portuguese. |
| FV_016 | All four fail completeness: EET/TSE documentation under applicable legislation is supported, but each refuses everything rather than identifying the missing form code. |
| FV_017 | All four appropriately decline to invent an exact emergency-procedure duration. |
| FV_018 | All four appropriately decline to invent a maximum file size. |
| FV_019 | All four appropriately decline to invent an exact minimum TLS version. |
| FV_020 | All four appropriately decline to invent a numerical panel quorum. |

## Reference-scope evidence for FV_012

Article 17 names all manufacturer categories and the batch-release site and requires GMP compliance and an Anvisa-issued CBPF. Article 31 I-III additionally identifies the cell-bank manufacturer/storage site and issuer of the finished-batch release certificate. Article 30 VIII requires an Anvisa certificate copy; IX additionally requires a certificate copy issued by the competent authority in the manufacturer's country. These latter details are relevant to the broad wording, even though excluded from the frozen core reference. The baseline Article 30 excerpt stops before the complete IX clause, so an omission can reflect missing selected evidence; it must not be interpreted automatically as hallucination or refusal error. Article 31 I-III is present in both conditions. This concerns the archived text only, without a current-law conclusion.

## Results and limits

The frozen primary bilingual result remains 14/20 baseline versus 18/20 integrated repair. An expanded-scope sensitivity for FV_012 yields 13/20 versus 17/20; the difference remains four pairs (20 percentage points). This scope interpretation is an AI recommendation, not an approved replacement gold. Excluding the disputed pair gives 13/19 versus 17/19. No new generation or judge calls were run. No changes were made to the manuscript's established frozen results.

Human confirmation is complete for 11 pairs/44 outputs, with 9 pairs/36 outputs reviewed by AI only. A full-human-review claim would therefore be inaccurate. The remaining prompt failures, reference ambiguity, limited sample and author-led provenance remain limitations. Generic refusals can be appropriate on the unanswerable items while failing on partly answerable items.
