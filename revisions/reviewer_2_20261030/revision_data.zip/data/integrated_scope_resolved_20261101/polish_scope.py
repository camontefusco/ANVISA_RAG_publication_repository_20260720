from pathlib import Path
from docx import Document
P=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/integrated_scope_resolved_20261101/documents')
d=Document(P/'supplementary_information_revised.docx')
p=d.paragraphs[-1];p.text='S39 documents the retrospective reference-scope correction. S40 reports the 80-answer integrated-repair comparison, including raw and processed results, retained failures and uncertainty. The author confirmed 44 outputs; 36 received AI review only. FV_012 expanded-scope sensitivity gives 13/20 versus 17/20; frozen scores are preserved. Current-law reevaluation, independent validation and additional baselines remain incomplete.'
d.save(P/'supplementary_information_revised.docx')
d=Document(P/'supplementary_integrated_validation_S40.docx')
for p in d.paragraphs:
 if p.text.startswith('The new experiment supports a favorable descriptive bundled-pipeline result'):
  p.text='The bundled pipeline showed a favorable descriptive result with a material formatting contribution. The staffing and ruminant-documentation refusals remain failures. The corresponding author confirmed 44 outputs; the other 36 received AI review only. Independent external validation, current-law verification and reevaluation, and no-retrieval or official-site answer-quality baselines remain absent. Further pipeline changes would consume this test as development data. We stop this bounded comparison without tuning the frozen inputs or replacing its negative results.'
 if p.text.startswith('A daily-quota error stopped'):
  p.text='A daily-quota error stopped the initial run on 31 October after eight translations. Resumption reused successful calls. The 20 translations required 22 attempts (one quota response and one connection error); all 80 answers succeeded on their first attempt. Calls used a shared 4.3-second throttle and at most three attempts. References, Howard ratings and author details were not sent. No judge, repair, billing or model changes were made. The recorded translation of technical panels as câmaras técnicas was retained without manual correction.'
 if p.text.startswith('The experimental pipeline was frozen'):
  p.text=p.text.replace('Human confirmation of the original 481-node index and component reference scope is pending.','Human confirmation is incomplete.')
d.save(P/'supplementary_integrated_validation_S40.docx')
d=Document(P/'response_to_reviewer_2.docx')
for p in d.paragraphs:
 if p.text.startswith('Under the primary definition'):
  start=p.text.find('A post hoc reference-scope audit');end=p.text.find(' Shared-source sensitivity')
  if start>=0 and end>start:p.text=p.text[:start]+p.text[end+1:]
d.save(P/'response_to_reviewer_2.docx')
