Historical data S1 and S2

The relabelled files preserve the 404 historical answer and judge rows. Repair sets reuse the internal baseline; stress-test content informed calibration. The current_adjudication directory provides a separate overlay, not overwritten historical scores. New author ratings are in Howard40_review. Literal model prompts, generated answers and initial rating fields retain their original spelling and punctuation.
