# Controlled follow-up of partial-answer failures

Completed 31 October 2026. All 213 planned unique generations completed in 215 HTTP attempts. There were 219 logical condition records, six cross-family exact-prompt reuses, and 12 additional identical factorial cells reused rather than regenerated. No external judge calls were made. All prompt hashes match the frozen inputs.

The fixed protocol tested two policies with saved, direct-clause and length-matched unrelated contexts; source language and English reminders; final citation validation; and direct evidence with related or unrelated distractors. There were three new repeats per distinct fixed condition. The model was gemini-3.5-flash-lite at temperature 0.2.

## Policy contribution

Supported in the selected cases. AV_015 EN and PT returned canonical refusals in 6/6 original saved-context responses and supported update triggers plus electronic submission and the absent deadline in 6/6 revised responses. The same 0/6 versus 6/6 content contrast recurred with unrelated appended text. No evidence was missing for those requested supported components.

Limits: Wording and length changed together; author review of these new outputs is pending.

## Missing clauses rather than added length

Supported in selected cases. Under the revised policy, AV_014 EN and PT refused in 6/6 saved and 6/6 unrelated length-control responses; all 6/6 direct-clause responses stated the literature evidence requirement. AV_013 PT supplied the seven API categories in 3/3 direct-clause responses and 0/3 saved and 0/3 sham responses.

Limits: This is component recovery, not full-task success. AV_014 EN omitted the general phase-3 and known-safety/minimal-risk framing; PT outputs did not explicitly identify missing indexing databases. AV_013 stated the complementary-act deferral explicitly in only 1/3 PT direct responses and 0/3 EN direct responses.

## Refusal citation instruction

Supported local repair with trade-off in removal arm. Original final validation yielded cited canonical refusals in 8/9 responses. An explicit refusal branch yielded 0/9, with all 9 remaining canonical refusals in the requested language. Removing final validation yielded 3 cited canonical refusals among 6 canonical refusals; the other 3 responses were Portuguese explanations to an English question.

Limits: Nine generations per arm on three selected questions; no independent test or human rating. Removal is not a safe general repair.

## Portuguese source language alone

No incremental effect demonstrated. All 36 minimal-context responses were English, including 12/12 using Portuguese source text. English translation and an additional English reminder provided no observed language improvement.

Limits: Floor effect. These shorter contexts differ from the saved full contexts; translation, source complexity and instruction interactions remain unresolved. Translations were AI prepared, not human verified.

## Distractor interference and relevance guard

Direct evidence helped; guard alone failed. AV_008 EN answered the contingency-plan task in all 18 direct-evidence responses, including related distractors and unrelated length controls. All 6 saved-context responses without Article 9 discussed the Risk Minimization Plan instead. The requested-subject guard failed in all 3 saved-context repeats.

Limits: Article 9 was placed first in the supplemented arms. Other positions and larger distractor loads were not tested; related-content interference cannot be excluded generally.

## Stochastic variation

Qualitative variation persists. With identical original-policy AV_016 EN sham prompts, one repeat returned an English partial answer, one a Portuguese partial answer and one a canonical refusal. Original-policy AV_016 PT direct support produced two Portuguese substantive answers and one mixed-language refusal.

Limits: Three repeats characterize these fixed prompts only. Returned model-version identifiers do not establish immutable provider weights.

## Reliable end to end repair

Not established. Complete-support additions did not guarantee all requested content, explicit unavailable-detail statements, correct language and literal citation labels. AV_016 EN revised direct support still answered in Portuguese in one of three repeats.

Limits: Selected known failures; unblinded local AI-assisted inspection; no deployment or change to the original human-reviewed 10/20 pairs.

These are selected development diagnostics. The local AI-assisted inspection is not a new human validation. Raw answers, failed attempts, exact prompts, condition membership and negative findings are preserved. Howard’s original 10/20 bilingual-pair outcome is unchanged. No revised prompt was deployed. Current-law verification and independent validation remain outside this experiment.
