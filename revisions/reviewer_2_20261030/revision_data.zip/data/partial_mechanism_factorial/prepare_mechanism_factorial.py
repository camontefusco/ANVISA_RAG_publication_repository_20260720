from pathlib import Path
import json,csv,re,hashlib,random,datetime,difflib,shutil
import tiktoken
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';F=R/'outputs/author_led_validation_frozen_20261030';P=R/'outputs/partial_answer_prompt_pilot_20261030';O=R/'outputs/partial_mechanism_factorial_20261030';O.mkdir(exist_ok=True);D=R/'outputs/howard_review_20261021/send_to_howard/archived_source_texts';enc=tiktoken.get_encoding('cl100k_base');sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
original={x['id']:x for x in map(json.loads,(F/'generation_payload_40/generation_inputs_40.jsonl').read_text().splitlines())};partial={x['id']:x for x in map(json.loads,(P/'generation_inputs_40.jsonl').read_text().splitlines()) if x['condition']=='partial_answer'}
sources={n:(D/n).read_text() for n in ['RDC_945_2024.txt','IN_338_2024.txt','RDC_751_2022.txt','RDC_406_2020.txt','RDC_55_2010.txt']}
def art(file,n):
 s=sources[file];ms=list(re.finditer(r'(?m)^Art\.\s*(\d+)[^\n]*',s));idx=next(j for j,m in enumerate(ms) if int(m.group(1))==n);return s[ms[idx].start():ms[idx+1].start() if idx+1<len(ms) else len(s)].strip()
def block(label,text):return '['+label+']\ncitation_label: '+label+'\n'+text
contexts={id:x['prompt'].split('Retrieved context:\n---------------------\n',1)[1].rsplit('\n---------------------\n\nQuestion:',1)[0] for id,x in original.items()}
def prompt(id,policy,context):
 p=(original if policy=='original' else partial)[id]['prompt'];prefix=p.split('Retrieved context:\n---------------------\n',1)[0];return prefix+'Retrieved context:\n---------------------\n'+context+'\n---------------------\n\nQuestion: '+original[id]['question']+'\nAnswer:'
pool='\n\n'.join(block('RDC 55/2010, Art. '+str(n),art('RDC_55_2010.txt',n)) for n in range(1,18))
def matched_control(target):
 N=len(enc.encode(target));ts=enc.encode(pool);assert len(ts)>N
 for k in range(N,N-4,-1):
  text=enc.decode(ts[:k])
  if '\ufffd' not in text and abs(len(enc.encode(text))-N)<=2:return text
 raise AssertionError('Cannot construct safe control')
a3=art('IN_338_2024.txt',3);low=a3[a3.index('II - Categoria'):a3.index('III - Categoria')].strip();low=block('IN 338/2024, Art. 3',low)
a28=art('RDC_945_2024.txt',28);api=a28[a28.index('V - dossiê'):a28.index('b) medicamento experimental')].strip();api=block('RDC 945/2024, Art. 28',api);a29=block('RDC 945/2024, Art. 29',art('RDC_945_2024.txt',29))
a12=art('RDC_751_2022.txt',12).split('Seção II')[0].strip();a13=art('RDC_751_2022.txt',13);cert13=a13.split('I - formulário')[0].strip()+'\n'+re.search(r'(?m)^III - .*',a13).group(0)
extras={}
for id in original:
 if id.startswith('AV_013'):extras[id]=a29 if id.endswith('EN') else api+'\n\n'+a29
 if id.startswith('AV_014'):extras[id]=low
 if id.startswith('AV_015'):extras[id]=''
 if id.startswith('AV_016'):extras[id]=block('RDC 751/2022, Art. 13',cert13) if id.endswith('EN') else block('RDC 751/2022, Art. 12',a12)
records=[];logical=[];claims=[]
def add(family,id,policy,condition,ctx,rep,p=None,**extra):
 text=p or prompt(id,policy,ctx);r={'call_id':f'{family}__{id}__{policy}__{condition}__r{rep}','family':family,'id':id,'pair_id':original[id]['pair_id'],'language':original[id]['language'],'policy':policy,'condition':condition,'repeat':rep,'question':original[id]['question'],'context':ctx,'context_sha256':sha(ctx),'prompt':text,'prompt_sha256':sha(text),**extra};records.append(r);return r
# 144 logical factorial cells;12 duplicate complete-support cells for AV015 are reused,132 unique calls.
for id in sorted(extras):
 for policy in ['original','partial_answer']:
  extra=extras[id];sham=matched_control(extra) if extra else block('RDC 55/2010, Art. 1',art('RDC_55_2010.txt',1))
  for rep in [1,2,3]:
   for condition in ['saved','sham_append','complete_support']:
    if condition=='complete_support' and not extra:
     logical.append({'family':'factorial','id':id,'policy':policy,'condition':condition,'repeat':rep,'reuses_call_id':f'factorial__{id}__{policy}__saved__r{rep}'});continue
    ctx=contexts[id]+('\n\n'+(sham if condition=='sham_append' else extra) if condition!='saved' else '')
    r=add('factorial',id,policy,condition,ctx,rep,added_cl100k_tokens=len(enc.encode(sham if condition=='sham_append' else extra)) if condition!='saved' else 0);logical.append({'family':'factorial','id':id,'policy':policy,'condition':condition,'repeat':rep,'reuses_call_id':r['call_id']})
  if extra:claims.append({'id':id,'target_tokens':len(enc.encode(extra)),'control_tokens':len(enc.encode(sham)),'difference':len(enc.encode(sham))-len(enc.encode(extra))})
# Language minimal passages retain source meaning; translations locally prepared, not independently human validated.
pt={'AV_010_EN':block('RDC 751/2022, Art. 11',art('RDC_751_2022.txt',11)), 'AV_016_EN':block('RDC 751/2022, Art. 12',a12)+'\n\n'+block('RDC 751/2022, Art. 13',cert13)}
en={'AV_010_EN':block('RDC 751/2022, Art. 11','Art. 11. Registration of medical devices is valid for 10 (ten) years, counted from the day of its publication in the Official Gazette of the Union, and may be revalidated successively for an equal period, under the terms established in section V of this Resolution.'), 'AV_016_EN':block('RDC 751/2022, Art. 12','Art. 12. Medical devices subject to conformity certification within the Brazilian System for Conformity Assessment (SBAC) may only be imported and marketed if manufactured during the validity of the Certificate of Conformity.')+'\n\n'+block('RDC 751/2022, Art. 13','Art. 13. To submit a notification petition for a medical device, the applicant must pay the corresponding fee and submit the following documents to Anvisa:\nIII - a copy of the Certificate of Conformity issued within the Brazilian System for Conformity Assessment (SBAC), applicable only to devices with compulsory certification listed by Anvisa in specific regulations; and')}
# Match the English evidence length to Portuguese evidence using only semantically empty whitespace/labelled non-evidence padding.
# Padding is an explicitly non-evidence English note and is not a new regulatory fact.
for id in pt:
 N=len(enc.encode(pt[id]));english=en[id];padding='\n\nFormatting note: End of the supplied regulatory excerpts. '
 while len(enc.encode(english+padding))<N:padding+='End of excerpt. '
 tok=enc.encode(english+padding);matched=enc.decode(tok[:N])
 assert '\ufffd' not in matched and english in matched
 for source_lang,ctx in [('Portuguese',pt[id]),('English',english),('English_length_control',matched)]:
  for cue in ['existing_language_rule','reinforced_English']:
   for rep in [1,2,3]:
    p=prompt(id,'partial_answer',ctx)
    if cue=='reinforced_English':p=p.replace('\nAnswer:','\nRequired response language: English. Write the entire response in English while preserving citation labels.\nAnswer:')
    add('language',id,'partial_answer',source_lang+'__'+cue,ctx,rep,p=p,source_language=source_lang,language_cue=cue,context_tokens=len(enc.encode(ctx)))
# Final citation validator intervention, with all other instructions and saved passages fixed.
clear='Final validation: First decide whether the response is the refusal sentence. If it is a blanket refusal, return exactly the language-appropriate refusal sentence from rule 5 with no citation or additional text. Otherwise, cite every material claim using only exact retrieved citation labels; include an article citation when article evidence supports the answer. Do not append a citation to a blanket refusal.\n\n'
for id in ['AV_004_EN','AV_014_EN','AV_014_PT']:
 p=prompt(id,'partial_answer',contexts[id]);start=p.index('Final validation:');end=p.index('Retrieved context:',start)
 for validator in ['original_final_validation','explicit_refusal_branch','no_final_validation']:
  alt=p if validator=='original_final_validation' else p[:start]+(clear if validator=='explicit_refusal_branch' else '')+p[end:]
  for rep in [1,2,3]:add('citation',id,'partial_answer',validator,contexts[id],rep,p=alt,validator=validator)
# Wrong-task probe: correct evidence first; original misleading passages vs equally long irrelevant passages.
id='AV_008_EN';direct=block('RDC 406/2020, Art. 9',art('RDC_406_2020.txt',9));wrong=contexts[id];control=matched_control(wrong)
relevance='Before drafting, identify the exact information requested. Use a passage only when it supports that requested information, rather than merely sharing a topic. Do not replace the requested subject with a different related subject. If no requested information is supported, use the refusal rule.\n'
for name,ctx in [('saved_no_direct',wrong),('direct_only',direct),('direct_plus_saved_distractors',direct+'\n\n'+wrong),('direct_plus_length_control',direct+'\n\n'+control)]:
 for guard in ['existing_rules','requested_subject_check']:
  p=prompt(id,'partial_answer',ctx)
  if guard=='requested_subject_check':p=p.replace('Final validation:',relevance+'\nFinal validation:')
  for rep in [1,2,3]:add('relevance',id,'partial_answer',name+'__'+guard,ctx,rep,p=p,relevance_guard=guard,evidence_condition=name)
assert len(records)==219,(len(records), {f:sum(r['family']==f for r in records) for f in ['factorial','language','citation','relevance']})
# Detect unintended identical prompts across families; reuse each exact prompt and repeat, never pretend duplicates are independent calls.
keys=[(r['prompt_sha256'],r['repeat']) for r in records];duplicates=len(keys)-len(set(keys))
# Original citation saved partial prompts overlap core factorial AV014. Reuse those6 calls (two questions*three repeats).
unique={};execution=[]
for r in records:
 k=(r['prompt_sha256'],r['repeat'])
 if k in unique:r['reuse_call_id']=unique[k]
 else:unique[k]=r['call_id'];r['reuse_call_id']=r['call_id'];execution.append(r)
# 219 logical inputs,213 unique calls after six cross-family exact-prompt reuses.
rng=random.Random(202610301);rng.shuffle(execution)
for i,r in enumerate(execution):r['sequence']=i+1
(O/'all_condition_inputs_219.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records));(O/'execution_inputs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in execution));(O/'factorial_logical_membership_144.json').write_text(json.dumps(logical,indent=2));(O/'token_control_checks.json').write_text(json.dumps(claims,indent=2))
fields=['sequence','call_id','family','id','pair_id','policy','condition','repeat','prompt_sha256']
with (O/'generation_plan.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in execution)
protocol={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generation_calls':len(execution),'logical_inputs':219,'factorial_logical_cells':144,'within_factorial_null_cells_reused':12,'cross_family_exact_prompt_repeat_reuses':duplicates,'judge_calls':0,'model':'gemini-3.5-flash-lite','temperature':.2,'max_attempts_per_call':3,'throttle_seconds':4.3,'random_seed':202610301,'families':{'factorial':{'unique_planned_before_cross_family_reuse':132,'questions':'AV013 to AV016, both languages','conditions':'2prompts x saved/sham-append/complete-support contexts x3 repeats; AV015 complete-support equals saved and is reused','interpretation':'Compare direct-support addition to both saved and length-matched unrelated additions. Compare policy within each evidence context; inspect interaction. Exclude constructed-identical AV015 cells from independent evidence effects.'},'language':{'inputs':36,'questions':'AV010_EN and AV016_EN','conditions':'Portuguese/English/English-length-control evidence x existing/reinforced language cue x3 repeats','interpretation':'Content-preserving minimal passages, locally prepared translations. Length control uses marked non-evidence note, not extra regulatory claims. Not a native tokenizer match or human-validated translation.'},'citation':{'inputs':27,'questions':'AV004_EN and AV014_EN/PT','conditions':'original/explicit-refusal-branch/no-final-validation x3 repeats','interpretation':'Tests effect of final validation wording/removal on cited refusals; does not assume logical contradiction in the original rule; wording and length differ.'},'relevance':{'inputs':24,'question':'AV008_EN','conditions':'saved/direct-only/direct+saved/direct+length-control x existing/requested-subject-check x3 repeats','interpretation':'Direct evidence precedes distractors in both extended arms. Distinguishes absent direct evidence from interference by related passages and relevance guard. Token controls use cl100k, not native provider tokenizer.'}},'hypotheses_and_discriminators':[{'hypothesis':'Blanket-refusal policy suppresses requested supported content','support':'More requested supported content under partial policy with fixed contexts, consistently across repeats','weaken':'No repeat-consistent difference once evidence content is fixed'},{'hypothesis':'Missing required clauses constrain full-task success','support':'Direct missing-clause additions improve completion more than length-control additions','weaken':'Direct complete support does not improve; sufficiency alone cannot explain failure'},{'hypothesis':'Portuguese source language contributes to Portuguese responses to English questions','support':'English or reinforced cue reduces wrong-language responses; compare English length control','weaken':'Failure persists similarly with English evidence or source-language effects inconsistent across repeats'},{'hypothesis':'Final citation validator contributes to citations on bare refusals','support':'Omission or explicit branch reduces prohibited citations on otherwise identical saved-context refusals','weaken':'Failures persist or differences inconsistent; original logical conflict not assumed'},{'hypothesis':'Related passages encourage wrong-task substitution','support':'Correct-plan task completion worse with saved distractors than equally long unrelated text, or generic relevance guard prevents substitution','weaken':'Wrong task persists with direct-only evidence or no repeat-consistent distractor/guard contrast'},{'hypothesis':'Single-run differences reflect generation variability','support':'Within identical prompt/temperature/model conditions show different qualitative outcomes across3new repeats','weaken':'Stable in these3repeats only; does not rule out variability generally'}],'assessment':'Predefined mechanical screens plus local AI-assisted passage-level inspection. No human ratings inferred and no Google judge calls. Original Howard ratings and all earlier primary results unchanged.','reporting':'Preserve each repeat, refusals, omissions, unsupported claims, wrong-task content, language and citation failures. Report selected-case counts and interactions; no population accuracy, independent validation, current-law certification, or post hoc winning-prompt deployment. No extra adaptive calls inside this plan.','quota_stop':'Stop on daily quota/nonretryable errors; retain partial progress. No model substitution, billing change or quota evasion.','source_sha256':{n:sha(s) for n,s in sources.items()},'inputs_sha256':sha((O/'execution_inputs.jsonl').read_text())}
(O/'PROTOCOL_BEFORE_CALLS.json').write_text(json.dumps(protocol,indent=2));(O/'source_translation_pairs.json').write_text(json.dumps({'Portuguese':pt,'English':en,'provenance':'Locally prepared AI-assisted translations of archived passages; no human translation validation'},ensure_ascii=False,indent=2));(O/'human_authorization.json').write_text(json.dumps({'date':'2026-10-30','user_instruction':'i asked for more time so we can continue the testing and try to eliminate each of the supposed explanations','scope':'Bounded controlled follow-up on selected archived questions and regulatory passages. Up to219logical calls, deduplicated by exact prompt/repeat. No references, Howard ratings or judge scores sent; no judge calls, repairs, billing changes or model substitution.','protocol_sha256':sha((O/'PROTOCOL_BEFORE_CALLS.json').read_text())},indent=2));shutil.copy2('/private/tmp/prepare_mechanism_factorial.py',O/'prepare_mechanism_factorial.py')
print(json.dumps({'logical_inputs':219,'unique_generation_calls':len(execution),'cross_family_reuses':duplicates,'families':{f:sum(r['family']==f for r in records) for f in ['factorial','language','citation','relevance']},'token_control_max_difference':max(abs(r['difference']) for r in claims),'payload_tokens':sum(len(enc.encode(r['prompt'])) for r in execution)},indent=2))
