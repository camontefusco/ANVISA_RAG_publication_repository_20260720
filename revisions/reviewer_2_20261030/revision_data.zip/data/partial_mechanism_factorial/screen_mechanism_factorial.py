from pathlib import Path
import json,csv,re,hashlib,unicodedata,collections
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/partial_mechanism_factorial_20261030';A=O/'analysis';A.mkdir(exist_ok=True)
inputs={r['call_id']:r for r in map(json.loads,(O/'execution_inputs.jsonl').read_text().splitlines())};all_conditions=list(map(json.loads,(O/'all_condition_inputs_219.jsonl').read_text().splitlines()));records={r['call_id']:r for r in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())} if (O/'results_checkpoint.jsonl').exists() else {}
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.lower()) if not unicodedata.combining(c))
def concept(s,*patterns):return any(re.search(p,s) for p in patterns)
def features(r):
 x=records[r['reuse_call_id']];a=x['answer'];t=norm(a);bare=norm(re.sub(r'\[[^\]]+\]','',a)).strip().strip('.').strip();ref=bare in ['the retrieved documents do not provide enough information to answer','os documentos recuperados nao fornecem informacao suficiente para responder'];labels=re.findall(r'\[([^\]\n]+)\]',a);allowed=set(re.findall(r'^\[([^\]\n]+)\]$',r['context'],re.M));body=re.sub(r'\[[^\]]+\]','',t);words=re.findall(r'[a-z]+',body)
 en=sum(w in {'the','and','must','is','are','not','with','from','for','which','only','when','this','does','provide','information','under','according','may','that','during','validity','required'} for w in words);pt=sum(w in {'os','as','do','da','dos','das','que','nao','para','com','uma','deve','de','e','em','no','na','pelo','pela','ser','por','quando','durante','somente','informacoes','fornecem','validade'} for w in words);lang='English' if en>pt else 'Portuguese' if pt>en else 'uncertain'
 # Keyword screens are never human ratings or semantic adjudication.
 pfx=r['id'][:6];checks={}
 if pfx=='AV_013':
  checks={'description':concept(t,r'descri',r'description'), 'manufacturing':concept(t,r'fabrica',r'manufactur'),'characterization_impurities':concept(t,r'caracteriza',r'characteriz') and concept(t,r'impur'), 'quality_method_validation':concept(t,r'qualidade',r'quality') and concept(t,r'valida'), 'reference_materials':concept(t,r'padr',r'standard',r'reference material',r'materiais de referencia'), 'packaging':concept(t,r'embal',r'packag'),'stability':concept(t,r'estabilidade',r'stability'), 'complementary_act':concept(t,r'complement',r'supplement') and concept(t,r'29')}
 elif pfx=='AV_014':checks={'meta_analysis':concept(t,r'meta.?an'), 'systematic_reviews':concept(t,r'sistemat',r'systematic'),'indexed_journal':concept(t,r'indexad',r'indexed'),'safety_and_efficacy':concept(t,r'seguranca',r'safety') and concept(t,r'eficacia',r'efficacy'),'phase3':concept(t,r'fase\s*3',r'phase\s*(?:3|iii)'),'known_safety_minimal_risk':concept(t,r'conhecid',r'known') and concept(t,r'minim')}
 elif pfx=='AV_015':checks={'new_safety_data':concept(t,r'seguranca',r'safety') and concept(t,r'nov',r'new'),'unstudied_populations':concept(t,r'popula') and concept(t,r'nao estud',r'not stud',r'unstudied'),'electronic_submission':concept(t,r'eletron',r'electron')}
 elif pfx=='AV_016':checks={'manufactured_during_certificate_validity':concept(t,r'fabricad',r'manufactur') and concept(t,r'vigencia',r'validity'),'certificate_copy_limited_to_compulsory':concept(t,r'copia',r'copy') and concept(t,r'compulsor',r'mandatory')}
 elif pfx=='AV_010':checks={'ten_years':concept(t,r'10',r'ten',r'dez'),'publication':concept(t,r'publica'),'renewal':concept(t,r'revalida',r'revalidat',r'renew')}
 elif pfx=='AV_008':checks={'contingency':concept(t,r'contingenc'), 'software_hardware':concept(t,r'software') and concept(t,r'hardware'),'continuity':concept(t,r'continu'),'pharmacovigilance':concept(t,r'farmacovigil',r'pharmacovigil')}
 return {'answer':a,'answer_sha256':hashlib.sha256(a.encode()).hexdigest(),'canonical_refusal_ignoring_citation':ref,'prohibited_citation_on_canonical_refusal':ref and bool(labels),'exact_citation_label_mismatches':' | '.join(x for x in labels if x not in allowed),'response_language_screen':lang,'language_screen_compliant':lang==('English' if r['id'].endswith('EN') else 'Portuguese'),'English_function_word_count':en,'Portuguese_function_word_count':pt,'requested_concept_screens':json.dumps(checks),'concept_screen_pass_count':sum(checks.values()),'concept_screen_total':len(checks),'risk_minimization_without_contingency_screen':pfx=='AV_008' and concept(t,r'minimiza') and not concept(t,r'contingenc'),'screen_limit':'Mechanical vocabulary/format screens only; not full-task or human ratings.'}
rows=[]
for r in all_conditions:
 if r['reuse_call_id'] not in records or records[r['reuse_call_id']].get('error') or not records[r['reuse_call_id']].get('answer'):continue
 out={k:r[k] for k in ['call_id','family','id','pair_id','policy','condition','repeat','reuse_call_id','prompt_sha256','context_sha256']};out.update(features(r));rows.append(out)
if rows:
 with (A/'condition_rows_with_mechanical_screens.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
groups=collections.defaultdict(list)
for r in rows:groups[(r['id'],r['answer_sha256'])].append(r)
g=[]
for k,rr in sorted(groups.items()):
 x=rr[0];g.append({'group_id':'G'+str(len(g)+1).zfill(3),'id':x['id'],'condition_records':len(rr),'conditions':' | '.join(r['family']+':'+r['policy']+':'+r['condition']+':r'+str(r['repeat']) for r in rr),'language_screen':x['response_language_screen'],'canonical_refusal':x['canonical_refusal_ignoring_citation'],'answer':x['answer'],'mechanical_concepts':x['requested_concept_screens'],'inspection_full_required_content':'','inspection_all_claims_supported':'','inspection_missing_detail_explicit':'','inspection_requested_task_relevance':'','inspection_language':'','inspection_notes':''})
if g:
 with (A/'unique_answers_for_AI_inspection.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=g[0]);w.writeheader();w.writerows(g)
summary={'unique_completed_calls':sum(bool(r.get('answer')) and not r.get('error') for r in records.values()),'unique_planned_calls':len(inputs),'logical_condition_records_available':len(rows),'unique_answer_groups':len(g),'by_family':dict(collections.Counter(r['family'] for r in rows)),'mechanical_screen_not_human_validation':True};(A/'screen_progress.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
