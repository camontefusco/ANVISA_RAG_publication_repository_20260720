from pathlib import Path
import csv,json,collections,hashlib,shutil,ast,re,difflib,datetime
from docx import Document
from docx.shared import Pt,Inches
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/partial_mechanism_factorial_20261030';A=O/'analysis';old=R/'outputs/partial_prompt_interpretation_20261030'
rows=list(csv.DictReader((A/'condition_rows_with_mechanical_screens.csv').open()));groups=list(csv.DictReader((A/'unique_answers_for_AI_inspection.csv').open()));inputs=list(map(json.loads,(O/'execution_inputs.jsonl').read_text().splitlines()));outputs=list(map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines()));out={x['call_id']:x for x in outputs}
assert len(inputs)==len(out)==213 and all(x.get('answer') and not x.get('error') for x in outputs)
for x in inputs:assert x['prompt_sha256']==out[x['call_id']]['prompt_sha256'] and hashlib.sha256(x['prompt'].encode()).hexdigest()==x['prompt_sha256']
attempts=list(map(lambda p:json.loads(p.read_text()),(O/'raw_calls').glob('*.json')));http=collections.Counter(str(x.get('http_status')) for x in attempts)
summary=[]
for key in sorted(set((x['family'],x['policy'],x['condition']) for x in rows)):
 rr=[x for x in rows if (x['family'],x['policy'],x['condition'])==key]
 summary.append(dict(zip(['family','policy','condition'],key))|{'n':len(rr),'canonical_refusals':sum(x['canonical_refusal_ignoring_citation']=='True' for x in rr),'language_screen_compliant':sum(x['language_screen_compliant']=='True' for x in rr),'cited_canonical_refusals':sum(x['prohibited_citation_on_canonical_refusal']=='True' for x in rr),'exact_label_mismatch_outputs':sum(bool(x['exact_citation_label_mismatches']) for x in rr)})
with (A/'condition_summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=summary[0]);w.writeheader();w.writerows(summary)
# Explicit case-level inspection records; no full-task score inferred from keyword counts.
findings=[
('Policy contribution','Supported in the selected cases','AV_015 EN and PT returned canonical refusals in 6/6 original saved-context responses and supported update triggers plus electronic submission and the absent deadline in 6/6 revised responses. The same 0/6 versus 6/6 content contrast recurred with unrelated appended text. No evidence was missing for those requested supported components.','Wording and length changed together; author review of these new outputs is pending.'),
('Missing clauses rather than added length','Supported in selected cases','Under the revised policy, AV_014 EN and PT refused in 6/6 saved and 6/6 unrelated length-control responses; all 6/6 direct-clause responses stated the literature evidence requirement. AV_013 PT supplied the seven API categories in 3/3 direct-clause responses and 0/3 saved and 0/3 sham responses.','This is component recovery, not full-task success. AV_014 EN omitted the general phase-3 and known-safety/minimal-risk framing; PT outputs did not explicitly identify missing indexing databases. AV_013 stated the complementary-act deferral explicitly in only 1/3 PT direct responses and 0/3 EN direct responses.'),
('Refusal citation instruction','Supported local repair with trade-off in removal arm','Original final validation yielded cited canonical refusals in 8/9 responses. An explicit refusal branch yielded 0/9, with all 9 remaining canonical refusals in the requested language. Removing final validation yielded 3 cited canonical refusals among 6 canonical refusals; the other 3 responses were Portuguese explanations to an English question.','Nine generations per arm on three selected questions; no independent test or human rating. Removal is not a safe general repair.'),
('Portuguese source language alone','No incremental effect demonstrated','All 36 minimal-context responses were English, including 12/12 using Portuguese source text. English translation and an additional English reminder provided no observed language improvement.','Floor effect. These shorter contexts differ from the saved full contexts; translation, source complexity and instruction interactions remain unresolved. Translations were AI prepared, not human verified.'),
('Distractor interference and relevance guard','Direct evidence helped; guard alone failed','AV_008 EN answered the contingency-plan task in all 18 direct-evidence responses, including related distractors and unrelated length controls. All 6 saved-context responses without Article 9 discussed the Risk Minimization Plan instead. The requested-subject guard failed in all 3 saved-context repeats.','Article 9 was placed first in the supplemented arms. Other positions and larger distractor loads were not tested; related-content interference cannot be excluded generally.'),
('Stochastic variation','Qualitative variation persists','With identical original-policy AV_016 EN sham prompts, one repeat returned an English partial answer, one a Portuguese partial answer and one a canonical refusal. Original-policy AV_016 PT direct support produced two Portuguese substantive answers and one mixed-language refusal.','Three repeats characterize these fixed prompts only. Returned model-version identifiers do not establish immutable provider weights.'),
('Reliable end to end repair','Not established','Complete-support additions did not guarantee all requested content, explicit unavailable-detail statements, correct language and literal citation labels. AV_016 EN revised direct support still answered in Portuguese in one of three repeats.','Selected known failures; unblinded local AI-assisted inspection; no deployment or change to the original human-reviewed 10/20 pairs.')]
with (A/'hypothesis_findings.csv').open('w') as f:w=csv.writer(f);w.writerow(['hypothesis','finding','evidence','limits']);w.writerows(findings)
record={'complete_unique_generations':213,'logical_condition_records':219,'factorial_logical_cells':144,'reused_identical_factorial_cells':12,'cross_family_reuses':6,'http_attempts':len(attempts),'http_status_counts':dict(http),'returned_model_versions':dict(collections.Counter(x.get('generation_metadata',{}).get('modelVersion','not_recorded') for x in outputs)),'judge_calls':0,'prompt_hashes_verified':True,'evaluation':'Mechanical screens plus local unblinded AI-assisted case inspection; no new human ratings; no overall full-task score computed.','completed_Berlin_date':'2026-10-31','original_Howard_result_changed':False}
(A/'completion_audit.json').write_text(json.dumps(record,indent=2))
report='''# Controlled follow-up of partial-answer failures\n\nCompleted 31 October 2026. All 213 planned unique generations completed in 215 HTTP attempts. There were 219 logical condition records, six cross-family exact-prompt reuses, and 12 additional identical factorial cells reused rather than regenerated. No external judge calls were made. All prompt hashes match the frozen inputs.\n\nThe fixed protocol tested two policies with saved, direct-clause and length-matched unrelated contexts; source language and English reminders; final citation validation; and direct evidence with related or unrelated distractors. There were three new repeats per distinct fixed condition. The model was gemini-3.5-flash-lite at temperature 0.2.\n\n'''
for h,status,e,l in findings:report+=f'## {h}\n\n{status}. {e}\n\nLimits: {l}\n\n'
report+='These are selected development diagnostics. The local AI-assisted inspection is not a new human validation. Raw answers, failed attempts, exact prompts, condition membership and negative findings are preserved. Howard\u2019s original 10/20 bilingual-pair outcome is unchanged. No revised prompt was deployed. Current-law verification and independent validation remain outside this experiment.\n'
(A/'RESULTS_AND_LIMITATIONS.md').write_text(report)
shutil.copytree(old/'documents',O/'documents',dirs_exist_ok=True)
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=9000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
text='A controlled development follow-up used 213 unique generations with three repeats per fixed condition, no external judge, and local unblinded AI-assisted inspection (Supplementary S34). For AV_015, both languages, the original policy refused in 6/6 saved-context responses, whereas the revised policy provided supported update triggers and electronic submission while identifying the absent deadline in 6/6; unrelated appended text reproduced this contrast. For AV_014, direct clauses recovered the literature-evidence requirement in 6/6 revised responses, compared with canonical refusals in 6/6 saved and 6/6 length-control responses. This was component recovery, not full-task success. For AV_008 English, all 18 responses with direct Article 9 evidence answered the contingency-plan task despite related or unrelated appended passages; all six without Article 9 discussed the Risk Minimization Plan, including three with a relevance reminder. An explicit refusal branch reduced cited canonical refusals from 8/9 to 0/9 on three selected questions. All 36 minimal-context language responses were English, so translation and a stronger language reminder showed no incremental benefit. Identical prompts still varied in response language and refusal behavior. Missing clauses and refusal policy contributed to these selected failures, but neither explains every error. Source-language effects in complex contexts, interactions between instructions, and generalization remain unresolved. These development tests do not establish a reliable repair or change the original 10/20 human-reviewed bilingual-pair result. No revised prompt was deployed.'
for name in ['manuscript_clean.docx','manuscript_tracked.docx']:
 pth=O/'documents'/name;d=Document(pth);p=next(p for p in d.paragraphs if acc(p._p).startswith('The exploratory prompt comparison supports'))
 if 'tracked' in name:redline(p._p,rej(p._p),text)
 else:p.text=text
 d.save(pth)
pth=O/'documents/response_to_reviewer_2.docx';d=Document(pth)
for p in d.paragraphs:
 if p.text.startswith('The post-calibration set shares'):p.text+=' We subsequently completed a frozen, three-repeat controlled follow-up with 213 unique generations and no external judge (S34). The AV_015 policy contrast persisted with identical evidence and unrelated length controls. Direct missing clauses recovered specific AV_014 content where unrelated additions did not. Article 9 recovered the contingency-plan task in 18/18 outputs; a relevance reminder alone failed in 3/3 saved-context outputs. An explicit refusal branch prevented cited refusals in 9/9 tested outputs. Translation and a stronger language reminder showed no incremental effect in 36 English minimal-context outputs. Remaining omissions and qualitative repeat variation prevent a general repair claim. These are unblinded AI-assisted development diagnostics, without new human verification; the original scores remain unchanged.'
d.save(pth)
pth=O/'documents/supplementary_partial_prompt_pilot_S33.docx';d=Document(pth);d.add_heading('Controlled follow up',1);d.add_paragraph('The subsequent three-repeat controlled development experiment is reported in Supplementary S34. It supplements this historical one-repeat diagnostic without changing its outputs or scores.');d.save(pth)
d=Document(old/'documents/supplementary_partial_prompt_pilot_S33.docx')
# Reuse existing document design, clear body while retaining section properties.
for el in list(d._element.body):
 if el.tag!=qn('w:sectPr'):d._element.body.remove(el)
d.add_paragraph('Controlled tests of partial answer failures',style='Title');d.add_paragraph('Supplementary S34   Completed 31 October 2026')
d.add_paragraph('The controlled follow-up supports both missing evidence and refusal policy as contributors to selected failures. It also records unsuccessful language and relevance interventions. These findings explain components of the observed behavior; they do not establish a validated repair.')
d.add_heading('Design and accounting',1);d.add_paragraph(report.split('## ')[0].split('\n\n',1)[1]);d.add_paragraph('The factorial design contains 144 logical cells, of which 12 AV_015 complete-support cells are identical to saved-context cells and reuse those responses. Its 132 remaining records, 36 language records, 27 citation records and 24 relevance records total 219. Six citation baseline records reuse identical factorial prompts and repeat indices, leaving 213 unique generations. Reused records are not independent observations. AV_015 is excluded from a direct-support evidence-effect contrast.')
d.add_paragraph('The protocol was frozen before the first call. Successful exact-prompt responses were reused. Direct and sham additions occupied the same appended position; added lengths matched under cl100k_base, not the provider tokenizer. AV_015 sham text was a separate unrelated control. English translations were prepared locally without human validation; their length controls used explicitly marked non-evidence notes. Article 9 preceded distractors. No adaptive calls were added.')
d.add_heading('Findings and negative results',1)
for h,s,e,l in findings:d.add_heading(h,2);d.add_paragraph(s+'. '+e);d.add_paragraph('Limitations: '+l)
d.add_heading('Mechanical screens and semantic limits',1);d.add_paragraph('The condition summary reports literal canonical refusals after removing bracketed citations, response-language vocabulary screens and citation-label comparisons. A mixed-language refusal is not counted as canonical. Vocabulary hits are not semantic completeness: an Article 13 summary need not repeat the word copy, and citations do not establish responsiveness. No overall full-task success rate or confidence interval was calculated from these screens. Repeat counts describe selected fixed prompts and must not be treated as independent regulatory questions.')
d.add_heading('Preserved evidence',1);d.add_paragraph('The accompanying partial_mechanism_factorial data directory contains the frozen protocol, exact prompts and contexts, randomized plan, reuse membership, 213 answers, 215 attempt records, condition screens, case-level findings and completion audit. All negative findings remain available. Human coordination and authorization records remain local. The original human-reviewed 10/20 bilingual-pair outcome is unchanged; Howard did not rate these new answers. No current-law or independent-validation claim is made.')
d.save(O/'documents/supplementary_partial_mechanism_S34.docx')
changed=['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_partial_prompt_pilot_S33.docx','supplementary_partial_mechanism_S34.docx']
for name in changed:
 p=O/'documents'/name;d=Document(p)
 for style in d.styles:
  if style.type==1 or style.type==2:style.font.name='Arial';style.font.color.rgb=__import__('docx').shared.RGBColor(0,0,0)
 for el in list(d._element.iter(qn('w:pBdr'))):el.getparent().remove(el)
 for el in list(d.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 d.save(p)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(O/'documents/manuscript_clean.docx',True)==proj(O/'documents/manuscript_tracked.docx',True)
assert proj(O/'documents/manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(A/'document_projection_QA.json').write_text(json.dumps({'accept_matches_clean':True,'reject_matches_September_submission_baseline':True,'changed_documents':changed},indent=2))
for name in ['finalize_mechanism.py','screen_mechanism_factorial.py']:shutil.copy2('/private/tmp/'+name,O/name)
print(json.dumps(record,indent=2))
