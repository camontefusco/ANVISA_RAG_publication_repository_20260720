from pathlib import Path
import csv,json,shutil,zipfile,hashlib
from lxml import etree
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/residual_mechanisms_20261031';prior=B/'remote_sync_heading_20261031';S=B/'remote_sync_residual_20261031';S.mkdir(exist_ok=True)
for folder in ['data','figures']:shutil.copytree(prior/folder,S/folder,dirs_exist_ok=True)
shutil.copytree(O/'documents',S/'documents',dirs_exist_ok=True);P=S/'data/residual_mechanisms';P.mkdir(exist_ok=True)
for folder in ['analysis','raw_calls']:shutil.copytree(O/folder,P/folder,dirs_exist_ok=True)
for f in O.iterdir():
 if f.is_file() and (f.suffix=='.py' or f.name in ['PROTOCOL_BEFORE_CALLS.json','generation_inputs_93.jsonl','generation_plan_93.csv','results_checkpoint.jsonl','run_status.json','README_CURRENT_STATUS.txt']):shutil.copy2(f,P/f.name)
H=P/'original_prompt_bridge_6';H.mkdir(exist_ok=True);sourceH=O/'original_prompt_bridge_6'
for f in sourceH.iterdir():
 if f.is_file() and f.name!='human_authorization.json':shutil.copy2(f,H/f.name)
shutil.copytree(sourceH/'raw_calls',H/'raw_calls',dirs_exist_ok=True)
p=S/'data/current_adjudication/hypothesis_results_register.csv';rows=list(csv.DictReader(p.open()));fields=list(rows[0]);F=json.loads((O/'analysis/final_interpretation.json').read_text())
for n,(hyp,find,limit) in enumerate(F['table'],1):rows.append(dict(zip(fields,[f'H39_{n:02}',hyp,find,'S38 residual_mechanisms','Fresh 93-call controls and six-call original-prompt bridge',limit+' Local AI-assisted, human confirmation pending.'])))
rows.append(dict(zip(fields,['H39_06','Further model probing warranted now','Stopped after bounded contrasts; no new batch queued','S38 and RESULTS_AND_STOPPING_DECISION.md','Decision based on positive, negative and variable results','More tuning on these known items cannot resolve human adjudication, current-law validity or independent validation.'])))
with p.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
shutil.copy2(p,P/'analysis/hypothesis_results_register_updated.csv');shutil.copy2(p,O/'analysis/hypothesis_results_register_updated.csv')
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};qa=[]
for p in (S/'documents').glob('*.docx'):
 with zipfile.ZipFile(p) as z:
  x=etree.fromstring(z.read('word/document.xml'));txt=''.join(x.xpath('//w:t[not(ancestor::w:del)]/text()',namespaces=ns));assert '\u2013' not in txt and '\u2014' not in txt,p.name
  for r in x.xpath('//w:r[w:t or w:delText]',namespaces=ns):
   font=r.find('w:rPr/w:rFonts',ns);color=r.find('w:rPr/w:color',ns);assert font is not None and font.get('{'+ns['w']+'}ascii')=='Arial',p.name;assert color is not None and color.get('{'+ns['w']+'}val')=='000000',p.name
 qa.append(p.name)
(O/'analysis/format_QA.json').write_text(json.dumps({'Arial_black_no_accepted_en_em_dashes':qa},indent=2));shutil.copy2(O/'analysis/format_QA.json',P/'analysis/format_QA.json')
for name in ['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx']:shutil.copy2(O/'documents'/name,S/name)
readme=(prior/'README.md').read_text()+'\n## Residual controls S38 and model-probing stopping decision\n\n'+F['results']+'\n\n'+F['discussion']+'\n\nRemaining work: '+F['remaining_work']+'\n'
(S/'README.md').write_text(readme)
with (S/'FILE_INDEX.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['relative_path','type','bytes'])
 for folder in ['documents','figures']:
  for p in sorted((S/folder).rglob('*')):
   if p.is_file():w.writerow([p.relative_to(S),p.suffix,p.stat().st_size])
for name,folders in [('supplementary_documents.zip',['documents','figures']),('revision_data.zip',['data'])]:
 with zipfile.ZipFile(S/name,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  for folder in folders:
   for p in sorted((S/folder).rglob('*')):
    if p.is_file():z.write(p,p.relative_to(S))
  if name.startswith('supplementary'):z.write(S/'FILE_INDEX.csv','FILE_INDEX.csv')
 with zipfile.ZipFile(S/name) as z:assert z.testzip() is None
names=['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_documents.zip','revision_data.zip','README.md']
with (S/'SHA256_MANIFEST.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['file','bytes','sha256'])
 for n in names:p=S/n;w.writerow([n,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
local=B/'submission_package_residual_20261031';local.mkdir(exist_ok=True)
for n in names+['SHA256_MANIFEST.csv','FILE_INDEX.csv']:shutil.copy2(S/n,local/n)
with zipfile.ZipFile(B/'submission_package_residual_20261031.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in local.iterdir():z.write(p,p.name)
shutil.copytree(O/'documents',B/'current_documents',dirs_exist_ok=True);(R/'LATEST_REVISION.txt').write_text(str(O)+'\n');shutil.copy2('/private/tmp/package_residual.py',O/'package_residual.py')
print(json.dumps({'documents':len(qa),'stage':str(S),'files':{n:(S/n).stat().st_size for n in names+['SHA256_MANIFEST.csv']}},indent=2))
