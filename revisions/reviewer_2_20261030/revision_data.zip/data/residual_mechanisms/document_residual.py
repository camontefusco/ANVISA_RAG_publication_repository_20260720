from pathlib import Path
import csv,json,shutil,ast,datetime,re,difflib
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/residual_mechanisms_20261031';D=O/'documents';D.mkdir(exist_ok=True);shutil.copytree(B/'remote_sync_heading_20261031/documents',D,dirs_exist_ok=True)
F=json.loads((O/'analysis/final_interpretation.json').read_text());methods=F['methods'];results=F['results'];discussion=F['discussion']
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=13000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
def settext(p,text):
 for x in list(p):
  if x.tag!=qn('w:pPr'):p.remove(x)
 r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=text;t.set(qn('xml:space'),'preserve');r.append(t);p.append(r)
changed=[]
for name in ['manuscript_clean.docx','manuscript_tracked.docx']:
 d=Document(D/name)
 for anchor,text in [('Results',methods),('Summary of quantitative evaluation',results)]:
  target=next(p for p in d.paragraphs if acc(p._p)==anchor);p=target.insert_paragraph_before('')
  if 'tracked' in name:redline(p._p,'',text)
  else:p.text=text
 target=next(p for p in d.paragraphs if acc(p._p).startswith('Automatic article completion repaired'));p=OxmlElement('w:p');target._p.addnext(p)
 if 'tracked' in name:redline(p,'',discussion)
 else:settext(p,discussion)
 d.save(D/name);changed.append(name)
d=Document(D/'response_to_reviewer_2.docx')
for p in d.paragraphs:
 if p.text.startswith('The post-calibration set shares'):p.text+=' '+F['response']
d.save(D/'response_to_reviewer_2.docx');changed.append('response_to_reviewer_2.docx')
d=Document(D/'supplementary_automatic_answer_followup_S37.docx')
for x in list(d._element.body):
 if x.tag!=qn('w:sectPr'):d._element.body.remove(x)
d.add_paragraph('Residual mechanism controls and stopping assessment',style='Title');d.add_paragraph('Supplementary S38   31 October 2026')
d.add_paragraph('This experiment separates remaining explanations for failures on known development questions. All 93 answers completed with the same model and temperature, using fresh controls randomized in the same batch. The results support specific case-level mechanisms, not an independently validated repair. Local AI-assisted assessments await human confirmation.')
for h,t in [('Design',methods),('Findings',results),('Interpretation',discussion)]:d.add_heading(h,1);d.add_paragraph(t)
d.add_heading('Mechanism summaries',1);t=d.add_table(rows=1,cols=3);t.style='Table Grid'
for c,v in zip(t.rows[0].cells,['Mechanism','Observed result','Limit']):c.text=v
for vals in F['table']:
 for c,v in zip(t.add_row().cells,vals):c.text=v
hr=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(hr)
d.add_heading('Reasons to stop model probing for now',1)
for t in F['stop_reasons']:d.add_paragraph(t)
d.add_heading('Remaining work',1);d.add_paragraph(F['remaining_work'])
d.add_heading('Audit and provenance',1);d.add_paragraph(F['audit'])
d.save(D/'supplementary_residual_mechanisms_S38.docx');changed.append('supplementary_residual_mechanisms_S38.docx')
for name in changed:
 d=Document(D/name)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 for p in d.paragraphs:
  if name.endswith('S38.docx'):p.paragraph_format.space_after=Pt(4)
 d.save(D/name)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True);assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(O/'analysis/document_projection_QA.json').write_text(json.dumps({'accept_matches_clean':True,'reject_matches_submission_baseline':True,'changed_documents':changed},indent=2));shutil.copy2('/private/tmp/document_residual.py',O/'document_residual.py');print(changed)
