from pathlib import Path
import csv,json,re,hashlib,collections,shutil
R=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021');O=R/'outputs/residual_mechanisms_20261031';A=O/'analysis';A.mkdir(exist_ok=True);old=R/'outputs/offline_retrieval_scoring_audit_20261031';rows=list(csv.DictReader((old/'heading_metadata_change_screen.csv').open()));counts=collections.Counter()
for x in rows:
 if x['baseline_exists']=='False':cat='Recovered source boundary'
 elif any(re.search(r'(desta|deste|deve constar|da RDC|do Anexo|identificada|^Seção I do)',x[k],re.I) for k in ['baseline_chapter','baseline_section']):cat='Inline reference or body text used as heading'
 else:cat='Completed multiline heading title'
 x['structural_change_category']=cat;counts[cat]+=1
with (A/'parser_change_categories_61.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
items=list(map(json.loads,(O/'generation_inputs_93.jsonl').read_text().splitlines()));summary={'parser_change_screen':dict(counts),'by_source':dict(collections.Counter(x['file'] for x in rows)),'frozen_payload_sha256':hashlib.sha256((O/'generation_inputs_93.jsonl').read_bytes()).hexdigest(),'intervention_audit':[]}
for family in sorted({x['family'] for x in items}):
 z=[x for x in items if x['family']==family];summary['intervention_audit'].append({'family':family,'calls':len(z),'unique_questions':len({x['question'] for x in z}),'unique_contexts':len({x['context_sha256'] for x in z}),'question_changed_calls':sum(x['question_changed'] for x in z),'conditions':dict(collections.Counter(x['condition'] for x in z))})
# Every family is a diagnostic intervention on known development examples, not an independent sample.
summary['limits']='Screened structural categories, not semantic or legal adjudication of all changed parser records. No full source/index rebuild; no new independent questions. Three repeats characterize local stability only.'
(A/'offline_audit_summary.json').write_text(json.dumps(summary,indent=2));shutil.copy2('/private/tmp/residual_offline_audit.py',O/'residual_offline_audit.py');print(json.dumps(summary,indent=2))
