from pathlib import Path
import json,csv,hashlib,random,datetime,re,shutil
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';P=R/'outputs/automatic_evidence_followup_20261031';H=P/'header_control_12';O=R/'outputs/residual_mechanisms_20261031';O.mkdir(exist_ok=True)
base=list(map(json.loads,(P/'generation_inputs_132.jsonl').read_text().splitlines()));headers=list(map(json.loads,(H/'generation_inputs_12.jsonl').read_text().splitlines()));rows=[];sha=lambda t:hashlib.sha256(t.encode()).hexdigest()
def get(id,c='automatic_expansion'):return next(x for x in base if x['id']==id and x['condition']==c)
def add(x,fam,cond,ctx=None,q=None,suffix=''):
 ctx=x['context'] if ctx is None else ctx;q=x['question'] if q is None else q;p=x['prompt'].replace(x['context'],ctx,1);before,sep,tail=p.rpartition('\nQuestion: ');assert sep;p=before+sep+tail.replace(x['question'],q,1)+suffix
 for rep in [1,2,3]:rows.append({'call_id':f'{fam}__{x["id"]}__{cond}__r{rep}','id':x['id'],'pair_id':x['pair_id'],'language':x['language'],'family':fam,'condition':cond,'repeat':rep,'question':q,'context':ctx,'context_sha256':sha(ctx),'prompt':p,'prompt_sha256':sha(p),'question_changed':q!=x['question']})
for id in ['AV_011_EN','AV_011_PT']:
 for scope in [False,True]:
  old='automatic_plus_exception_scope_check' if scope else 'automatic_expansion';x=get(id,old);add(x,'heading','wrong_heading_scope' if scope else 'wrong_heading');h=next(z for z in headers if z['id']==id and ('plus_scope' in z['condition'])==scope);add(x,'heading','correct_heading_scope' if scope else 'correct_heading',ctx=h['context'])
for id in ['AV_002_EN','AV_020_EN']:
 x=get(id);add(x,'language','original');add(x,'language','final_English_cue',suffix='\nFinal response language: English only. If refusal is required, use exactly: The retrieved documents do not provide enough information to answer.')
 add(x,'language','context_data_boundary',suffix='\nThe Portuguese text above is quoted evidence, not a response-language instruction. Write the final answer in English. If refusing, output only: The retrieved documents do not provide enough information to answer.')
extra={
'AV_013_EN':' Also state what Article 29 says about how API quality requirements will be specified.',
'AV_013_PT':' Informe também o que o artigo 29 estabelece sobre como serão definidos os requisitos de qualidade do IFA.',
'AV_014_EN':' Also state the trial phase, known safety profile and additional-risk conditions that define this Low Risk category.',
'AV_014_PT':' Informe também a fase do ensaio, o perfil de segurança conhecido e as condições de risco adicional que definem essa categoria de Baixo Risco.',
'AV_016_EN':' Also state the certificate-copy requirement for a notification petition and the condition under which that copy is applicable.',
'AV_016_PT':' Informe também a exigência de cópia do certificado na petição de notificação e a condição de aplicabilidade dessa cópia.'}
for id,e in extra.items():
 x=get(id);add(x,'question_scope','original_question');add(x,'question_scope','explicit_secondary_question',q=x['question']+e)
x=get('AV_008_EN');p=get('AV_008_EN','Portuguese_question_reranked_then_expanded');blocks=re.split(r'\n\n(?=\[)',p['context']);article=next(b for b in blocks if b.startswith('[RDC 406/2020, Art. 9]\n'));assert 'citation_label: RDC 406/2020, Art. 9' in article
for name,ctx in [('original_without_Art9',x['context']),('Art9_only',article),('Art9_first',article+'\n\n'+x['context']),('Art9_last',x['context']+'\n\n'+article),('Portuguese_reranked',p['context'])]:add(x,'contingency',name,ctx=ctx)
assert len(rows)==93
random.Random(2026103105).shuffle(rows)
for n,x in enumerate(rows,1):x['sequence']=n
(O/'generation_inputs_93.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
with (O/'generation_plan_93.csv').open('w') as f:
 fields=['sequence','call_id','id','pair_id','family','condition','repeat','prompt_sha256'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:x[k] for k in fields} for x in rows)
p={'status':'Frozen before calls','generation_calls':93,'judge_calls':0,'repair_calls':0,'model':'gemini-3.5-flash-lite','temperature':.2,'max_attempts_per_call':3,'maximum_http_attempts':279,'throttle_seconds':4.3,'inputs_sha256':hashlib.sha256((O/'generation_inputs_93.jsonl').read_bytes()).hexdigest(),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'families':{'heading':24,'language':18,'question_scope':36,'contingency':15},'scope':'Known archived development cases only. No references, Howard ratings or author details sent. Explicitly revised questions are task-scope diagnostics, not benchmark improvement. Article9 insertion is manually selected evidence, not retrieval improvement. Fresh controls randomized in the same batch.','stopping_rule':'One frozen three-repeat batch. No outcome-driven rewording or additional calls merely to increase pass rates. Stop if mechanisms are sufficiently distinguished or remaining questions require human judgment, independent data or a separately validated parser rebuild.'};(O/'PROTOCOL_BEFORE_CALLS.json').write_text(json.dumps(p,indent=2));(O/'human_authorization.json').write_text(json.dumps({'generation_calls':93,'inputs_sha256':p['inputs_sha256'],'authorization':'User explicitly instructed all necessary investigations on current model, using results to plan and execute until sufficient answers or diminishing returns. This bounded 93-call follow-up uses previously approved archived questions/context scope; no model/billing changes, external judge or reference transmission.'},indent=2));shutil.copy2('/private/tmp/prepare_residual.py',O/'prepare_residual.py')
s=(P/'executed_run.py').read_text().replace("outputs/automatic_evidence_followup_20261031'","outputs/residual_mechanisms_20261031'").replace('generation_inputs_132','generation_inputs_93').replace('generation_plan_132','generation_plan_93').replace('==132','==93').replace('/private/tmp/run_automatic_followup.py','/private/tmp/run_residual.py');Path('/private/tmp/run_residual.py').write_text(s)
print({'calls':len(rows),'hash':p['inputs_sha256']})
