def _heading_end(lines,index):
 end=index+1
 if end>=len(lines):return end
 s=lines[end].strip()
 if not s or ARTICLE_RE.match(s) or CHAPTER_RE.match(s) or SECTION_RE.match(s) or len(s)>140:return end
 end+=1
 while end<len(lines):
  s=lines[end].strip()
  if not s or not s.isupper() or ARTICLE_RE.match(s) or CHAPTER_RE.match(s) or SECTION_RE.match(s) or len(s)>140:break
  end+=1
 return end

def _heading_with_subtitle(lines,index):
 return lines[index].strip()+ (' - '+' '.join(s.strip() for s in lines[index+1:_heading_end(lines,index)]) if _heading_end(lines,index)>index+1 else '')

def parse_regulatory_document(source_path: Path) -> list[Document]:
    """Split one regulation into article-level documents with citation metadata."""
    catalog_entry = DOCUMENT_CATALOG.get(source_path.name)
    if catalog_entry is None:
        raise ValueError(f"No document metadata configured for {source_path.name}")

    lines = source_path.read_text(encoding="utf-8").splitlines()
    documents: list[Document] = []
    current_lines: list[str] = []
    current_article = "Preamble"
    current_chapter = ""
    current_section = ""
    pending_chapter: str | None = None
    pending_section: str | None = None
    skipped_subtitle_indexes: set[int] = set()

    def flush() -> None:
        nonlocal current_lines
        text = "\n".join(current_lines).strip()
        if text:
            documents.append(
                _make_document(
                    text,
                    source_path,
                    catalog_entry,
                    current_article,
                    current_chapter,
                    current_section,
                )
            )
        current_lines = []

    for index, raw_line in enumerate(lines):
        if index in skipped_subtitle_indexes:
            continue
        line = raw_line.strip()
        if not line:
            continue

        chapter_match = CHAPTER_RE.match(line)
        section_match = SECTION_RE.match(line)
        article_match = ARTICLE_RE.match(line)

        if chapter_match:
            pending_chapter = _heading_with_subtitle(lines, index)
            pending_section = ""
            if " - " in pending_chapter:
                skipped_subtitle_indexes.update(range(index+1,_heading_end(lines,index)))
            continue
        elif section_match:
            pending_section = _heading_with_subtitle(lines, index)
            if " - " in pending_section:
                skipped_subtitle_indexes.update(range(index+1,_heading_end(lines,index)))
            continue

        if article_match:
            flush()
            if pending_chapter is not None:
                current_chapter = pending_chapter
                pending_chapter = None
            if pending_section is not None:
                current_section = pending_section
                pending_section = None
            current_article = f"Art. {article_match.group(1)}"

        current_lines.append(line)

    flush()
    return documents
