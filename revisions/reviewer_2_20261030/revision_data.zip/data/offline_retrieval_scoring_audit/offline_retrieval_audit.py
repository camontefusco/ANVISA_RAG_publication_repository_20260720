from pathlib import Path
import json,csv,re,hashlib,collections,unicodedata,datetime
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/offline_retrieval_scoring_audit_20261031';O.mkdir(exist_ok=True);F=R/'outputs/author_led_validation_frozen_20261030';payload=F/'generation_payload_40/generation_inputs_40.jsonl';index=B/'historical_workspace/Rag_project/vector_store/docstore.json';goldfile=F/'approved_questions_and_references_40_FROZEN.csv';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'questions':40,'network_calls':0,'index_nodes':481,'selection_uses_gold':False,'conditions':['saved','all_siblings_top5','all_siblings_top5_neighbor1','candidate_pool_all_siblings_UPPER_BOUND','named_document_UPPER_BOUND'],'rule':'Use exact saved top5 node IDs, all indexed chunks from each selected regulation/article, and optionally adjacent article numbers ±1. Gold references used only after selection for evaluation. Candidate100 and question-named full-document contexts are diagnostic upper bounds, not proposed generation contexts.','metrics':'Archived source-fragment lexical coverage and exact normalized word5gram coverage, grouped by question; lexical screens do not establish semantic evidence sufficiency or answer quality. Record passage counts and length.','hashes':{'saved_payload':sha(payload),'docstore':sha(index),'frozen_reference':sha(goldfile)},'historical_unchanged':True}
(O/'PROTOCOL_BEFORE_AUDIT.json').write_text(json.dumps(protocol,indent=2))
inputs=list(map(json.loads,payload.read_text().splitlines()));nodes={i:v['__data__'] for i,v in json.loads(index.read_text())['docstore/data'].items()};g={x['id']:x for x in csv.DictReader(goldfile.open())}
def norm(s):return re.sub(r'[^a-z0-9]+',' ',''.join(c for c in unicodedata.normalize('NFKD',s.lower()) if not unicodedata.combining(c))).strip()
def key(n):
 m=n['metadata'];return (m.get('regulation_id',''),m.get('article',''))
lookup=collections.defaultdict(list)
for id,n in nodes.items():lookup[key(n)].append(id)
for ids in lookup.values():ids.sort(key=lambda id:int(nodes[id]['metadata'].get('article_chunk_index') or 1))
def expand(ids,neighbors=False):
 out=[]
 for id in ids:
  k=key(nodes[id]);keys=[k];m=re.search(r'Art\. (\d+)',k[1])
  if neighbors and m:keys += [(k[0],'Art. '+str(int(m[1])+d)) for d in [-1,1]]
  for kk in keys:
   for ii in lookup.get(kk,[]):
    if ii not in out:out.append(ii)
 return out
metrics=[];contexts=[];fragments=[]
for x in inputs:
 q=x['id'];seed=x['ranked_node_ids'];reg=re.search(r'(?:RDC|IN)\s+\d+/\d{4}',x['question']).group(0);variants={'saved':None,'all_siblings_top5':expand(seed),'all_siblings_top5_neighbor1':expand(seed,True),'candidate_pool_all_siblings_UPPER_BOUND':expand(x['candidate_ids']),'named_document_UPPER_BOUND':[id for id,n in nodes.items() if key(n)[0]==reg]};gs=g[q];quotes=[z.strip() for z in re.split(r'\\n|\n|\|\|',gs['verbatim_source_support']) if z.strip()]
 for condition,ids in variants.items():
  texts=[z['text'] for z in x['selected_evidence']] if ids is None else [nodes[id]['text'] for id in ids];labels=[z['citation'] for z in x['selected_evidence']] if ids is None else [nodes[id]['metadata'].get('citation_label','') for id in ids];tt=[norm(t) for t in texts];joined=' '.join(tt);ng=set()
  for t in tt:
   w=t.split();ng.update(tuple(w[i:i+5]) for i in range(len(w)-4))
  hits=[];cover=[]
  for j,quote in enumerate(quotes):
   nq=norm(quote);w=nq.split();qn={tuple(w[i:i+5]) for i in range(len(w)-4)};fraction=len(qn&ng)/len(qn) if qn else float(nq in joined);hit=any(nq in t for t in tt);hits.append(hit);cover.append(fraction);fragments.append({'id':q,'condition':condition,'fragment':j+1,'quote':quote,'exact_fragment_in_one_passage':hit,'word5gram_coverage':fraction})
  metrics.append({'id':q,'pair_id':x['pair_id'],'language':x['language'],'category':gs['planned_category'],'condition':condition,'passages':len(texts),'characters':sum(map(len,texts)),'distinct_articles':len(set(labels)),'reference_fragments':len(quotes),'exact_fragments_found':sum(hits),'all_fragments_5gram_covered':all(v==1 for v in cover) if quotes else '', 'mean_fragment_5gram_coverage':sum(cover)/len(cover) if quotes else '', 'evidence_labels':' | '.join(dict.fromkeys(labels))})
  contexts.append({'id':q,'condition':condition,'node_ids':ids,'labels':labels,'texts':texts,'selection_uses_gold':False})
for name,rr in [('question_condition_metrics.csv',metrics),('fragment_coverage.csv',fragments)]:
 with (O/name).open('w') as f:w=csv.DictWriter(f,fieldnames=rr[0]);w.writeheader();w.writerows(rr)
(O/'selected_contexts_LOCAL_ONLY.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in contexts));summary={}
for c in variants:
 rr=[r for r in metrics if r['condition']==c and r['reference_fragments']];summary[c]={'questions_with_reference_fragments':len(rr),'all_reference_word5grams_covered':sum(r['all_fragments_5gram_covered'] for r in rr),'mean_reference_fragment_coverage':sum(r['mean_fragment_5gram_coverage'] for r in rr)/len(rr),'mean_passages':sum(r['passages'] for r in rr)/len(rr),'max_passages':max(r['passages'] for r in rr),'mean_characters':sum(r['characters'] for r in rr)/len(rr)}
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
for q in ['AV_004_EN','AV_006_EN','AV_008_EN','AV_009_PT','AV_013_PT','AV_014_EN','AV_016_EN','AV_016_PT']:
 print(q,[(r['condition'],round(r['mean_fragment_5gram_coverage'],3),r['passages']) for r in metrics if r['id']==q])
