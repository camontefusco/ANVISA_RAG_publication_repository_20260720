from pathlib import Path
import json,ast,re,csv,hashlib,types
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/offline_retrieval_scoring_audit_20261031';src=(B/'repository/src/regulatory_documents.py').read_text();tree=ast.parse(src)
class Doc:
 def __init__(self,**kw):self.__dict__.update(kw)
keep=[n for n in tree.body if isinstance(n,(ast.Assign,ast.FunctionDef)) and (isinstance(n,ast.Assign) or n.name in ['_heading_with_subtitle','_make_document','parse_regulatory_document'])];ns={'re':re,'Path':Path,'Document':Doc};exec(compile(ast.Module(body=keep,type_ignores=[]),'original_parser','exec'),ns);data=B/'historical_workspace/Rag_project/cleaned_data';baseline={p.name:ns['parse_regulatory_document'](p) for p in data.glob('*.txt')};fix={'re':re,'Path':Path,'Document':Doc};exec(compile(ast.Module(body=keep,type_ignores=[]),'prototype_parser','exec'),fix)
fix['ARTICLE_RE']=re.compile(r'^Art\.?\s*(\d+)\s*[oº°.]?',re.I);fix['CHAPTER_RE']=re.compile(r'^CAP[IÍ]TULO\s+([IVXLCDM]+|\d+)\s*$',re.I);fix['SECTION_RE']=re.compile(r'^SE[CÇ][AÃ]O\s+([IVXLCDM]+|\d+)\s*$',re.I)
helper='''def _heading_end(lines,index):
 end=index+1
 if end>=len(lines):return end
 s=lines[end].strip()
 if not s or ARTICLE_RE.match(s) or CHAPTER_RE.match(s) or SECTION_RE.match(s) or len(s)>140:return end
 end+=1
 while end<len(lines):
  s=lines[end].strip()
  if not s or not s.isupper() or ARTICLE_RE.match(s) or CHAPTER_RE.match(s) or SECTION_RE.match(s) or len(s)>140:break
  end+=1
 return end

def _heading_with_subtitle(lines,index):
 return lines[index].strip()+ (' - '+' '.join(s.strip() for s in lines[index+1:_heading_end(lines,index)]) if _heading_end(lines,index)>index+1 else '')
''';exec(helper,fix)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='parse_regulatory_document');text=ast.get_source_segment(src,fn).replace('skipped_subtitle_indexes.add(index + 1)','skipped_subtitle_indexes.update(range(index+1,_heading_end(lines,index)))');exec(text,fix);patched={p.name:fix['parse_regulatory_document'](p) for p in data.glob('*.txt')};rows=[]
for file,docs in baseline.items():
 old={d.metadata['article']:d for d in docs};new={d.metadata['article']:d for d in patched[file]}
 for article in sorted(set(old)|set(new)):
  a=old.get(article);b=new.get(article)
  if a is None or b is None or any(a.metadata[k]!=b.metadata[k] for k in ['chapter','section']):rows.append({'file':file,'article':article,'baseline_exists':a is not None,'prototype_exists':b is not None,'baseline_chapter':a.metadata['chapter'] if a else '', 'prototype_chapter':b.metadata['chapter'] if b else '', 'baseline_section':a.metadata['section'] if a else '', 'prototype_section':b.metadata['section'] if b else ''})
with (O/'heading_metadata_change_screen.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
rdc=next(f for f in baseline if f.startswith('RDC_55_2010'));old41=next(d for d in baseline[rdc] if d.metadata['article']=='Art. 41');new41=next(d for d in patched[rdc] if d.metadata['article']=='Art. 41');assert 'IV' in new41.metadata['chapter'] and 'INDIVIDUAL' in new41.metadata['chapter'];assert any(d.metadata['article']=='Art. 37' for d in patched[rdc]);assert not any(d.metadata['article']=='Art. 37' for d in baseline[rdc]);assert 'Capítulo III desta Resolução.' in next(d.text for d in patched[rdc] if d.metadata['article']=='Art. 37')
summary={'source_sha256':hashlib.sha256(src.encode()).hexdigest(),'baseline_article_blocks':sum(len(v) for v in baseline.values()),'prototype_article_blocks':sum(len(v) for v in patched.values()),'metadata_or_boundary_changes_screened':len(rows),'Art41_baseline':old41.metadata,'Art41_prototype':new41.metadata,'Art37_missing_baseline_and_recovered_prototype':True,'body_cross_reference_preserved':True,'limits':'Local structural prototype; no full semantic validation, re-embedding or production index replacement. Metadata-change count is a screen, not a count of adjudicated errors. Genuine headings with same-line titles need separate coverage before deployment.'};(O/'heading_parser_audit.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));(O/'heading_parser_prototype_helpers.py').write_text(helper+'\n'+text+'\n');print({k:v for k,v in summary.items() if k not in ['Art41_baseline','Art41_prototype']});print('Art41 corrected chapter',new41.metadata['chapter'])
