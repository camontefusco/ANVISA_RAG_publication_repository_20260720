from pathlib import Path
import csv,json,collections,re,os,textwrap
os.environ['MPLCONFIGDIR']='/private/tmp/anvisa_submission_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/automatic_evidence_followup_20261031';F=O/'figures';F.mkdir(exist_ok=True)
for p in Path('/System/Library/Fonts/Supplemental').glob('Arial*.ttf'):font_manager.fontManager.addfont(str(p))
plt.rcParams.update({'font.family':'Arial','font.size':10,'text.color':'black','axes.labelcolor':'black','axes.edgecolor':'black','xtick.color':'black','ytick.color':'black','svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,n):
 for text in fig.findobj(matplotlib.text.Text):
  text.set_fontfamily('Arial');text.set_color('black');text.set_text(text.get_text().replace('\u2013',' to ').replace('\u2014',', '))
 for ext in ['png','pdf','svg','tif']:fig.savefig(F/(n+'.'+ext),dpi=400,bbox_inches='tight',**({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tif' else {}))
 plt.close(fig)
def box(ax,y,title,body):
 ax.add_patch(FancyBboxPatch((.04,y),.92,.08,boxstyle='round,pad=0.012',facecolor='white',edgecolor='black',lw=1));ax.text(.065,y+.052,title,fontweight='bold',va='center',fontsize=10);ax.text(.065,y+.021,body,va='center',fontsize=9)
fig,ax=plt.subplots(figsize=(9,10));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
workflow=[('Archived corpus','Six selected regulatory documents; includes revoked RDC 9/2015'),('Text and article structure','382 parsed source records; 481 chunks with source and citation metadata'),('Query preparation','Portuguese questions retained; English glossary rewriting and query expansions'),('Hybrid retrieval','Dense and BM25 candidates, fusion, anchors and lexical fallback'),('Reranking and context selection','Cross-encoder ranking; conditional sibling expansion and citation diversification'),('Evidence classification','Sufficient, partial related, or insufficient under the frozen prompt'),('Answer or refusal','Supported answer with article citations, or a language-specific refusal'),('Evaluation','Reused development sets, diagnostic assessments, then a frozen author-led test')]
for i,(title,body) in enumerate(workflow):
 y=.88-i*.115;box(ax,y,title,body)
 if i<7:ax.annotate('',xy=(.5,y-.025),xytext=(.5,y-.002),arrowprops={'arrowstyle':'->','color':'black'})
ax.set_title('Closed corpus retrieval and answer workflow',fontsize=15,pad=14);save(fig,'Figure_1_closed_corpus_rag_workflow')
