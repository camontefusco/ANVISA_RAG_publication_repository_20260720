# Submission evidence guide

This curated archive supports the final archived-corpus manuscript and Supplementary Sections S1 to S9. Original generated answers, judge scores, known problematic golds and failed controls are retained as evidence, not presented as current-law truth. No historical result was silently corrected or removed for being negative.

- historical_S1_S2: all 404 evaluated historical rows and 404 judge rows, with corrected development-stage labels, exact judge prompt and overlap audits.
- historical_author_review: original94-output review, comparison records and separate confirmation/date provenance; AI-assisted and unblinded.
- four_question_context_controls and ethics_length_and_prompt_controls: exact early control inputs, raw outputs, repeat membership and summaries.
- current_adjudication: separate archived-corpus label and refusal overlays; original labels remain available.
- Howard40_review: 40 frozen answers, selected evidence, references, ratings, date correction and derived 20-pair outcomes.
- DR11, DR13 and sibling_context: completed embedding, retrieval-rule and sibling-context analyses, including negative results and review limitations.
- partial_prompt_pilot, partial_mechanism_factorial, combined_repair_comparison, automatic_evidence_followup and residual_mechanisms: development controls, failures and raw outputs underlying Section S7.
- integrated_validation_completed_20261101: frozen new questions, references, plan/prompt hashes, 20 translations, 80 raw/processed answers and original AI assessments. Historical frozen fields stating authorization or human review was pending describe their creation time, not current status.
- integrated_scope_resolved_20261101: separate FV012 sensitivity and review provenance. 44 outputs received personal author confirmation; 36 received AI review only. The review overlay does not imply independent validation.
- current_law_targeted_check_20261101 and DR8_clause_audit: source-status evidence and explicit applicability limits. RDC 55 Articles 22 and 30 are revoked; archived-task scores remain unchanged.
- source_provenance: source checksums and official-source links.
- reproducibility_code: source and evaluation code. Reproduction of retrieval requires the original local corpus/vector assets; these and credentials are excluded. Exact hosted-model outputs are not guaranteed reproducible.

Current-law corpus rebuilding and reevaluation, independent external validation and additional answer baselines remain incomplete or absent. Negative results, raw format failures and original source exposure are deliberately retained. Superseded authoring templates, pending-run instructions, draft replacement references and duplicate document/report build files are excluded; the full research history remains in the preserved local archive and repository history.
