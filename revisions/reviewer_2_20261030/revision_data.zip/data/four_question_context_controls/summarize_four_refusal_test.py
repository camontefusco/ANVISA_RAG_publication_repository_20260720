from pathlib import Path
import json,csv,re,unicodedata
O=Path('/Users/cmontefusco/projects/Codex/ANVISA_RAG_publication_repository_20260720/revisions/reviewer_2_20261021/outputs/four_refusal_context_test_20261028')
rows=[json.loads(x) for x in (O/'generations_39.jsonl').read_text().splitlines()];bycall={x['call_id']:x for x in rows};inputs={(x['id'],x['variant'],x['condition']):x for x in map(json.loads,(O/'generation_inputs_15.jsonl').read_text().splitlines())};members=list(csv.DictReader((O/'condition_membership_45.csv').open()))
def norm(x):return ''.join(c for c in unicodedata.normalize('NFKD',x.lower()) if not unicodedata.combining(c))
out=[]
for m in members:
 if m['call_id'] not in bycall:continue
 x=bycall[m['call_id']];inp=inputs[(m['id'],m['variant'],m['condition'])];a=x['answer'];n=norm(a).strip();canonical=n.rstrip('.!') in ['os documentos recuperados nao fornecem informacao suficiente para responder','the retrieved documents do not provide enough information to answer'];negative=bool(re.match(r'^(?:\*\*)?(?:no|nao)\b',n));citations=re.findall(r'\[([^\[\]]+)\]',a);expected=inp['direct_provision'];direct_cited=expected in citations
 out.append(dict(m,answer=a,canonical_refusal=canonical,negative_opening=negative,citation_count=len(citations),citations=';'.join(citations),direct_provision_cited=direct_cited,cited_negative_candidate=negative and bool(citations),AI_grounding_assessment='pending full-text inspection; mechanical negative/citation markers are not correctness',modelVersion=x['modelVersion'],shared_call_across_conditions=sum(y['call_id']==m['call_id'] for y in members)>1))
def write(n,rr):
 with (O/n).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
write('condition_answers_and_screening_45.csv',out)
summary=[]
for key in inputs:
 rr=[r for r in out if (r['id'],r['variant'],r['condition'])==key]
 summary.append({'id':key[0],'variant':key[1],'condition':key[2],'outputs':len(rr),'canonical_refusals':sum(r['canonical_refusal'] for r in rr),'cited_negative_candidates':sum(r['cited_negative_candidate'] for r in rr),'direct_provision_cited':sum(r['direct_provision_cited'] for r in rr),'not_a_correctness_measure':'Cited negative candidates require support review; same-prompt reused conditions are dependent.'})
write('per_case_condition_counts.csv',summary)
(O/'answer_inspection.txt').write_text('\n\n'.join(x['call_id']+'\n'+next(m['id']+' '+m['variant']+' '+m['condition'] for m in members if m['call_id']==x['call_id'])+'\n'+x['answer'] for x in rows))
print(json.dumps(summary,indent=2))
