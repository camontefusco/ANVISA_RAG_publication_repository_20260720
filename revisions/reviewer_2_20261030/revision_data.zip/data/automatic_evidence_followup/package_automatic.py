from pathlib import Path
import json,csv,shutil,zipfile,hashlib
from lxml import etree
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/automatic_evidence_followup_20261031';A=R/'outputs/offline_retrieval_scoring_audit_20261031';S=B/'remote_sync_automatic_20261031';prior=B/'remote_sync_combined_20261031';S.mkdir(exist_ok=True)
for folder in ['data','figures']:shutil.copytree(prior/folder,S/folder,dirs_exist_ok=True)
shutil.copytree(O/'documents',S/'documents',dirs_exist_ok=True);shutil.copytree(O/'figures',S/'figures',dirs_exist_ok=True)
P=S/'data/automatic_evidence_followup';P.mkdir(exist_ok=True)
for folder in ['analysis','raw_calls']:shutil.copytree(O/folder,P/folder,dirs_exist_ok=True)
for p in O.iterdir():
 if p.is_file() and (p.suffix=='.py' or p.name in ['PROTOCOL_BEFORE_CALLS.json','PROTOCOL_PREPARED.json','generation_inputs_132.jsonl','generation_plan_132.csv','results_checkpoint.jsonl','run_status.json']):shutil.copy2(p,P/p.name)
refs=list(csv.DictReader((O/'local_frozen_references_40.csv').open()));fields_ref=['id','pair_id','language','planned_category','question','expected_answer','required_supported_elements','unavailable_detail','source_citations','verbatim_source_support','source_version_and_scope','current_law_claim']
with (P/'frozen_reference_components_40.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields_ref);w.writeheader();w.writerows({k:r[k] for k in fields_ref} for r in refs)
PA=S/'data/offline_retrieval_scoring_audit';PA.mkdir(exist_ok=True)
for p in A.iterdir():
 if p.is_file() and p.name!='selected_contexts_LOCAL_ONLY.jsonl' and p.suffix in ['.json','.csv','.py']:shutil.copy2(p,PA/p.name)
H=P/'header_control_12_PENDING_AUTHORIZATION';H.mkdir(exist_ok=True)
for name in ['PROTOCOL_PREPARED.json','generation_inputs_12.jsonl','generation_plan_12.csv']:shutil.copy2(O/'header_control_12'/name,H/name)
findings=[('H36_01','Missing clause coverage','Lexical coverage rose from 20/32 with saved contexts to 26/32 with all sibling chunks and 31/32 with adjacent articles.','S36','Lexical coverage is not semantic sufficiency or answer quality.'),('H36_02','Cross-language reranking','Article 9 moved from rank 6 under English to rank 1 under a faithful Portuguese query.','S36 and S37','One known case; frozen candidate pool.'),('H36_03','Heading parser','Inline cross-references were misread as headings; Art 37 lacked the expected dot. Article 41 had a false chapter prefix.','S36','Prototype only; 61 screened differences are not 61 adjudicated errors; index unchanged.'),('H36_04','Corpus count units','382 parsed records include six preambles and repeated labels. Split nodes total 122, not stale manifest field 150.','S36','Historical manifest retained; no source/index replacement.'),('H37_01','Automatic evidence completion','Raw pair successes 11/20, 10/20, 12/20; normalized 13/20, 12/20, 12/20.','S37','Local unblinded AI-assisted scoring; batch and rendering differences prevent a causal manual-versus-automatic claim.'),('H37_02','Portuguese-query ranking','Contingency-plan probe succeeded in 3/3 versus 0/3 automatic controls.','S37','Known single question, no independent validation.'),('H37_03','Exception scope','Generic scope check passed 5/6 provisionally versus 0/6 controls.','S37','Two qualifications require human confirmation; malformed heading not isolated.'),('H37_04','Extra English cue','Probe and controls were English in 3/3; no full-task success in either.','S37','No incremental benefit; certificate-copy component remained absent.'),('H37_05','Format and reference scope','Formatter removed ten literal citation-format failures; three pairs have secondary frozen requirements flagged for review.','S36 and S37','Strict primary references retained; no human adjudication or semantic repair by formatter.')]
p=S/'data/current_adjudication/hypothesis_results_register.csv';rows=list(csv.DictReader(p.open()));fields=list(rows[0])
for ident,hyp,find,evid,limit in findings:rows.append(dict(zip(fields,[ident,hyp,find,evid,'Archived development data; historical primary and Howard scores retained',limit])))
with p.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
shutil.copy2(p,O/'analysis/hypothesis_results_register_updated.csv');shutil.copy2(p,P/'analysis/hypothesis_results_register_updated.csv')
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};qa=[]
for p in (S/'documents').glob('*.docx'):
 with zipfile.ZipFile(p) as z:
  x=etree.fromstring(z.read('word/document.xml'));txt=''.join(x.xpath('//w:t[not(ancestor::w:del)]/text()',namespaces=ns));assert '\u2013' not in txt and '\u2014' not in txt,p.name
  for r in x.xpath('//w:r[w:t or w:delText]',namespaces=ns):
   font=r.find('w:rPr/w:rFonts',ns);color=r.find('w:rPr/w:color',ns);assert font is not None and font.get('{'+ns['w']+'}ascii')=='Arial',p.name;assert color is not None and color.get('{'+ns['w']+'}val')=='000000',p.name
 qa.append(p.name)
(O/'analysis/format_QA.json').write_text(json.dumps({'Arial_black_no_accepted_en_em_dashes':qa},indent=2));shutil.copy2(O/'analysis/format_QA.json',P/'analysis/format_QA.json')
for name in ['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx']:shutil.copy2(O/'documents'/name,S/name)
readme=(prior/'README.md').read_text()+'\n## Automatic evidence follow-up S36 and S37, 31 October 2026\n\nAll 132 generations completed in 132 successful attempts, with no external judge or repair calls. Automatic-context full-task pair counts were 11/20, 10/20 and 12/20; the separate existing citation-formatter overlay yielded 13/20, 12/20 and 12/20. Portuguese-query reranking recovered the contingency-plan answer in 3/3 versus 0/3 controls; an exception-scope instruction passed 5/6 provisionally versus 0/6 controls. The extra English cue had no incremental benefit. These are local unblinded AI-assisted development assessments awaiting human confirmation. Historical batches are comparators, not randomized contemporaneous controls. Howard’s original 10/20 result remains unchanged.\n\nS36 documents missing-clause coverage, a malformed chapter prefix and missed article boundary, reference-scope flags and a stale split-chunk manifest field. The saved index has 359 intact records plus 122 chunks from 23 split records, totaling 481 nodes; 382 parsed source records include six preambles and repeated labels. Historical files and index remain intact. No parser or retrieval repair was deployed. A separate 12-call heading-only control is prepared but remains pending authorization; it has no results. Current-law verification, independent validation and human confirmation of the new tests remain open.\n'
(S/'README.md').write_text(readme)
with (S/'FILE_INDEX.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['relative_path','type','bytes'])
 for folder in ['documents','figures']:
  for p in sorted((S/folder).rglob('*')):
   if p.is_file():w.writerow([p.relative_to(S),p.suffix,p.stat().st_size])
for name,folders in [('supplementary_documents.zip',['documents','figures']),('revision_data.zip',['data'])]:
 with zipfile.ZipFile(S/name,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  for folder in folders:
   for p in sorted((S/folder).rglob('*')):
    if p.is_file():z.write(p,p.relative_to(S))
  if name.startswith('supplementary'):z.write(S/'FILE_INDEX.csv','FILE_INDEX.csv')
 with zipfile.ZipFile(S/name) as z:assert z.testzip() is None
names=['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_documents.zip','revision_data.zip','README.md']
with (S/'SHA256_MANIFEST.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['file','bytes','sha256'])
 for name in names:p=S/name;w.writerow([name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
local=B/'submission_package_automatic_20261031';local.mkdir(exist_ok=True)
for name in names+['SHA256_MANIFEST.csv','FILE_INDEX.csv']:shutil.copy2(S/name,local/name)
with zipfile.ZipFile(B/'submission_package_automatic_20261031.zip','w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in local.iterdir():z.write(p,p.name)
shutil.copytree(O/'documents',B/'current_documents',dirs_exist_ok=True);(R/'LATEST_REVISION.txt').write_text(str(O)+'\n');(O/'README_CURRENT_STATUS.txt').write_text(readme);shutil.copy2('/private/tmp/package_automatic.py',O/'package_automatic.py')
print(json.dumps({'documents':len(qa),'stage':str(S),'files':{n:(S/n).stat().st_size for n in names+['SHA256_MANIFEST.csv']}},indent=2))
