from pathlib import Path
import csv,json,hashlib,datetime,time,threading,concurrent.futures,re,shutil
import requests
from dotenv import dotenv_values
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');O=B/'repository/revisions/reviewer_2_20261021/outputs/automatic_evidence_followup_20261031';RAW=O/'raw_calls';RAW.mkdir(exist_ok=True);MODEL='gemini-3.5-flash-lite'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
protocol=json.loads((O/'PROTOCOL_BEFORE_CALLS.json').read_text());assert hashlib.sha256((O/'generation_inputs_132.jsonl').read_bytes()).hexdigest()==protocol['inputs_sha256'];assert protocol['generation_calls']==132 and protocol['judge_calls']==0
authorization=json.loads((O/'human_authorization.json').read_text());assert authorization['inputs_sha256']==protocol['inputs_sha256'] and authorization['generation_calls']==132
KEY=dotenv_values(B/'historical_workspace/Rag_project/.env').get('GOOGLE_API_KEY','');assert KEY,'Missing local Google credential'
inputs={x['call_id']:x for x in map(json.loads,(O/'generation_inputs_132.jsonl').read_text().splitlines())};plan=list(csv.DictReader((O/'generation_plan_132.csv').open()));assert len(inputs)==len(plan)==132
RATE=threading.Lock();LOCK=threading.Lock();STOP=threading.Event();NEXT=[0.];REASON=[''];endpoint=f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent'
shutil.copy2('/private/tmp/run_automatic_followup.py',O/'executed_run.py')
def pace():
 with RATE:
  if STOP.is_set():raise RuntimeError('stopped_before_submission')
  delay=max(0,NEXT[0]-time.monotonic())
  if delay:time.sleep(delay)
  if STOP.is_set():raise RuntimeError('stopped_before_submission')
  NEXT[0]=time.monotonic()+4.3

def call(item):
 stem=item['call_id'];prompt=item['prompt'];digest=hashlib.sha256(prompt.encode()).hexdigest();assert digest==item['prompt_sha256'];previous=sorted(RAW.glob(stem+'_attempt*.json'))
 for p in previous:
  x=json.loads(p.read_text());assert x['prompt_sha256']==digest
  if x.get('http_status')==200 and x.get('answer') and x.get('modelVersion')==MODEL:return x['answer'],{'raw_file':str(p.relative_to(O)),'modelVersion':MODEL,'prompt_sha256':digest,'reused':True}
 for attempt in range(len(previous)+1,4):
  pace();p=RAW/(stem+f'_attempt{attempt}.json');record={'id':stem,'attempt':attempt,'started_utc':now(),'prompt_sha256':digest,'temperature':.2}
  try:
   response=requests.post(endpoint,headers={'x-goog-api-key':KEY,'Content-Type':'application/json'},json={'contents':[{'role':'user','parts':[{'text':prompt}]}],'generationConfig':{'temperature':.2}},timeout=120)
   record['http_status']=response.status_code
   try:raw=response.json()
   except ValueError:raw={'non_json_response':response.text[:1000]}
   record['response']=raw;record['finished_utc']=now()
   if response.status_code==200:
    answer=''.join(y.get('text','') for c in raw.get('candidates',[])[:1] for y in c.get('content',{}).get('parts',[]) if not y.get('thought'));record.update(answer=answer,modelVersion=raw.get('modelVersion'),responseId=raw.get('responseId'));p.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    if raw.get('modelVersion')!=MODEL:STOP.set();REASON[0]='model_version_mismatch';raise RuntimeError(REASON[0])
    if answer:return answer,{'raw_file':str(p.relative_to(O)),'modelVersion':MODEL,'prompt_sha256':digest,'responseId':raw.get('responseId'),'reused':False}
   else:
    p.write_text(json.dumps(record,ensure_ascii=False,indent=2));err=raw.get('error',{});daily=any('perday' in str(v.get('quotaId','')).lower() for d in err.get('details',[]) for v in d.get('violations',[]))
    if daily or response.status_code in [400,401,403,404]:STOP.set();REASON[0]='daily_quota_exhausted' if daily else 'non_retryable_http_'+str(response.status_code);raise RuntimeError(REASON[0])
    if response.status_code not in [429,500,502,503,504]:raise RuntimeError('unexpected_http_'+str(response.status_code))
    for d in err.get('details',[]):
     if d.get('@type','').endswith('RetryInfo'):
      delay=float(re.sub('[^0-9.]','',d.get('retryDelay','0s')) or 0)
      with RATE:NEXT[0]=max(NEXT[0],time.monotonic()+delay+1)
  except requests.RequestException as e:
   record.update(finished_utc=now(),error_type=type(e).__name__);p.write_text(json.dumps(record,indent=2))
  if attempt<3:time.sleep(min(15,5*attempt))
 raise RuntimeError('attempts_exhausted')
def task(row):
 item=inputs[row['call_id']];out={k:item[k] for k in ['call_id','id','pair_id','language','condition','prompt_sha256']};out.update(sequence=int(row['sequence']),error='')
 try:out['answer'],out['generation_metadata']=call(item)
 except Exception as e:out['error']=str(e) if isinstance(e,RuntimeError) else type(e).__name__
 with LOCK:
  with (O/'results_checkpoint.jsonl').open('a') as f:f.write(json.dumps(out,ensure_ascii=False)+'\n')
  current={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())};n=sum(bool(x.get('answer')) and not x['error'] for x in current.values());(O/'run_status.json').write_text(json.dumps({'status':'stopped' if STOP.is_set() else 'running','updated_utc':now(),'complete_answers':n,'target':len(inputs),'judge_calls':0,'stop_reason':REASON[0]},indent=2));print('saved',out['id'],'complete',n,'error',out['error'],flush=True)
 return out
existing={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())} if (O/'results_checkpoint.jsonl').exists() else {};todo=[x for x in plan if not (existing.get(x['call_id'],{}).get('answer') and not existing[x['call_id']]['error'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 it=iter(todo);pending={}
 for _ in range(2):
  row=next(it,None)
  if row:pending[ex.submit(task,row)]=row
 while pending:
  done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
  for f in done:
   pending.pop(f);f.result()
   if not STOP.is_set():
    row=next(it,None)
    if row:pending[ex.submit(task,row)]=row
current={x['call_id']:x for x in map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines())};n=sum(bool(x.get('answer')) and not x['error'] for x in current.values());status={'status':'complete' if n==len(inputs) else 'blocked' if STOP.is_set() else 'incomplete','updated_utc':now(),'complete_answers':n,'target':len(inputs),'judge_calls':0,'stop_reason':REASON[0],'errors':{k:x['error'] for k,x in current.items() if x['error']},'http_attempt_records':len(list(RAW.glob('*.json')))};(O/'run_status.json').write_text(json.dumps(status,indent=2));print(json.dumps(status),flush=True)
