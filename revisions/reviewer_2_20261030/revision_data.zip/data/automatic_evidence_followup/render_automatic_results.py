from pathlib import Path
import json,subprocess,concurrent.futures
O=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/automatic_evidence_followup_20261031');changed=json.loads((O/'analysis/document_projection_QA.json').read_text())['changed_documents'];P='/Users/cmontefusco/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';S='/Users/cmontefusco/.codex/plugins/cache/openai-primary-runtime/documents/26.1024.11018/skills/documents/render_docx.py'
def run(n):
 out=Path('/private/tmp/automatic_final_render')/Path(n).stem;out.mkdir(parents=True,exist_ok=True);r=subprocess.run([P,S,str(O/'documents'/n),'--output_dir',str(out),'--emit_pdf'],capture_output=True,text=True);(out/'render.log').write_text(r.stdout+r.stderr);return [n,r.returncode,len(list(out.glob('page-*.png')))]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:
 for x in e.map(run,changed):print(json.dumps(x),flush=True)
