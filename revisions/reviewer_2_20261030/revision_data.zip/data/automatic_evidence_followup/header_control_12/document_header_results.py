from pathlib import Path
import json,shutil,ast,datetime,re,difflib
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/automatic_evidence_followup_20261031';H=O/'header_control_12';D=O/'documents'
archive=H/'pre_heading_documents'
if not archive.exists():shutil.copytree(D,archive)
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=12000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
def settext(p,text):
 for x in list(p):
  if x.tag!=qn('w:pPr'):p.remove(x)
 r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=text;t.set(qn('xml:space'),'preserve');r.append(t);p.append(r)
result='In a separate heading control, 12 further generations changed only the erroneous Article 41 prefix to the exact archived Chapter IV heading, with and without the previously tested exception-scope instruction (three repeats per language and condition). All 12 completed in 12 attempts. Local AI-assisted inspection found all required content, requested language and literal citations in 6/6 heading-only outputs versus 0/6 saved automatic controls, and in 6/6 heading-plus-scope outputs versus 5/6 saved scope-check controls. Both corrected-heading conditions passed the bilingual pair in all three repeats. These are repeated answers to one known bilingual question, with controls from an earlier batch; they do not estimate independent validation performance.'
disc='The isolated heading control supports a context-structure explanation for the phase III failure: correcting the prefix was sufficient for acceptable answers in all six heading-only outputs, without the extra exception instruction. Adding that instruction showed no further full-task gain after heading correction. The findings are compatible with a misleading pathway heading contributing to blanket refusal and exception-scope errors, but earlier-batch controls leave stochastic and temporal variation unresolved. The test changes a supplied context prefix; it does not demonstrate that a rebuilt parser or retrieval index is reliable. No system repair was deployed, and human confirmation remains pending.'
changed=[]
for name in ['manuscript_clean.docx','manuscript_tracked.docx']:
 d=Document(archive/name)
 for p in d.paragraphs:
  a=acc(p._p)
  if a.startswith('Automatic evidence and residual-failure follow-up.'):
   new=a+' A separately authorized 12-call control then replaced only the Article 41 prefix with its exact archived heading, with and without the same scope instruction; the 12 previously generated controls were reused.'
  elif a.startswith('The automatic context audit covered'):
   new=a+' '+result
  elif a.startswith('Automatic article completion repaired'):
   new=a.replace('A separately prepared heading-only control remains outside the completed 132-call experiment.','The separately completed 12-call heading control is reported outside the original 132-call experiment.')+' '+disc
  else:continue
  if 'tracked' in name:redline(p._p,rej(p._p),new)
  else:settext(p._p,new)
 d.save(D/name);changed.append(name)
d=Document(archive/'response_to_reviewer_2.docx')
for p in d.paragraphs:
 if p.text.startswith('The post-calibration set shares'):p.text+=' The separate 12-call heading control is now complete. Replacing only the false Article 41 prefix with the archived Chapter IV heading yielded 6/6 acceptable outputs versus 0/6 earlier automatic controls. With the scope check, the corresponding counts were 6/6 versus 5/6. Each cell contains three Portuguese and three English answers to one known question, not six independent items. This supports a misleading-heading explanation but does not remove cross-batch uncertainty or demonstrate a deployed parser repair. Human confirmation remains pending.'
d.save(D/'response_to_reviewer_2.docx');changed.append('response_to_reviewer_2.docx')
d=Document(archive/'supplementary_automatic_answer_followup_S37.docx')
for p in d.paragraphs:
 if p.text=='Pending isolated heading control':p.text='Completed isolated heading control'
 elif p.text.startswith('After the structural audit, a separate 12-call protocol'):p.text=result+' '+disc
 elif 'A separately prepared heading-only control remains outside' in p.text:p.text=p.text.replace('A separately prepared heading-only control remains outside the completed 132-call experiment.','The separately completed 12-call heading control is reported outside the original 132-call experiment.')
d.add_heading('Heading control comparison',1);t=d.add_table(rows=1,cols=4);t.style='Table Grid'
for c,v in zip(t.rows[0].cells,['Heading','Scope instruction','Acceptable outputs','Timing']):c.text=v
for vals in [('Incorrect','Absent','0/6','Saved controls'),('Incorrect','Present','5/6','Saved controls'),('Correct Chapter IV','Absent','6/6','New calls'),('Correct Chapter IV','Present','6/6','New calls')]:
 for c,v in zip(t.add_row().cells,vals):c.text=v
d.add_paragraph('Every cell includes the same English and Portuguese question, with three repeats per language. New answers were inspected locally without external judge calls. All 12 used the requested language and exact article citation; none denied the individual-development pathway or refused the task. The chapter prefix was the only context change. The original 132-call scores and Howard ratings are preserved. The generic scope instruction added no observed pass-count benefit once the heading was corrected.')
d.save(D/'supplementary_automatic_answer_followup_S37.docx');changed.append('supplementary_automatic_answer_followup_S37.docx')
# Update any pending heading statement in the structural audit without rewriting the audit history.
d=Document(archive/'supplementary_automatic_evidence_audit_S36.docx');n=0
for p in d.paragraphs:
 if '12-call' in p.text or 'heading-only' in p.text:
  p.text=p.text.replace('A separately prepared heading-only generation control is required to isolate their effect on answers.','The subsequent heading-only control is reported in S37 and in the addendum below.')
d.add_heading('Subsequent heading control',1);d.add_paragraph('The separately authorized 12-call control subsequently completed in 12 attempts. Correcting only the Article 41 prefix yielded acceptable content, language and citations in 6/6 outputs without the scope instruction and 6/6 with it, versus 0/6 and 5/6 saved controls respectively. These are provisional local AI-assisted assessments of one known bilingual question. S37 retains the protocol, results and cross-batch limitations; the parser prototype and index were not deployed or rebuilt.')
d.save(D/'supplementary_automatic_evidence_audit_S36.docx');changed.append('supplementary_automatic_evidence_audit_S36.docx')
for name in changed:
 d=Document(D/name)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 d.save(D/name)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True);assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(H/'analysis/document_projection_QA.json').write_text(json.dumps({'accept_matches_clean':True,'reject_matches_submission_baseline':True,'changed_documents':changed},indent=2));shutil.copy2('/private/tmp/document_header_results.py',H/'document_header_results.py');print('Projections passed',changed)
