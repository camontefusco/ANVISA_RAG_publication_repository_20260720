from pathlib import Path
import json,csv,shutil,ast,re,difflib,datetime
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/automatic_evidence_followup_20261031';C=R/'outputs/combined_repair_comparison_20261031';A=R/'outputs/offline_retrieval_scoring_audit_20261031';D=O/'documents';D.mkdir(exist_ok=True);shutil.copytree(C/'documents',D,dirs_exist_ok=True);shutil.copy2(A/'documents/supplementary_automatic_evidence_audit_S36.docx',D/'supplementary_automatic_evidence_audit_S36.docx')
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=11000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
def settext(p,text):
 for x in list(p):
  if x.tag!=qn('w:pPr'):p.remove(x)
 r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=text;t.set(qn('xml:space'),'preserve');r.append(t);p.append(r)
replacements={'382 articles and 481 chunks':'382 parsed source records and 481 chunks','382 articles, 481 chunks':'382 parsed source records, 481 chunks','382 articles;':'382 parsed source records;','382 article records':'382 parsed source records','382 detected regulatory articles':'382 parsed source records','382 detected articles':'382 parsed source records','359 articles remained intact and 23 were split':'359 source records remained intact and 23 were split','359 single-chunk articles and 23 long articles':'359 single-chunk source records and 23 long source records'};changed=[]
for f in D.glob('*.docx'):
 d=Document(f);n=0
 for p in d._element.iter(qn('w:p')):
  old=acc(p);new=old
  for a,b in replacements.items():new=new.replace(a,b)
  if old=='Detected articles':new='Parsed source records including preambles'
  if new!=old:
   if 'tracked' in f.name:redline(p,rej(p),new)
   else:settext(p,new)
   n+=1
 if n:d.save(f);changed.append(f.name)
methods='Automatic evidence and residual-failure follow-up. A reference-blind local audit completed selected articles with all indexed sibling chunks and, separately, adjacent articles. Archived reference fragments were evaluated only after selection using normalized word five-gram coverage. A cached reranker trace compared the original English contingency-plan query with a faithful Portuguese translation on the same 100 candidates. We then froze 132 new generations: 120 on all 40 questions with automatic article completion and neighbors, three with a final English cue, six with an exception-scope check, and three with Portuguese-query reranking (S36 and S37). Model, temperature and repeat count remained unchanged. No judge or repair calls were made. Prior S35 answers were historical comparators, not newly randomized controls. Local AI-assisted inspection retained frozen reference components; raw scores and a separate overlay using the repository\u2019s existing deterministic citation formatter were reported separately. The formatter changes citation labels, not answer wording or semantic assessments.'
results='The automatic context audit covered all archived reference-fragment wording in 20/32 positive question rows with saved contexts, 26/32 with unconditional article completion and 31/32 with adjacent articles; these are lexical screens, not answer-quality scores. Mean positive-row context length increased from 5748 to 17403 characters. The remaining AV_008 English provision was candidate 46 and reranker rank 6; translating the query to Portuguese moved it to rank 1. All 132 follow-up generations completed in 132 attempts. Automatic-context raw full-task pair counts were 11/20, 10/20 and 12/20 across repeats, with 10/20 pairs passing all repeats. Citation normalization yielded 13/20, 12/20 and 12/20, with 11/20 passing all repeats. Raw format failures fell from 10/120 to zero in that overlay, while six wrong-language outputs remained. The ranking probe recovered the contingency-plan task in 3/3 outputs versus 0/3 controls. The exception-scope probe met frozen task criteria in 5/6 outputs versus 0/6 controls, although pathway-scope qualifications require human confirmation. The final English cue added no language gain: its three responses and all three automatic controls were English, while the frozen certificate-copy component remained omitted. These provisional development outcomes are not human-confirmed improvement estimates.'
discussion='Automatic article completion repaired many clause omissions, but larger contexts did not reproduce the manually supplemented S35 performance. The comparison is across batches and changes context composition and metadata rendering, so it does not isolate a causal loss. Cross-language ranking explained the missing contingency-plan provision in the selected case, while the additional English cue showed no incremental benefit. Exception interpretation improved under a generic scope instruction, but a separate source-processing defect remains: the index prefixes RDC 55/2010 Article 41 with inline references to another chapter and sections, while the archived source places it under Chapter IV, the individual-development pathway. The article parser also misses Art 37 without a dot. A local prototype recovered that boundary and corrected the Article 41 heading; it screened 61 boundary or metadata differences but was not deployed or used to rebuild the index. A separately prepared heading-only control remains outside the completed 132-call experiment. The reference-scope audit flags secondary components in AV_013, AV_014 and AV_016 without changing golds or primary scores. Other strict omissions include the successive-renewal wording in one AV_010 answer and the specific-guide component in one AV_012 answer. Human review should distinguish these completeness judgments from unsupported claims and wrong-task answers. In the earlier S35 outputs, the existing citation formatter alone raised combined pair counts to 16/20 in every repeat, including one partly answerable pair; raw S35 scores remain unchanged. These results support specific, limited explanations rather than a fully validated system repair.'
for name in ['manuscript_clean.docx','manuscript_tracked.docx']:
 d=Document(D/name)
 for anchor,text in [('Results',methods),('Summary of quantitative evaluation',results)]:
  target=next(p for p in d.paragraphs if acc(p._p)==anchor);p=target.insert_paragraph_before('')
  if 'tracked' in name:redline(p._p,'',text)
  else:p.text=text
 target=next(p for p in d.paragraphs if acc(p._p).startswith('The combined comparison shows that supplying complete'));p=OxmlElement('w:p');target._p.addnext(p)
 if 'tracked' in name:redline(p,'',discussion)
 else:settext(p,discussion)
 # Clarify the count unit without altering source counts or historical index.
 target=next(p for p in d.paragraphs if acc(p._p).startswith('The final index contained six ANVISA'))
 old=acc(target._p);new=old.replace('382 parsed source records,','382 parsed source records, including six preambles and repeated article labels,',1)
 if 'tracked' in name:redline(target._p,rej(target._p),new)
 else:target.text=new
 d.save(D/name)
 changed.append(name)
d=Document(D/'response_to_reviewer_2.docx')
for p in d.paragraphs:
 if p.text.startswith('The post-calibration set shares'):p.text+=' Local audit S36 and the 132-generation follow-up S37 now distinguish article completion, query ranking, exception scope, language and citation formatting. Automatic-context raw pair counts were 11/20, 10/20 and 12/20; the separate formatter overlay yielded 13/20, 12/20 and 12/20. Portuguese-query reranking recovered the contingency-plan answer in 3/3 versus 0/3 controls, the exception-scope check met frozen criteria in 5/6 versus 0/6, and an extra English cue added no observed benefit. A misparsed chapter prefix and missed Art37 boundary are documented as structural limitations, not silently repaired. Question/reference scope flags remain for human confirmation. All original ratings and raw scores are preserved.'
 if p.text.startswith('Figure 3B bars start at zero'):p.text+=' Corpus terminology and Figure 1 now distinguish 382 parsed source records, including preambles and repeated labels, from unique legal articles; the frozen index still contains 481 chunks.'
d.save(D/'response_to_reviewer_2.docx');changed.append('response_to_reviewer_2.docx')
d=Document(C/'documents/supplementary_combined_repair_S35.docx')
for x in list(d._element.body):
 if x.tag!=qn('w:sectPr'):d._element.body.remove(x)
d.add_paragraph('Automatic evidence and residual failure tests',style='Title');d.add_paragraph('Supplementary S37   Completed 31 October 2026   Provisional AI assisted assessment')
d.add_paragraph('This follow-up tests whether automatic assembly of indexed evidence can recover the manually supplemented development performance, then examines three residual explanations. All 132 calls completed without retries. It retains raw answers, strict frozen-reference scores and a separate deterministic-format overlay. Howard has not confirmed these new assessments.')
for h,t in [('Frozen design',methods),('Completed results',results),('Interpretation and residual limitations',discussion)]:d.add_heading(h,1);d.add_paragraph(t)
d.add_heading('Raw and normalized pair counts',1);t=d.add_table(rows=1,cols=4);t.style='Table Grid'
for c,v in zip(t.rows[0].cells,['Outcome','Repeat 1','Repeat 2','Repeat 3']):c.text=v
for vals in [('Raw full task','11/20','10/20','12/20'),('Citation normalized','13/20','12/20','12/20'),('Raw answerable','7/12','7/12','8/12'),('Raw partly answerable','1/4','0/4','1/4'),('Normalized partly answerable','1/4','1/4','1/4'),('Unanswerable in requested language','3/4','3/4','3/4')]:
 for c,v in zip(t.add_row().cells,vals):c.text=v
for i,row in enumerate(t.rows):
 for c in row.cells:
  for p in c.paragraphs:p.paragraph_format.keep_with_next=i<len(t.rows)-1
hr=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(hr)
d.add_paragraph('Exact 95% intervals are 31.5 to 76.9% for 11/20, 27.2 to 72.8% for 10/20, 36.1 to 80.9% for 12/20 and 40.8 to 84.6% for 13/20. Repeats are not independent questions. Raw output passes were 75/120 and normalized output passes 82/120. Six wrong-language answers were Portuguese responses to AV_002 English and AV_020 English, three each. AV_011 Portuguese instead produced three blanket refusals. The automatically supplied Article 41 retained the incorrect chapter prefix.')
d.add_heading('Targeted probes',1);d.add_paragraph('The Portuguese-query probe changed only reranking on the frozen candidate pool, followed by the same automatic completion, while the user question and response language remained English. It answered the contingency task in 3/3 versus 0/3 automatic controls. The exception-scope check corrected the English exception attachment in all three repeats and supplied the frozen content in two Portuguese repeats; one Portuguese repeat still denied the requested pathway scope. These five provisional passes include two scope qualifications that need human confirmation. Both the English-cue probe and its controls were English in 3/3, so there was no language gain; none supplied the frozen certificate-copy component.')
d.add_heading('Secondary components and preserved failures',1);d.add_paragraph('All API lists and low-risk literature answers recovered their main requested content, but complementary-act deferral and general low-risk eligibility framing remained omitted. No certificate-copy component was supplied for AV_016. One AV_010 English answer used successfully instead of successively and did not explicitly state repeated renewals; one AV_012 English answer omitted specific guides. The frozen scoring components are retained, with question-scope and wording decisions identified for later human review. Article 14 VI independently repeats the compulsory-certification applicability language, so AV_016 statements citing it are source-supported; they are not mislabeled as citation-support errors. Literal citation format remains a separate dimension.')
d.add_heading('Pending isolated heading control',1);d.add_paragraph('After the structural audit, a separate 12-call protocol was prepared on AV_011 English and Portuguese. It replaces only the false Article 41 prefix with the exact archived Chapter IV heading, with and without the same exception-scope instruction, and reuses the 12 previous controls. Its results are not part of the completed 132 calls and are not assumed here. The original source, index, primary benchmark and Howard ratings remain unchanged.')
d.add_heading('Retained records and human confirmation',1);d.add_paragraph('The data package retains the protocol frozen before calls, all 132 prompts and answers, all attempt records, automatic node selections, local annotations, raw and normalized output scores, bilingual pair scores and targeted-probe results. All 99 unique answer groups were inspected; 90 substantive groups received semantic annotations and nine canonical-refusal groups were checked for category, language and formatting. No external judge, repair generation, billing change or model substitution occurred. Human confirmation remains deferred until the technical package and reference-scope decisions are ready for consolidated review.')
d.save(D/'supplementary_automatic_answer_followup_S37.docx');changed+=['supplementary_automatic_evidence_audit_S36.docx','supplementary_automatic_answer_followup_S37.docx']
for name in set(changed):
 f=D/name;d=Document(f)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 for el in list(d._element.iter(qn('w:pBdr')))+list(d.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
 d.save(f)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True);assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(O/'analysis/document_projection_QA.json').write_text(json.dumps({'accept_matches_clean':True,'reject_matches_submission_baseline':True,'changed_documents':sorted(set(changed))},indent=2));shutil.copy2('/private/tmp/document_automatic_results.py',O/'document_automatic_results.py');print('Updated',len(set(changed)),'documents; projections passed.')
