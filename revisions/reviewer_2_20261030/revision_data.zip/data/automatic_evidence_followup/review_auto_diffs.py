from pathlib import Path
import json,csv,difflib,re,sys
R=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021');O=R/'outputs/automatic_evidence_followup_20261031';C=R/'outputs/combined_repair_comparison_20261031';prior=list(csv.DictReader((C/'analysis/outputs_scored.csv').open()));rows=list(csv.DictReader((O/'analysis/unique_answers_FOR_AI_REVIEW.csv').open()));lo=int(sys.argv[1]) if len(sys.argv)>1 else 1;hi=int(sys.argv[2]) if len(sys.argv)>2 else 20
seenfile=Path('/private/tmp/auto_reviewed_hashes.json');seen=set(json.loads(seenfile.read_text())) if seenfile.exists() else set()
for r in rows:
 key=r['id']+':'+r['answer_sha256']
 if key in seen or r['canonical_refusal']=='True' or not lo<=int(r['id'][3:6])<=hi:continue
 pp=[x for x in prior if x['id']==r['id']];p=max(pp,key=lambda x:difflib.SequenceMatcher(None,x['answer'],r['answer']).ratio());print('\nNEW',r['id'],r['answer_sha256'][:12],r['conditions']);print('PRIOR',p['condition'],p['repeat'],'semantic',p['semantic_pass_AI_inspection'],'language',p['language_pass_AI_inspection']);a=re.findall(r'\S+',p['answer']);b=re.findall(r'\S+',r['answer']);sm=difflib.SequenceMatcher(None,a,b,autojunk=False);changes=[(' '.join(a[i:j]),' '.join(b[k:l])) for tag,i,j,k,l in sm.get_opcodes() if tag!='equal'];ratio=difflib.SequenceMatcher(None,p['answer'],r['answer']).ratio()
 if ratio<.65 or int(r['id'][3:6]) in [11,13,14,16]:print(r['answer'])
 else:print(' | '.join('['+x+'] => ['+y+']' for x,y in changes))
 seen.add(key)
seenfile.write_text(json.dumps(sorted(seen)))
