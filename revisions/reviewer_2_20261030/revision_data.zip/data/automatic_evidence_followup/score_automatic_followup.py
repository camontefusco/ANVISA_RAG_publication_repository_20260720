from pathlib import Path
import csv,json,re,ast,hashlib,collections
from scipy.stats import beta
R=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021');O=R/'outputs/automatic_evidence_followup_20261031';A=O/'analysis';inputs={x['call_id']:x for x in map(json.loads,(O/'generation_inputs_132.jsonl').read_text().splitlines())};rr=list(csv.DictReader((A/'mechanical_screens.csv').open()));annotations=[];lookup={}
for x in csv.DictReader((A/'unique_answers_FOR_AI_REVIEW.csv').open()):
 if x['canonical_refusal']=='True':continue
 n=int(x['id'][3:6]);h=x['answer_sha256'];sem=True;note='Required components and material claims inspected against the frozen reference and selected indexed evidence. Citation formatting scored separately.'
 if n==8 and 'Portuguese_question_reranked_then_expanded' not in x['conditions']:sem=False;note='Wrong requested task: describes Risk Management or Risk Minimization rather than the contingency plan; the direct Article9 is absent from this automatic context.'
 if n==10 and h.startswith('45e5888e'):sem=False;note='Provides ten years, publication and equal-period revalidation, but says successfully rather than successively and omits explicit repeatability required by the frozen reference. Narrow yes/no renewal content is present; human scope/wording review pending.'
 if n==11:
  if x['id'].endswith('EN') and 'automatic_plus_exception_scope_check' not in x['conditions']:sem=False;note='Incorrectly attaches product exceptions to requiring phaseIII studies rather than to comparative design.'
  if h.startswith('bc2f8018'):sem=False;note='Denies the requested individual-pathway scope and omits the always-necessary requirement. The frozen index contains a misparsed chapter prefix; preserve this source-context limitation.'
  if h.startswith(('82b00f55','baf3e381')):note='States always necessary and comparative design with listed exceptions. Adds a qualification about absent pathway-specific detail; main frozen content is present, but scope qualification and corrupt heading require later human confirmation.'
 if n==12 and h.startswith('d4d446bc'):sem=False;note='Covers the four substantive comparability conditions but omits the frozen caput component that extrapolation is established through specific guides.'
 if n==13:sem=False;note='Recovers all seven API categories and withholds numeric limits, but omits frozen Article29 complementary-act deferral. Secondary-component scope flag retained.'
 if n==14:sem=False;note='Recovers literature evidence requirement but omits frozen general phase3/known-safety/minimal-risk framing; one Portuguese output also fails to identify absent indexing databases. Secondary scope flag retained.'
 if n==15:note='Both update triggers, electronic submission and absent deadline are present. Literal citation errors remain a separate endpoint.'
 if n==16:sem=False;note='Supplies Article12 condition but omits the frozen certificate-copy component; explicit missing-list identification varies. Article14VI also contains the compulsory-certification applicability wording, so citing it for that statement is supported, not a source error. Secondary scope flag retained.'
 if n>=17:sem=False;note='Unexpected substantive response to an unanswerable task; requires human review.'
 lang=next(z['language_screen_compliant']=='True' for z in rr if z['id']==x['id'] and z['answer_sha256']==h)
 row={'id':x['id'],'answer_sha256':h,'semantic_pass':sem,'language_pass':lang,'notes':note,'assessment_provenance':'Local unblinded AI-assisted inspection of all substantive answer variants; no new human review'};annotations.append(row);lookup[(x['id'],h)]=row
with (A/'semantic_annotations.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=annotations[0]);w.writeheader();w.writerows(annotations)
source=(R.parent.parent/'evaluation/answer_quality.py').read_text();tree=ast.parse(source);names={'CITATION_RE','LOOSE_ARTICLE_CITATION_RE'};body=[n for n in tree.body if (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name in {'normalize_citation','sanitize_answer_citations'})];ns={'re':re};exec(compile(ast.Module(body=body,type_ignores=[]),'existing_formatter','exec'),ns)
scored=[]
for x in rr:
 ref=x['canonical_refusal_ignoring_citations']=='True';ann=lookup.get((x['id'],x['answer_sha256']));sem=(x['category']=='unanswerable') if ref else ann['semantic_pass'];lang=x['language_screen_compliant']=='True';fmt=x['citation_labels_exact']=='True' and x['refusal_has_citation']=='False' and (ref or x['has_article_citation']=='True');allowed=re.findall(r'^citation_label: (.+)$',inputs[x['call_id']]['context'],re.M);fixed=ns['sanitize_answer_citations'](x['answer'],allowed);labs=re.findall(r'\[([^\]\n]+)\]',fixed);nf=all(z in allowed for z in labs) and not(ref and labs) and (ref or any(', Art.' in z for z in labs));assert re.sub(r'\[[^\[\]]+\]','',fixed)==re.sub(r'\[[^\[\]]+\]','',x['answer'])
 scored.append(x|{'semantic_pass_AI_inspection':sem,'language_pass_AI_inspection':lang,'format_pass':fmt,'full_task_pass_AI_inspection':sem and lang and fmt,'semantic_notes':ann['notes'] if ann else 'Canonical refusal; assess frozen category and requested language.','normalized_answer':fixed,'normalized_format_pass':nf,'normalized_full_task_pass_AI_inspection':sem and lang and nf,'normalization_changed':fixed!=x['answer'],'assessment_provenance':'Local unblinded AI-assisted development inspection; human review pending'})
assert len(scored)==132
with (A/'outputs_scored.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=scored[0]);w.writeheader();w.writerows(scored)
base=[x for x in scored if x['condition']=='automatic_expansion'];pairs=[]
for rep in [1,2,3]:
 for pid in sorted({x['pair_id'] for x in base}):
  z=[x for x in base if x['pair_id']==pid and int(x['repeat'])==rep];assert len(z)==2;pairs.append({'pair_id':pid,'repeat':rep,'category':z[0]['category'],'raw_pass':all(x['full_task_pass_AI_inspection'] for x in z),'normalized_pass':all(x['normalized_full_task_pass_AI_inspection'] for x in z)})
with (A/'pair_results_60.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=pairs[0]);w.writeheader();w.writerows(pairs)
def ci(k,n):return [float(beta.ppf(.025,k,n-k+1)) if k else 0,float(beta.ppf(.975,k+1,n-k)) if k<n else 1]
summary={'calls':132,'judge_calls':0,'attempts':132,'unique_answer_groups':99,'substantive_groups_annotated':len(annotations),'assessment':'Provisional local AI-assisted; known development questions; historical comparison across batches, no causal gain estimate','automatic':{}}
for key in ['raw_pass','normalized_pass']:
 summary['automatic'][key]={'per_repeat':[],'categories':{},'robust_all_repeats':sum(all(x[key] for x in pairs if x['pair_id']==pid) for pid in sorted({x['pair_id'] for x in pairs}))}
 for rep in [1,2,3]:
  z=[x for x in pairs if x['repeat']==rep];k=sum(x[key] for x in z);summary['automatic'][key]['per_repeat'].append({'repeat':rep,'pass':k,'n':20,'exact_95_interval':ci(k,20)})
 for cat in ['answerable','partly_answerable','unanswerable']:summary['automatic'][key]['categories'][cat]=[sum(x[key] for x in pairs if x['category']==cat and x['repeat']==rep) for rep in [1,2,3]]
summary['automatic'].update({'wrong_language':sum(not x['language_pass_AI_inspection'] for x in base),'raw_format_failures':sum(not x['format_pass'] for x in base),'normalized_format_failures':sum(not x['normalized_format_pass'] for x in base),'raw_output_passes':sum(x['full_task_pass_AI_inspection'] for x in base),'normalized_output_passes':sum(x['normalized_full_task_pass_AI_inspection'] for x in base)})
summary['probes']={}
for c in sorted(set(x['condition'] for x in scored)-{'automatic_expansion'}):
 z=[x for x in scored if x['condition']==c];ids={x['id'] for x in z};control=[x for x in base if x['id'] in ids];summary['probes'][c]={'n':len(z),'raw_full_task':sum(x['full_task_pass_AI_inspection'] for x in z),'normalized_full_task':sum(x['normalized_full_task_pass_AI_inspection'] for x in z),'semantic_pass':sum(x['semantic_pass_AI_inspection'] for x in z),'language_pass':sum(x['language_pass_AI_inspection'] for x in z),'control_n':len(control),'control_raw_full_task':sum(x['full_task_pass_AI_inspection'] for x in control),'control_semantic_pass':sum(x['semantic_pass_AI_inspection'] for x in control),'control_language_pass':sum(x['language_pass_AI_inspection'] for x in control)}
summary['limits']=['No primary raw or original Howard score changed','Raw/normalized endpoints kept separate','Scope of secondary gold components still awaits human confirmation','Parser prototype not included in frozen generation contexts','Larger contexts and changed metadata rendering may affect answers','No deployment, current-law or independent generalization claim']
(A/'analysis_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
