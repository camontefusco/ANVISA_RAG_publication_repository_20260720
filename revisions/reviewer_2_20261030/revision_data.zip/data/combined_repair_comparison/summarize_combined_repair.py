from pathlib import Path
import json,csv,collections,hashlib
import numpy as np
from scipy.stats import beta
O=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/combined_repair_comparison_20261031');A=O/'analysis'
read=lambda p:list(csv.DictReader(p.open()))
r=read(A/'mechanical_screens.csv');notes=read(A/'semantic_annotations.csv') if (A/'semantic_annotations.csv').exists() else [];annotations={(x['id'],x['answer_sha256']):x for x in notes};scored=[]
for x in r:
 a=annotations.get((x['id'],x['answer_sha256']));ref=x['canonical_refusal_ignoring_citations']=='True';n=x['category']=='unanswerable';format_ok=x['citation_labels_exact']=='True' and x['refusal_has_citation']=='False' and (ref or x['has_article_citation']=='True');lang=x['language_screen_compliant']=='True';semantic=None;note=''
 if ref:semantic=n;note='Canonical refusal: correct only for frozen unanswerable task; full answerable or partly answerable task fails.'
 elif a:semantic=a['semantic_pass']=='True';note=a['notes'];lang=a['language_pass']=='True'
 full=semantic and format_ok and lang if semantic is not None else None
 scored.append(x|{'semantic_pass_AI_inspection':semantic,'language_pass_AI_inspection':lang,'format_pass':format_ok,'full_task_pass_AI_inspection':full,'semantic_notes':note,'assessment_provenance':'Local unblinded AI-assisted assessment; no new human rating'})
with (A/'outputs_scored.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=scored[0]);w.writeheader();w.writerows(scored)
missing=[x['call_id'] for x in scored if x['full_task_pass_AI_inspection'] is None]
if len(scored)!=240 or missing:print(json.dumps({'outputs':len(scored),'semantic_review_missing':len(missing),'incomplete':True}));raise SystemExit
pairs=[]
for condition in ['original_saved','combined_oracle_evidence']:
 for repeat in [1,2,3]:
  for pid in sorted(set(x['pair_id'] for x in scored)):
   rr=[x for x in scored if x['condition']==condition and int(x['repeat'])==repeat and x['pair_id']==pid];assert len(rr)==2
   pairs.append({'pair_id':pid,'category':rr[0]['category'],'condition':condition,'repeat':repeat,'pair_pass':all(x['full_task_pass_AI_inspection'] for x in rr)})
with (A/'pair_results_120.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=pairs[0]);w.writeheader();w.writerows(pairs)
def interval(k,n):return [float(beta.ppf(.025,k,n-k+1)) if k else 0,float(beta.ppf(.975,k+1,n-k)) if k<n else 1]
summary={}
for condition in ['original_saved','combined_oracle_evidence']:
 rr=[x for x in scored if x['condition']==condition];pp=[x for x in pairs if x['condition']==condition];cats={}
 for cat in ['all','answerable','partly_answerable','unanswerable']:
  data=[x for x in pp if cat=='all' or x['category']==cat];rep=[]
  for i in [1,2,3]:
   v=[x for x in data if x['repeat']==i];k=sum(x['pair_pass'] for x in v);rep.append({'repeat':i,'pass':k,'n':len(v),'exact_95_interval':interval(k,len(v))})
  ids=set(x['pair_id'] for x in data);robust=sum(all(x['pair_pass'] for x in data if x['pair_id']==pid) for pid in ids);cats[cat]={'per_repeat':rep,'robust_all_three_repeats_pass':robust,'pairs':len(ids)}
 summary[condition]={'categories':cats,'full_task_outputs':sum(x['full_task_pass_AI_inspection'] for x in rr),'n_outputs':len(rr),'wrong_language_outputs':sum(not x['language_pass_AI_inspection'] for x in rr),'format_fail_outputs':sum(not x['format_pass'] for x in rr),'canonical_refusals':sum(x['canonical_refusal_ignoring_citations']=='True' for x in rr)}
diffs=[]
for pid in sorted(set(x['pair_id'] for x in pairs)):
 vals={c:np.mean([x['pair_pass'] for x in pairs if x['pair_id']==pid and x['condition']==c]) for c in ['original_saved','combined_oracle_evidence']};diffs.append(vals['combined_oracle_evidence']-vals['original_saved'])
rng=np.random.default_rng(2026103102);boot=np.mean(np.asarray(diffs)[rng.integers(0,20,size=(10000,20))],axis=1)
result={'status':'complete provisional local AI-assisted scoring','summary':summary,'cluster_average_pair_success_difference':float(np.mean(diffs)),'paired_cluster_bootstrap_95_interval':np.quantile(boot,[.025,.975]).tolist(),'cluster_unit':'20 bilingual question pairs, retaining both languages, conditions and all repeats','no_new_human_review':True,'original_Howard_scores_unchanged':True,'oracle_evidence_not_retrieval_improvement':True};(A/'analysis_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
