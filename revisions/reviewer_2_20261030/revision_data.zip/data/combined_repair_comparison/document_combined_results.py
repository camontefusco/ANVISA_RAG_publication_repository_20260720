from pathlib import Path
import json,csv,shutil,ast,re,difflib,datetime,hashlib,collections
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/combined_repair_comparison_20261031';A=O/'analysis';old=R/'outputs/partial_mechanism_factorial_20261030/documents';D=O/'documents';prepared=O/'prepared_documents';prepared.mkdir(exist_ok=True)
for f in D.glob('*.docx'):shutil.copy2(f,prepared/f.name)
for f in D.glob('*'):f.unlink()
shutil.copytree(old,D,dirs_exist_ok=True)
s=json.loads((A/'analysis_summary.json').read_text());rows=list(csv.DictReader((A/'outputs_scored.csv').open()));raw=list(map(lambda p:json.loads(p.read_text()),(O/'raw_calls').glob('*.json')));inputs={x['call_id']:x for x in map(json.loads,(O/'generation_inputs_240.jsonl').read_text().splitlines())};outs=list(map(json.loads,(O/'results_checkpoint.jsonl').read_text().splitlines()));assert len(raw)==len(outs)==len(inputs)==240 and all(x['http_status']==200 for x in raw) and all(x['generation_metadata']['modelVersion']=='gemini-3.5-flash-lite' for x in outs)
for x in outs:assert x['prompt_sha256']==inputs[x['call_id']]['prompt_sha256']
(A/'completion_audit.json').write_text(json.dumps({'unique_generations':240,'successful_http_attempts':240,'failed_attempts':0,'judge_calls':0,'all_prompt_hashes_verified':True,'model_versions':{'gemini-3.5-flash-lite':240},'unique_answer_groups_inspected':173,'substantive_answer_groups_annotated':152,'canonical_refusal_groups':21,'all_canonical_surface_forms_exact':True,'original_Howard_result_unchanged':True},indent=2))
methods='Combined evidence and instruction comparison. We subsequently tested all 40 frozen development questions, comprising 20 bilingual pairs, under the original saved condition and a combined condition, with three fresh repeats per question and condition (240 generations; S35). The combined condition retained the saved passages, appended manually selected complete relevant archived articles for the 32 answerable or partly answerable questions, and revised partial-answer, refusal, relevance, language and literal-citation instructions. Unanswerable controls received no added passages. Model and temperature remained gemini-3.5-flash-lite and 0.2; the frozen randomized order used seed 2026103101. No external judge or repair calls were made. Full-task assessment used unchanged frozen reference components, missing-detail requirements, language and citation criteria, with local unblinded AI-assisted inspection and no new human rating. Each repeat was scored by bilingual pair. Paired 95% bootstrap intervals resampled the 20 pair IDs 10000 times while retaining both languages, conditions and all repeats. This manually supplemented evidence comparison is a development diagnostic, not an evaluation of an improved retrieval system.'
results='The combined comparison completed all 240 generations in 240 successful attempts. Full-task bilingual-pair success was 8/20, 9/20 and 9/20 under the original condition, versus 14/20, 15/20 and 14/20 under the combined condition across the three repeats. Mean pair success across repeats changed from 43.3% to 71.7%, a paired difference of 28.3 percentage points (descriptive 95% pair-cluster bootstrap interval 10.0 to 48.3). Seven of 20 original-condition pairs and 14/20 combined-condition pairs passed all three repeats. Combined-condition answerable pairs passed 10/12 in every repeat, and unanswerable pairs 4/4; partly answerable pairs passed 0/4, 1/4 and 0/4, with none passing all repeats. Wrong-language outputs decreased from 16/120 to 3/120, but literal-citation format failures increased from 5/120 to 7/120. The original 120 and combined 120 outputs contain repeated responses to the same 40 questions and are not independent samples. These provisional AI-assisted outcomes do not replace Howard\u2019s original 10/20 assessment.'
discussion='The combined comparison shows that supplying complete archived clauses and revising instructions can improve full-task performance on known development questions, but it leaves a clear partly answerable failure. The combined answers recovered the seven API-list categories, the low-risk literature requirement and the certificate-validity condition; they still omitted frozen secondary reference components such as the complementary-act deferral, general phase-3 risk framing and certificate-copy requirement. These components are retained for comparability and distinguished from the narrower question content. One Portuguese AV_014 response also omitted the unavailable indexing-database detail. All three combined AV_016 English responses remained Portuguese. Literal citation suffixes persisted, and two combined AV_011 English responses misapplied the product exceptions to requiring phase III studies rather than to comparative design. A Portuguese response also added an unverifiable claim about which chapter details were present. Thus the overall gain does not establish a reliable partial-answer repair. Because relevant complete articles were selected manually and multiple instructions changed together, the experiment cannot identify a repaired retrieval algorithm or separate effects of each change. The interval describes variation across the selected development pairs under provisional inspection; it does not establish independent generalization, human-validated improvement or current-law applicability. No repair was deployed.'
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=10000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
for name in ['manuscript_clean.docx','manuscript_tracked.docx']:
 pth=D/name;d=Document(pth)
 for anchor,text in [('Results',methods),('Summary of quantitative evaluation',results)]:
  target=next(p for p in d.paragraphs if acc(p._p)==anchor);p=target.insert_paragraph_before('')
  if 'tracked' in name:redline(p._p,'',text)
  else:p.text=text
 target=next(p for p in d.paragraphs if acc(p._p).startswith('A controlled development follow-up used 213'));p=OxmlElement('w:p');target._p.addnext(p)
 if 'tracked' in name:redline(p,'',discussion)
 else:
  from docx.text.paragraph import Paragraph
  Paragraph(p,target._parent).text=discussion
 d.save(pth)
d=Document(D/'response_to_reviewer_2.docx')
for p in d.paragraphs:
 if p.text.startswith('The post-calibration set shares'):p.text+=' The combined evidence and instruction comparison subsequently completed 240 generations (S35). Full-task pair success was 8/20, 9/20 and 9/20 with original inputs versus 14/20, 15/20 and 14/20 with manually supplemented evidence and revised instructions. The mean paired difference was 28.3 percentage points (pair-cluster 95% interval 10.0 to 48.3). However, none of four partly answerable pairs passed all three repeats. Wrong-language outputs fell from 16/120 to 3/120, while citation-format failures rose from 5/120 to 7/120. Required secondary reference components, unavailable-detail statements and interpretation errors remain documented. The assessment is provisional and AI assisted; this oracle-evidence development gain does not demonstrate an improved retrieval system, independent validation or a deployed repair.'
d.save(D/'response_to_reviewer_2.docx')
d=Document(prepared/'supplementary_combined_repair_protocol_S35.docx')
d.paragraphs[0].text='Combined evidence and instruction comparison';d.paragraphs[0].style='Title';d.paragraphs[1].text='Supplementary S35   Completed 31 October 2026   Provisional AI assisted assessment'
for p in d.paragraphs:
 if 'No new generations have been made at the preparation stage.' in p.text:p.text=p.text.replace('No new generations have been made at the preparation stage.','The pre-call protocol is preserved separately; all 240 generations are now complete.')
d.add_heading('Completed results',1);d.add_paragraph(results)
t=d.add_table(rows=1,cols=4);t.style='Table Grid'
for c,v in zip(t.rows[0].cells,['Outcome','Original','Combined','Denominator']):c.text=v
for vals in [('Full task repeat 1','8','14','20 pairs'),('Full task repeat 2','9','15','20 pairs'),('Full task repeat 3','9','14','20 pairs'),('Pass all three repeats','7','14','20 pairs'),('Wrong language','16','3','120 outputs per condition'),('Citation format failure','5','7','120 outputs per condition')]:
 for c,v in zip(t.add_row().cells,vals):c.text=v
d.add_paragraph('Exact 95% pair-count intervals are 19.1 to 63.9% for 8/20, 23.1 to 68.5% for 9/20, 45.7 to 88.1% for 14/20 and 50.9 to 91.3% for 15/20. The repeat-average difference uses paired clustering, not 60 independent question pairs. Output counts are descriptive repeated observations.')
d.add_heading('Persistent failures and interpretation',1);d.add_paragraph(discussion)
d.add_paragraph('For AV_013, all six combined outputs recovered the seven API-list categories and withheld numerical limits, but none supplied the complementary-act deferral. For AV_014, all six recovered the literature requirement, five named absent indexing databases and all six withheld a publication count, but none supplied the frozen general risk framing. For AV_015, all six covered the substantive partial answer; two English outputs added a prohibited citation suffix, so only repeat 2 passed as a bilingual pair. For AV_016, all six recovered Article 12 and withheld the specific list, but none included the frozen certificate-copy component and all three English questions received Portuguese answers. These component counts are explanatory and do not revise the frozen scoring rule.')
d.add_heading('Assessment audit',1);d.add_paragraph('All 173 distinct question-answer groups were inspected: 152 substantive groups received local AI-assisted semantic annotations; 21 canonical-refusal groups were checked for frozen category, exact surface form, language and citation compliance. Related statements were checked against selected and appended archived provisions. The full-task score combines the semantic inspection with separate language and literal-format checks. AI interpretation, including assessment of the scope of exceptions in AV_011, remains open to human confirmation. No new Howard ratings or external model-judge scores were produced. The original 10/20 human-reviewed outcome remains unchanged.')
d.add_paragraph('The data directory retains the pre-call protocol, randomized payload, evidence additions, 240 response and attempt records, unchanged frozen reference components, annotations, per-output and per-pair scores, exact count intervals, cluster bootstrap summary and negative findings. No failed attempts occurred. There was no adaptive prompt modification or additional generation. Human authorization and private coordination remain local.')
d.save(D/'supplementary_combined_repair_S35.docx')
changed=['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_combined_repair_S35.docx']
for name in changed:
 p=D/name;d=Document(p)
 for el in list(d._element.iter(qn('w:pBdr')))+list(d.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 d.save(p)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True);assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(A/'document_projection_QA.json').write_text(json.dumps({'accept_matches_clean':True,'reject_matches_submission_baseline':True,'changed_documents':changed},indent=2));(A/'RESULTS_AND_LIMITATIONS.md').write_text('# Combined repair comparison\n\n'+results+'\n\n'+discussion+'\n');shutil.copy2('/private/tmp/document_combined_results.py',O/'document_combined_results.py')
for name in ['screen_combined_repair.py','summarize_combined_repair.py','annotate_combined_reviewed.py','review_combined_diffs.py']:shutil.copy2('/private/tmp/'+name,O/name)
print('Completed S35 and manuscript/response updates; tracked projections verified.')
