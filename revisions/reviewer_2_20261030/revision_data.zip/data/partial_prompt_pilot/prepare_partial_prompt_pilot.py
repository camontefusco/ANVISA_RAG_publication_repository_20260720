from pathlib import Path
import json,csv,hashlib,random,datetime,difflib
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';F=R/'outputs/author_led_validation_frozen_20261030';O=R/'outputs/partial_answer_prompt_pilot_20261030';O.mkdir(exist_ok=True)
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
raw=[json.loads(x) for x in (F/'generation_payload_40/generation_inputs_40.jsonl').read_text().splitlines()];refs={r['id']:r for r in csv.DictReader((F/'approved_questions_and_references_40_FROZEN.csv').open())}
pairs=['AV_001','AV_004','AV_008','AV_010','AV_013','AV_014','AV_015','AV_016','AV_017','AV_018'];items=[]
new='''5. Answer the requested information that is explicitly supported by the retrieved
   context, and do not supply any requested information that is unavailable.
   When only part of the requested information is supported, give that supported
   part with its exact article citations. Then explicitly identify each requested
   detail that the context does not provide. Do not substitute a nearby general
   rule or an unrelated fact for that missing detail. Do not invent current forms,
   URLs, fees, values, private terms, company status, contacts, prices, tax or patent
   information, future approvals, or advice absent from the context.
   If none of the requested information is supported, respond only with the
   appropriate sentence below and do not add a citation:
   Portuguese: Os documentos recuperados nao fornecem informacao suficiente para responder.
   English: The retrieved documents do not provide enough information to answer.
6. Before answering, silently classify the retrieved evidence as one of:
   sufficient: it directly answers every material part of the question;
   partial_related: it supports some requested information but omits another requested detail;
   insufficient: it supports none of the requested information.
   For sufficient evidence, answer the question using only that evidence.
   For partial_related evidence, provide the supported requested information with
   citations and explicitly identify the unavailable requested detail, as in rule 5.
   For insufficient evidence, return only the refusal sentence from rule 5.
'''
for x in raw:
 if x['pair_id'] not in pairs:continue
 p=x['prompt'];a=p.index('5. If the context');b=p.index('7. For yes/no');changed=p[:a]+new+p[b:]
 assert changed.split('Retrieved context:\n',1)[1]==p.split('Retrieved context:\n',1)[1]
 for condition,prompt in [('original',p),('partial_answer',changed)]:
  item={k:x[k] for k in ['id','pair_id','language','question','selected_evidence','context_sha256']};item.update(call_id=x['id']+'__'+condition,condition=condition,prompt=prompt,prompt_sha256=sha(prompt));items.append(item)
assert len(items)==40
rng=random.Random(20261030);rng.shuffle(items)
for i,x in enumerate(items):x['sequence']=i+1
(O/'generation_inputs_40.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in items))
with (O/'generation_plan_40.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['sequence','call_id','id','pair_id','condition','prompt_sha256']);w.writeheader();w.writerows({k:x[k] for k in w.fieldnames} for x in items)
proto={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design':'Exploratory development comparison after inspecting earlier failures. Twenty questions in ten bilingual pairs, two newly generated prompt conditions, one answer per condition. No independent test claim.','selection':{'partly_answerable_pairs':pairs[4:8],'answerable_controls':pairs[:4],'unanswerable_controls':pairs[8:]},'model':'gemini-3.5-flash-lite','temperature':0.2,'generation_calls':40,'judge_calls':0,'max_attempts_per_call':3,'throttle_seconds':4.3,'random_seed':20261030,'change':'Only rules 5 and 6 replaced. Same question, exact context, citation rules, language rule, false-premise rule and final validation. The new policy separates supported requested information from unavailable detail.','endpoints':['Blanket refusal vs substantive partial answer','Completeness of requested supported information','Explicit identification of unavailable requested detail','Claim and citation support against exact passages','Response language compliance','Full frozen-task completion as a separate descriptive endpoint'],'assessment':'Local AI-assisted passage-by-passage inspection, no automated Google judge calls and no new human ratings. Preserve all outputs, negative findings and uncertainty. Historical Howard ratings are not transferred to new outputs.','limits':['One repeat cannot estimate stochastic variability reliably','Selected development-exposed questions; no generalization estimate','Changing two linked rules changes wording and prompt length','Archived source scope; no current-law verification','No retrieval change, so missing context cannot be supplied by this intervention'],'inputs_sha256':sha((O/'generation_inputs_40.jsonl').read_text())}
(O/'PROTOCOL_BEFORE_CALLS.json').write_text(json.dumps(proto,indent=2));(O/'human_authorization.json').write_text(json.dumps({'date':'2026-10-30','user_request':'try the rushed experiment just to see what we get','subsequent_instruction':'if it doesnt work we can document we tried, how we tried and that it is a negative results, which is also a result to be seen','scope':'40 bounded Google Gemini generations on selected archived questions and contexts with original/revised prompt, no judge/reference answers/Howard ratings transmitted; no billing/model change','protocol_sha256':sha((O/'PROTOCOL_BEFORE_CALLS.json').read_text())},indent=2))
(O/'prompt_rules_5_and_6_revised.txt').write_text(new);(O/'prompt_change.diff').write_text(''.join(difflib.unified_diff(p.splitlines(True),changed.splitlines(True),fromfile='original',tofile='partial_answer')))
print(json.dumps({'planned_calls':40,'pairs':pairs,'inputs_sha256':proto['inputs_sha256']},indent=2))
