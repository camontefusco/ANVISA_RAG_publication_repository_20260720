from pathlib import Path
import csv,json,collections,re,os,textwrap
os.environ['MPLCONFIGDIR']='/private/tmp/anvisa_submission_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
B=Path(__file__).resolve().parents[2];R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/Howard40_review_and_submission_package_20261030';F=O/'figures';F.mkdir(exist_ok=True)
for p in Path('/System/Library/Fonts/Supplemental').glob('Arial*.ttf'):font_manager.fontManager.addfont(str(p))
plt.rcParams.update({'font.family':'Arial','font.size':10,'text.color':'black','axes.labelcolor':'black','axes.edgecolor':'black','xtick.color':'black','ytick.color':'black','svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,n):
 for text in fig.findobj(matplotlib.text.Text):
  text.set_fontfamily('Arial');text.set_color('black');text.set_text(text.get_text().replace('\u2013',' to ').replace('\u2014',', '))
 for ext in ['png','pdf','svg','tif']:fig.savefig(F/(n+'.'+ext),dpi=400,bbox_inches='tight',**({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tif' else {}))
 plt.close(fig)
def box(ax,y,title,body):
 ax.add_patch(FancyBboxPatch((.04,y),.92,.08,boxstyle='round,pad=0.012',facecolor='white',edgecolor='black',lw=1));ax.text(.065,y+.052,title,fontweight='bold',va='center',fontsize=10);ax.text(.065,y+.021,body,va='center',fontsize=9)
fig,ax=plt.subplots(figsize=(9,10));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
workflow=[('Archived corpus','Six selected regulatory documents; includes revoked RDC 9/2015'),('Text and article structure','382 articles; 481 chunks with source and citation metadata'),('Query preparation','Portuguese questions retained; English glossary rewriting and query expansions'),('Hybrid retrieval','Dense and BM25 candidates, fusion, anchors and lexical fallback'),('Reranking and context selection','Cross-encoder ranking; conditional sibling expansion and citation diversification'),('Evidence classification','Sufficient, partial related, or insufficient under the frozen prompt'),('Answer or refusal','Supported answer with article citations, or a language-specific refusal'),('Evaluation','Reused development sets, diagnostic assessments, then a frozen author-led test')]
for i,(title,body) in enumerate(workflow):
 y=.88-i*.115;box(ax,y,title,body)
 if i<7:ax.annotate('',xy=(.5,y-.025),xytext=(.5,y-.002),arrowprops={'arrowstyle':'->','color':'black'})
ax.set_title('Closed corpus retrieval and answer workflow',fontsize=15,pad=14);save(fig,'Figure_1_closed_corpus_rag_workflow')
fig,axs=plt.subplots(2,1,figsize=(8.6,7.7),gridspec_kw={'height_ratios':[1,1.4]});fig.subplots_adjust(left=.32,hspace=.6,bottom=.15)
axs[0].barh(range(4),[70,70,20,40],color='0.55');axs[0].set_yticks(range(4),['PT direct article','EN direct article','Multi-article or exception','Unanswerable or adversarial']);axs[0].invert_yaxis();axs[0].set(xlim=(0,85),xlabel='Question rows',title='Constructed benchmark: 200 rows in 100 bilingual pairs')
for i,n in enumerate([70,70,20,40]):axs[0].text(n+1,i,str(n),va='center')
labels=['RDC 9/2015 (revoked)','RDC 55/2010','RDC 751/2022','RDC 406/2020','RDC 945/2024','IN 338/2024'];nums=[28,28,28,28,26,22];axs[1].barh(range(6),nums,color='0.55');axs[1].set_yticks(range(6),labels);axs[1].invert_yaxis();axs[1].set(xlim=(0,34),xlabel='Distinct question rows citing the source',title='Archived reference source coverage')
for i,n in enumerate(nums):axs[1].text(n+.5,i,str(n),va='center')
fig.text(.5,.025,'A regulation is counted once per question. Coverage does not establish current-law validity.',ha='center',fontsize=9);save(fig,'Figure_2_benchmark_design_and_source_coverage')
raw=list(csv.DictReader((R/'outputs/revision_20261021_step02/supplementary_S1_relabelled.csv').open()));stageids=list(dict.fromkeys(r['stage_id'] for r in raw));labs=['Internal development','English repair','Portuguese repair','Diagnostic stress','Refusal calibration','Post-calibration diagnostic'];assert len(stageids)==6
metrics=[('judge_faithfulness','Faithfulness'),('judge_citation_correctness','Citation support'),('judge_completeness','Completeness'),('judge_refusal_correctness','Refusal score')];plotrows=[];fig,axs=plt.subplots(1,4,figsize=(12,4.4),sharey=True)
for ax,(key,title) in zip(axs,metrics):
 for i,s in enumerate(stageids):
  rr=[r for r in raw if r['stage_id']==s and (r['answerable']=='False' if key=='judge_refusal_correctness' else r['answerable']=='True')];vs=[float(r[key]) for r in rr if r[key]!=''];m=sum(vs)/len(vs);ax.plot(m,i,'o',color='black');plotrows.append({'figure':'3A','stage':labs[i],'metric':title,'n':len(vs),'mean':m});ax.text(m+.025,i,f'{m+1e-10:.3f}',va='center',fontsize=8)
 ax.set(xlim=(0,1.19),xticks=[0,.5,1],xlabel='Mean automated score',title=title);ax.grid(axis='x',alpha=.2)
axs[0].set_yticks(range(6),labs);axs[0].invert_yaxis();fig.suptitle('Historical scores on overlapping development assessments',fontsize=14);fig.tight_layout(rect=(0,.06,1,.93));fig.text(.5,.015,'Unconnected points. Original labels and scores retained; sample sizes and stage overlap are reported in the legend.',ha='center',fontsize=9);save(fig,'Figure_3A_development_stage_answer_quality')
fig,axs=plt.subplots(1,3,figsize=(10.8,4.3),sharey=True)
def avg(stage,key,answerable,lang=None):
 rr=[r for r in raw if r['stage_id']==stage and r['answerable']==str(answerable) and (not lang or r['language']==lang)];return sum(float(r[key]) for r in rr)/len(rr),len(rr)
# Use exact stage provenance, not numerical assumptions about file names.
comparisons=[('English completeness',avg(stageids[0],'judge_completeness',True,'en'),avg(stageids[1],'judge_completeness',True,'en'),['Baseline','Repair']),('Refusal score',avg(stageids[3],'judge_refusal_correctness',False),avg(stageids[5],'judge_refusal_correctness',False),['Stress','Post-calibration']),('Answer completeness',avg(stageids[3],'judge_completeness',True),avg(stageids[5],'judge_completeness',True),['Stress','Post-calibration'])]
for ax,(title,a,b,lbls) in zip(axs,comparisons):
 ax.bar([0,1],[a[0],b[0]],color='0.55',width=.55);ax.set(ylim=(0,1.14),yticks=[0,.25,.5,.75,1],xticks=[0,1],xticklabels=lbls,title=title)
 for i,(v,n) in enumerate([a,b]):ax.text(i,v+.025,f'{v+1e-10:.3f}\nn = {n}',ha='center',fontsize=9)
axs[0].set_ylabel('Mean automated score');fig.tight_layout(rect=(0,.1,1,.96));fig.text(.5,.015,'Left: reused English development questions. Other panels: different diagnostic sets, with calibration overlap.',ha='center',fontsize=9);save(fig,'Figure_3B_targeted_weak_point_repairs')
summary=json.loads((O/'data/Howard40_analysis_record.json').read_text())['summary'];fig,ax=plt.subplots(figsize=(8.3,4.3));catnames=['Answerable','Partly answerable','Unanswerable','Overall']
for i,r in enumerate(summary):
 p=r['proportion'];ax.errorbar(p,i,xerr=[[p-r['CI95_lower']],[r['CI95_upper']-p]],fmt='o',color='black',capsize=4);ax.text(1.06,i,f"{r['successful_pairs']}/{r['pairs']}",va='center',fontsize=11)
ax.set(yticks=range(4),yticklabels=catnames,xlim=(-.03,1.2),xticks=[0,.25,.5,.75,1],xlabel='Both languages meet the full task criteria',title='Frozen 40-answer author review');ax.invert_yaxis();ax.grid(axis='x',alpha=.2);fig.tight_layout();save(fig,'Figure_4_frozen_author_review_pair_success')
P=B/'repository/evaluation/publication_results/manuscript_package_20260719/tirs_final_submission_package_20260720/figures_from_development_20260720';old=list(csv.DictReader((P/'figure_metrics_source_table.csv').open()))
for figid in ['S1','S2','S3']:
 rr=[r for r in old if r['figure']=='Figure '+figid];fig,ax=plt.subplots(figsize=(8,4.8));vals=[float(r['value']) for r in rr]
 if figid=='S1':
  ax.bar(range(len(rr)),vals,color='0.55');ax.set(xticks=range(len(rr)),xticklabels=['Source hit','Source MRR','Article recall@5','Article MRR@5'],ylim=(0,1.13),ylabel='Mean retrieval metric',title='Archived diagnostic stress assessment: 40 answerable outputs')
  for i,v in enumerate(vals):ax.text(i,v+.025,f'{v+1e-10:.3f}',ha='center')
 elif figid=='S2':
  ax.bar(range(4),vals,color='0.55');ax.set(xticks=range(4),xticklabels=['Multi-article','EN direct','PT direct','Unanswerable'],ylabel='Question rows',title='Constructed benchmark composition: 200 rows')
  for i,v in enumerate(vals):ax.text(i,v+1,str(int(v)),ha='center')
 else:
  labels=[re.search(r'(IN|RDC)[_ ]?(\d+)[_ ]?(\d{4})',r['stage_label'],re.I) for r in rr];labs=[(m[1].upper()+' '+str(int(m[2]))+'/'+m[3]) if m else 'RDC 9/2015' for m in labels];ax.barh(range(6),vals,color='0.55');ax.set(yticks=range(6),yticklabels=labs,xlabel='Chunks',title='Archived index: 481 chunks across six documents');ax.invert_yaxis()
  for i,v in enumerate(vals):ax.text(v+1,i,str(int(v)),va='center')
 fig.tight_layout();stem={'S1':'Figure_S1_diagnostic_retrieval_validity','S2':'Figure_S2_benchmark_composition','S3':'Figure_S3_article_chunk_distribution'}[figid];save(fig,stem)
# An explicitly labelled schematic avoids altering or upscaling a cropped historical screenshot.
fig,ax=plt.subplots(figsize=(9,6.7));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');ax.text(.04,.94,'Regulatory evidence interface',fontsize=15,fontweight='bold');ax.text(.04,.88,'Schematic of the interface structure, not a runtime screenshot',fontsize=10)
for y,title,body in [(.72,'Question','A regulatory question in Portuguese or English'),(.55,'Generated answer','Answer text and inline source/article citations, or a refusal'),(.38,'Retrieved evidence','Selected regulatory passages with citation labels'),(.21,'User verification','Inspect the named source, article and applicable regulatory date')]:box(ax,y,title,body)
ax.text(.04,.08,'The archived smoke test showed a language mismatch. It is not evidence of bilingual deployment performance.',fontsize=9,wrap=True);save(fig,'Figure_S4_interface_layout_schematic')
with (O/'data/figure_3A_source_values.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(plotrows[0]));w.writeheader();w.writerows(plotrows)
print('Generated nine figures in PNG, PDF, SVG and TIFF; all text uses Arial and black.')
