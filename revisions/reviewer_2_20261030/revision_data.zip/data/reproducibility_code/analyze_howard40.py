from pathlib import Path
import csv,json,hashlib,shutil,collections,re,ast,unicodedata
from scipy.stats import beta
B=Path(__file__).resolve().parents[2];R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/Howard40_review_and_submission_package_20261030';D=O/'data';D.mkdir(parents=True,exist_ok=True);I=O/'intake_original';I.mkdir(exist_ok=True)
src=Path('/Users/cmontefusco/Downloads/Howard_answer_ratings_40.csv');shutil.copy2(src,I/src.name);rs=list(csv.DictReader(src.open(encoding='utf-8-sig')))
F=R/'outputs/author_led_validation_frozen_20261030';G=R/'outputs/author_led_generation_complete_20261030';inputs={r['id']:r for r in map(json.loads,(F/'generation_payload_40/generation_inputs_40.jsonl').read_text().splitlines())};answers={r['id']:r for r in csv.DictReader((G/'answers_40_UNRATED.csv').open())};refs={r['id']:r for r in csv.DictReader((F/'approved_questions_and_references_40_FROZEN.csv').open())}
assert len(rs)==len({r['id'] for r in rs})==40;assert {r['id'] for r in rs}==set(inputs)==set(answers)==set(refs)
for p,h in json.loads((F/'EXECUTION_INPUT_MANIFEST.json').read_text()).items():assert hashlib.sha256((F/p).read_bytes()).hexdigest()==h
for r in rs:
 assert r['pair_id']==refs[r['id']]['pair_id'] and r['language']==refs[r['id']]['language'] and r['planned_category']==refs[r['id']]['planned_category']
 assert answers[r['id']]['prompt_sha256']==inputs[r['id']]['prompt_sha256']==hashlib.sha256(inputs[r['id']]['prompt'].encode()).hexdigest()
 assert r['automated_scores_seen_before_rating']=='No'
# Verify the rule in the actual frozen prompt, not just current source code.
assert all('For partial_related or insufficient,' in x['prompt'] and 'return only the refusal sentence' in x['prompt'] for x in inputs.values())
source=ast.parse((B/'repository/evaluation/publication_eval.py').read_text());node=next(x for x in source.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTEXT_EXPANSION_RE' for t in x.targets));scope={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'trigger','exec'),scope)
normalize=lambda t:re.sub(r'\s+',' ',unicodedata.normalize('NFKD',t).encode('ascii','ignore').decode().lower()).strip()
refusals={'os documentos recuperados nao fornecem informacao suficiente para responder.','the retrieved documents do not provide enough information to answer.'}
rows=[]
for r in rs:
 id=r['id'];cat=r['planned_category'];a=answers[id]['answer'];pure=normalize(a) in refusals;part=cat=='partly_answerable'
 if cat=='answerable':success=all(r[k]=='Yes' for k in ['corpus_required_elements_complete','material_claims_supported','citations_support_claims','language_compliant'])
 elif part:success=all(r[k]=='Yes' for k in ['corpus_required_elements_complete','selected_supported_information_complete','material_claims_supported','citations_support_claims','refusal_of_unavailable_detail_appropriate','language_compliant']) and not pure
 else:success=r['refusal_of_unavailable_detail_appropriate']=='Yes' and r['language_compliant']=='Yes' and r['material_claims_supported'] in ['Yes','NA'] and r['citations_support_claims'] in ['Yes','NA']
 quotes=[normalize(x) for x in re.split(r'\\n|\n',refs[id]['verbatim_source_support']) if x.strip()];ctx='\n'.join(x['text'] for x in inputs[id]['selected_evidence']);matched=[q for q in quotes if q in normalize(ctx)]
 rows.append({**r,'reported_review_date':r['actual_review_date'],'actual_review_date':'2026-10-30','date_correction_basis':'Corresponding author confirmed 30 October in chat; original CSV preserved','answer':a,'full_task_success':bool(success),'pure_refusal':pure,'unavailable_detail_explicitly_identified':False if part and pure else 'NA','evidence_sufficiency_for_supported_content':r['selected_evidence_sufficiency'] if cat!='unanswerable' else 'NA','required_completeness_for_supported_content':r['corpus_required_elements_complete'] if cat!='unanswerable' else 'NA','expansion_trigger_active':bool(scope['CONTEXT_EXPANSION_RE'].search(inputs[id]['question'])),'selected_citations':' | '.join(x['citation'] for x in inputs[id]['selected_evidence']),'source_quote_match_count':len(matched),'source_quote_count':len(quotes),'quote_matching_limit':'Normalized substring audit only; not a substitute for semantic review','prompt_sha256':inputs[id]['prompt_sha256']})
with (D/'Howard40_ratings_and_derived_results.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
pairs=[]
for p in sorted({r['pair_id'] for r in rows}):
 rr=[r for r in rows if r['pair_id']==p];assert len(rr)==2;pairs.append({'pair_id':p,'category':rr[0]['planned_category'],'EN_pass':next(r['full_task_success'] for r in rr if r['language']=='en'),'PT_pass':next(r['full_task_success'] for r in rr if r['language']=='pt'),'both_languages_success':all(r['full_task_success'] for r in rr)})
with (D/'Howard40_pair_results_20.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
summ=[]
for cat in ['answerable','partly_answerable','unanswerable','overall']:
 pr=[p for p in pairs if cat=='overall' or p['category']==cat];rr=[r for r in rows if cat=='overall' or r['planned_category']==cat];k=sum(p['both_languages_success'] for p in pr);n=len(pr);lo=float(beta.ppf(.025,k,n-k+1)) if k else 0.;hi=float(beta.ppf(.975,k+1,n-k)) if k<n else 1.;summ.append({'category':cat,'successful_pairs':k,'pairs':n,'proportion':k/n,'CI95_lower':lo,'CI95_upper':hi,'successful_outputs':sum(r['full_task_success'] for r in rr),'outputs':len(rr)})
with (D/'Howard40_success_summary.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summ[0]));w.writeheader();w.writerows(summ)
checks=[]
for r in rows:
 id=r['id'];cat=r['planned_category']
 if cat=='partly_answerable':tag='blanket_refusal_omits_supported_information' if r['selected_supported_information_complete']=='No' else 'blanket_refusal_with_no_required_supported_content_retrieved'
 elif id=='AV_008_EN':tag='supported_but_wrong_task_content'
 elif r['full_task_success']:tag='full_task_success'
 elif r['corpus_required_elements_complete']=='Yes':tag='language_only_failure'
 else:tag='incomplete_required_content'
 checks.append({'id':id,'pair_id':r['pair_id'],'category':cat,'primary_failure_class':tag,'language_failure':r['language_compliant']=='No','evidence_sufficiency':r['evidence_sufficiency_for_supported_content'],'prompt_expansion_trigger':r['expansion_trigger_active'],'human_explanation':r['rationale_and_evidence'],'full_task_success':r['full_task_success']})
with (D/'Howard40_failure_audit.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
record={'review_date_confirmed':'2026-10-30','original_csv_date':'2026-10-29','original_csv_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'rows':40,'pairs':20,'raw_ratings_preserved':True,'frozen_inputs_hashes_pass':True,'model_answers_unchanged':True,'no_new_automated_evaluations':True,'automated_scores_seen_reported':False,'review_scope':'Reference-informed author-led review by Howard of the exact answers and selected passages. No independent validation claim. Prior benchmark exposure retained.','summary':summ,'language_compliant_outputs':35,'language_compliant_English':15,'language_compliant_Portuguese':20,'answerable_required_complete':18,'answerable_outputs':24,'pure_refusals':sum(r['pure_refusal'] for r in rows),'P_supported_content_omission_rows':[r['id'] for r in rows if r['planned_category']=='partly_answerable' and r['selected_supported_information_complete']=='No'],'P_no_supported_required_content_retrieved_rows':[r['id'] for r in rows if r['planned_category']=='partly_answerable' and r['selected_supported_information_complete']=='NA'],'material_claims_supported':23,'claim_bearing_outputs':23,'citation_support_yes':23,'citation_bearing_outputs':23,'N_vacuous_completeness_and_sufficiency':'Raw Yes/Sufficient retained; derived supported-content completeness and sufficiency are NA for all eight N rows; N success uses refusal, claim support and language.','prompt_scoring_mismatch':'All actual prompts require a blanket refusal for partial evidence, while the fixed P endpoint requires supported information and explicit identification of unavailable detail. This design mismatch is documented, not changed after results.','counts_are_not_causal_effects':True,'independent_pairs_assumption':'Exact binomial pair intervals are conditional descriptive uncertainty for this selected author-exposed sample; they do not account for review bias or shared regulations.','new_API_calls':0}
(D/'Howard40_analysis_record.json').write_text(json.dumps(record,indent=2));(D/'review_date_correction.json').write_text(json.dumps({'submitted_date':'2026-10-29','confirmed_actual_date':'2026-10-30','basis':'Direct user clarification in this chat','raw_file_preserved':True},indent=2));print(json.dumps(record,indent=2))
