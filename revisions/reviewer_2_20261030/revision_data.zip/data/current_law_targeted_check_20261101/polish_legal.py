from pathlib import Path
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
P=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication/repository/revisions/reviewer_2_20261021/outputs/targeted_legal_status_incorporated_20261101/documents')
d=Document(P/'supplementary_integrated_validation_S40.docx')
for p in d.paragraphs:
 if p.text.startswith('The baseline retained the original 481-node index'):
  p.text='The baseline retained the original 481-node index, normalized CLS-pooled MiniLM embeddings (512-token limit), dense/BM25 top-100 fusion (RRF constant 60), cross-encoder, top-five selection, conditional article expansion, glossary and original prompt. The separate 482-node repair completes selected/adjacent articles by physical source occurrence. Structural conservation checks passed; reproduced historical embeddings had minimum cosine similarity 0.999999843. These checks do not establish current legal validity.'
 if p.text.startswith('The data archive preserves frozen questions'):
  p.text='The archive preserves frozen inputs, screening, prompt hashes, translations, all raw and processed answers, component decisions, pair tables, intervals, sensitivity analyses and code. Full corpora, vector assets, credentials and private review files remain local. Original scores and Howard files are preserved.'
d.save(P/'supplementary_integrated_validation_S40.docx')
d=Document(P/'supplementary_targeted_legal_status_S41.docx')
for p in d.paragraphs:
 if p.text.startswith('This targeted status check does not rebuild'):
  p.text='Current-law corpus rebuilding and model reevaluation, independent external validation and additional baselines remain incomplete or absent. Author confirmation covers 44/80 outputs; 36 received AI review only. Frozen references, answers and scores remain unchanged.'
 if p.text.startswith('All eight outputs for FV_014'):
  p.text='All eight outputs for FV_014 and FV_016 had the supported core requirement in their selected passages but returned blanket refusals. They omitted supported content and did not identify the unavailable headcount or form code. The repaired condition therefore retains two failed bilingual pairs. Context hashes and outputs are in the targeted-audit data. No generation or judge calls were repeated.'
 if p.text.startswith(('RDC406 consolidated:','RDC55 consolidated:','RDC948 consolidated:')):
  label,url=p.text.split(': ',1);p.clear();h=OxmlElement('w:hyperlink');h.set(qn('r:id'),d.part.relate_to(url,RT.HYPERLINK,is_external=True));r=OxmlElement('w:r');t=OxmlElement('w:t');t.text=label.replace('RDC','RDC ');r.append(t);h.append(r);p._p.append(h)
 if p.text.startswith('RDC 305/2002 status and consolidated'):
  p.text='RDC 305/2002 and RDC 68/2003 links are in the targeted-audit data. All sources accessed 1 November 2026. Consolidated displays do not replace the official gazette.'
for root in [d.styles.element,d._element]:
 for el in list(root.iter(qn('w:pBdr'))):el.getparent().remove(el)
d.save(P/'supplementary_targeted_legal_status_S41.docx')
for name in ['supplementary_integrated_validation_S40.docx','supplementary_targeted_legal_status_S41.docx']:
 d=Document(P/name)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 d.save(P/name)
