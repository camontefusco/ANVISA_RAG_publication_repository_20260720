from pathlib import Path
import ast,datetime,re,difflib,json,shutil
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches,Pt,RGBColor
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';OLD=R/'outputs/integrated_scope_resolved_20261101';N=R/'outputs/targeted_legal_status_incorporated_20261101';D=N/'documents';shutil.copytree(OLD/'documents',D,dirs_exist_ok=True)
code=(R/'work/revise_abstract_dr3_dr4.py').read_text();node=next(x for x in ast.parse(code).body if isinstance(x,ast.FunctionDef) and x.name=='redline');cid=18000000;exec(ast.get_source_segment(code,node).replace("'2026-10-22T10:00:00Z'","datetime.datetime.now(datetime.timezone.utc).isoformat()"))
def acc(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:del)]/text()'))
def rej(p):return ''.join(p.xpath('.//w:t[not(ancestor::w:ins) and not(ancestor::w:del)]/text() | .//w:delText/text()'))
legal='A targeted consolidated-text check on 1 November 2026 retained the staffing criterion in RDC 406/2020 Article 18, but confirmed that RDC 55/2010 Articles 22 and 30 were revoked by RDC 948/2024 [4,5,19]. The ruminant-documentation target and FV_012 Article 30 components therefore remain archived-text references, not evidence of current obligations. Separate EET documentation provisions require product-specific applicability assessment; no current-law model reevaluation was performed (S41).'
for name in ['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_integrated_validation_S40.docx','supplementary_information_revised.docx']:
 d=Document(D/name);tracked=name=='manuscript_tracked.docx'
 for p in d.paragraphs:
  old=acc(p._p);new=old
  if name.startswith('manuscript'):
   if old.startswith('The integrated repair showed a favorable descriptive result'):
    new=old.replace('These retained failures limit the repair rather than requiring successful correction of every case before reporting.',legal)
   for n in ['4. Agência','5. Agência','19. Agência']:
    if old.startswith(n):new=old+' Consolidated provisions checked 1 November 2026.'
  elif name=='response_to_reviewer_2.docx':
   if old.startswith('We retain the negative results'):new=old.replace('These retained failures limit the repair rather than requiring successful correction of every case before reporting.','Supplementary S41 confirms that both failure pairs had their supported requirements in all eight selected contexts. A targeted current-text check retains RDC 406/2020 Article 18, but identifies RDC 55/2010 Articles 22 and 30 as revoked by RDC 948/2024. The archived failures and FV_012 sensitivity remain unchanged. Separate EET documentation rules do not establish product-specific current applicability without further review. This targeted check does not complete current-law verification or reevaluation.')
  elif name=='supplementary_integrated_validation_S40.docx':
   if old.startswith('A post hoc reference-scope audit'):new+=' The corresponding author confirmed this archived scope on 1 November 2026. Article 30 is revoked for current-law purposes; see S41.'
   if old.startswith('The experimental pipeline was frozen'):new=old.replace('human confirmation is pending.','human confirmation covers 44/80 outputs; 36 have AI review only.')
   if old.startswith('The bundled pipeline showed'):new+=' S41 separates the retained current staffing criterion from revoked Article 22 and Article 30 references.'
  else:
   if old=='Revised 30 October 2026':new='Revised 1 November 2026'
   if old.startswith('S39 documents the retrospective reference-scope correction.'):
    new='S39 documents the retrospective scope correction. S40 reports the 80-answer repair comparison and FV_012 sensitivity (13/20 versus 17/20), preserving frozen scores. The author confirmed 44 outputs; 36 received AI review only. S41 checks retained staffing and revoked ruminant-documentation/GMP provisions. Current-law reevaluation, independent validation and additional baselines remain incomplete.'
  if new!=old:
   if tracked:redline(p._p,rej(p._p),new)
   else:p.text=new
 d.save(D/name)
# New concise source-status supplement; no frozen task or score is overwritten.
d=Document();sec=d.sections[0];sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.75)
for n in ['Normal','Title','Heading 1','Heading 2']:
 st=d.styles[n];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
d.styles['Normal'].font.size=Pt(10);d.styles['Normal'].paragraph_format.space_after=Pt(6);d.styles['Title'].font.size=Pt(17);d.styles['Heading 1'].font.size=Pt(12)
d.add_paragraph('Targeted provision status and retained refusal failures','Title');d.add_paragraph('Supplementary S41   1 November 2026')
d.add_paragraph('The two repaired refusal failures remain failures against the explicitly archived questions. A targeted current-source check supports the staffing criterion but identifies the cited ruminant-documentation article as revoked. This check does not establish current-law answer accuracy or complete a corpus-wide legal review.')
d.add_heading('Exact evidence and archived outcomes',1)
d.add_paragraph('All eight outputs for FV_014 and FV_016 (two languages in each of two conditions) had the supported core requirement in their selected passages and returned only a blanket refusal. They omitted the supported staffing criterion or EET documentation requirement and did not identify the particular unavailable headcount or form code. No generation or judge calls were repeated. The repaired condition therefore retains two failed bilingual pairs. Exact context hashes, review IDs and answers are preserved in the accompanying targeted-audit data.')
d.add_heading('Provision status checked',1)
d.add_paragraph('FV_014: Consolidated RDC 406/2020 Article 18 retains the requirement for qualified staffing compatible with pharmacovigilance activities. It specifies no numerical minimum. This is not an exhaustive finding that no other applicable instrument could impose additional requirements.')
d.add_paragraph('FV_016: Consolidated RDC 55/2010 explicitly marks Article 22 revoked by RDC 948/2024. Article 59 II of RDC 948 lists this repeal; Article 60 sets commencement at 1 January 2025. The frozen Article 22 reference remains a historical reading target and cannot itself establish a current documentation obligation.')
d.add_paragraph('FV_012: The broad archived question requires Articles 17, 30 VIII-IX and 31 I-III. The corresponding author explicitly confirmed that scope on 1 November 2026. Article 30 is revoked by RDC 948/2024, while Article 17 and Article 31 I-III remain displayed in the consolidated text checked. The expanded-scope sensitivity remains 13/20 versus 17/20 bilingual pairs; frozen results remain 14/20 versus 18/20. Scope confirmation does not imply approval of the four generated answers or of current-law applicability.')
d.add_heading('Separate EET framework and limits',1)
d.add_paragraph('AnvisaLegis lists RDC 305/2002 as in force with amendments. Consolidated RDC 68/2003 Article 1 addresses information for human-use products with ruminant-derived starting materials. Article 12 requires an analytical quality-control report supporting Q1 information and Q3 documents at registration or exemption requests, among other events. The Q1 form includes medicines. These separate provisions show why repeal of RDC 55 Article 22 must not be equated with elimination of EET controls. Coverage, material and geographical risks, exceptions, amendments and current filing rules need product-specific assessment. These additional instruments were outside the frozen corpus and are not imported retrospectively into its gold answers.')
d.add_heading('Interpretation',1)
d.add_paragraph('This targeted status check does not rebuild the index, validate replacement gold answers or rerun the model against current law. Current-law verification and reevaluation remain incomplete. Independent external validation and no-retrieval or official-site answer-quality baselines remain absent. Personal author confirmation covers 44 of the 80 new outputs; the remaining 36 received AI review only. The original corpus, questions, references, raw answers and scores remain unchanged.')
d.add_heading('Sources checked',1)
urls=json.loads((R/'outputs/current_law_targeted_check_20261101/official_sources.json').read_text())['sources']
for key in ['RDC406_consolidated','RDC55_consolidated','RDC948_consolidated']:
 d.add_paragraph(key.replace('_',' ')+': '+urls[key])
d.add_paragraph('RDC 305/2002 status and consolidated RDC 68/2003: complete links and access records are in official_sources.json and TARGETED_CHECK_AND_REVIEWER_RESPONSE.md in the accompanying data. All sources accessed 1 November 2026; consolidated displays do not replace the official gazette.')
d.save(D/'supplementary_targeted_legal_status_S41.docx')
changed=['manuscript_clean.docx','manuscript_tracked.docx','response_to_reviewer_2.docx','supplementary_integrated_validation_S40.docx','supplementary_information_revised.docx','supplementary_targeted_legal_status_S41.docx']
for name in changed:
 d=Document(D/name)
 for r in d._element.iter(qn('w:r')):
  rp=r.find(qn('w:rPr'))
  if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
  for tag in ['rFonts','color']:
   x=rp.find(qn('w:'+tag))
   if x is None:x=OxmlElement('w:'+tag);rp.append(x)
   x.attrib.clear()
   if tag=='color':x.set(qn('w:val'),'000000')
   else:
    for k in ['ascii','hAnsi','eastAsia','cs']:x.set(qn('w:'+k),'Arial')
 assert not any('\u2013' in acc(p._p) or '\u2014' in acc(p._p) for p in d.paragraphs)
 d.save(D/name)
proj=lambda f,a:[v for p in Document(f).paragraphs if (v:=acc(p._p) if a else rej(p._p))]
assert proj(D/'manuscript_clean.docx',True)==proj(D/'manuscript_tracked.docx',True)
assert proj(D/'manuscript_tracked.docx',False)==proj(R/'work/september_baseline.docx',True)
(N/'document_projection_QA.json').write_text(json.dumps(dict(accept_matches_clean=True,reject_matches_original_submission=True,changed=changed),indent=2))
shutil.copytree(R/'outputs/current_law_targeted_check_20261101',N/'targeted_audit',dirs_exist_ok=True)
print(N)
