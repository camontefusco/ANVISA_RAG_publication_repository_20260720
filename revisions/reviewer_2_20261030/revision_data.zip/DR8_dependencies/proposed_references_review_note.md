# Human review needed for two newly identified dependency issues

Review the four rows in dependency_reference_proposals_4_rows_NOT_APPROVED.csv against FAQ4 section 5.19.3 and Informative Note1 item4, plus RDC945 Articles4 and82–83. Confirm question scope, translation, answer completeness and current application. These are AI-assisted drafts. Approve or amend each row explicitly; the original46 draft golds have not been replaced. Prior partial-clause proposals for COMPLEX02 and COMPLEX09 remain separate.
