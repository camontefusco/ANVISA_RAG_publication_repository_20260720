# Next actions

Author approval of all eight revised reference rows is complete. The current approved CSV and S31 contain the adopted wording. Six rows change task scope and require fresh task-specific evaluation. The separate 50-row working reference collection remains inactive until the revised corpus and evaluation plan are consolidated. Remaining original-benchmark applicability work and Howard’s 40-answer review are separate tasks.
