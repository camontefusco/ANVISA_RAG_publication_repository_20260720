Current revision 31 October 2026

The combined comparison is complete: 240 generations, 240 successful attempts, no judge calls. Provisional full-task pair counts were 8/20, 9/20 and 9/20 originally, versus 14/20, 15/20 and 14/20 with manually supplemented evidence and revised instructions. Mean paired gain: 28.3 percentage points, descriptive 95% pair-cluster interval 10.0 to 48.3. Pairs passing every repeat: 7/20 versus 14/20. No partly answerable pair passed all repeats. This is an oracle-evidence development diagnostic, not a demonstrated retrieval repair. Howard’s original 10/20 result remains unchanged.

Remaining: human confirmation of new scores, current-law applicability, independent validation, no-retrieval and official-site baselines. No extra calls are authorized within this plan.
