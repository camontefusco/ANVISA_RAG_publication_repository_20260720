Current revision 1 November 2026

The clean and cumulative tracked manuscripts, reviewer response, S40, supplementary guide and new S41 incorporate the targeted legal-status audit. Staffing (RDC406 Article18) remains supported in the current consolidated text; RDC55 Articles22 and30 are revoked by RDC948. The frozen tasks explicitly concern archived text. All eight saved FV014/FV016 contexts contained the supported requirement; blanket refusals remain failures. FV012 expanded archived scope is author-confirmed. Frozen primary14/20 versus18/20 and post hoc sensitivity13/20 versus17/20 remain unchanged.

Reporting completed: both refusal failures retained; current-law verification/reevaluation explicitly incomplete; independent external validation and additional no-retrieval/official-site answer-quality baselines explicitly absent. These are acknowledged limitations, not completed experiments. Author confirmation covers44/80 new outputs;36 received AI review only.

Next: complete the final reviewer-comment consistency and evidence audit. A current-law performance claim would require a distinct corpus/reference rebuild and reevaluation. No further API calls were made or planned here.
