from pathlib import Path
import csv,json,hashlib,shutil,datetime
from collections import defaultdict
from scipy.stats import binomtest
import numpy as np
B=Path('/Users/cmontefusco/projects/ANVISA_RAG_publication');R=B/'repository/revisions/reviewer_2_20261021';O=R/'outputs/Howard36_confirmed_20261101';O.mkdir(exist_ok=True);src=Path('/Users/cmontefusco/Downloads/Howard_remaining_36_COMPLETED_AI_DRAFT.csv');shutil.copy2(src,O/src.name)
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(p,rows):
 with p.open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
V=R/'outputs/integrated_validation_completed_20261101';H=V/'human_review_private';key={r['review_id']:r for r in read(H/'coordinator_key_private.csv')};inv={r['call_id']:r for r in key.values()};pending=read(src);old=read(H/'human_confirmation_80_AUTHOR_REVIEW_IN_PROGRESS.csv');frozen={r['call_id']:r for r in read(V/'analysis/answer_quality_80.csv')};incoming={r['review_id']:r for r in pending};assert len(incoming)==36
allrows=[];overlay=[]
for r in old:
 new=r['review_id'] in incoming;t=dict(r)
 if new:
  rr=incoming[r['review_id']]
  for k,v in rr.items():t[k]=v
  t['reviewer_name']='H. L. Ribeiro Junior';t['review_date']='2026-11-01';t['review_provenance']='AI-prepared rating draft personally reviewed and approved by coauthor; corresponding author reports no prior exposure to separate AI scores, condition identities or assessment findings'
 else:t['review_provenance']='Corresponding author personal confirmation; unblinded, previous AI assessments visible'
 for k in ['expanded_archived_scope_complete','additional_source_needed']:t.setdefault(k,'')
 t['prior_exposure_before_this_review']='None reported for separate AI scores, condition identities or previous findings' if new else 'Unblinded, prior AI-assisted assessments visible'
 allrows.append(t);kk=key[r['review_id']];fr=frozen[kk['call_id']];scopefail=kk['call_id'] in ['fresh__FV_012_PT__integrated_repair','fresh__FV_012_EN__original_baseline','fresh__FV_012_PT__original_baseline'];hp=t['overall_task_success']=='Yes'
 overlay.append({'call_id':kk['call_id'],'question_id':kk['id'],'pair_id':fr['pair_id'],'condition':kk['condition'],'language':fr['language'],'frozen_AI_primary_pass':fr['primary_full_task'],'author_review_pass':str(hp),'expanded_scope_author_review_pass':str(hp and not scopefail),'reviewer':'Howard' if new else 'Corresponding author','actual_review_date':'2026-11-01','AI_prepared_rating_draft':str(new),'review_provenance':t['review_provenance'],'reported_prior_exposure':t['prior_exposure_before_this_review']})
assert len(allrows)==80 and sum(r['reviewer']=='Howard' for r in overlay)==36
write(O/'author_review_overlay_80.csv',overlay)
# Store detailed personal review privately: do not publish coordinator key.
private=O/'human_review_private';private.mkdir(exist_ok=True)
fields=list(dict.fromkeys(k for r in allrows for k in r))
with (private/'human_confirmation_80_COMPLETED.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(allrows)
pair=[]
for metric in ['frozen_AI_primary_pass','author_review_pass','expanded_scope_author_review_pass']:
 groups=defaultdict(list)
 for r in overlay:groups[r['pair_id'],r['condition']].append(r)
 for (pid,c),rr in groups.items():assert len(rr)==2;pair.append({'metric':metric,'pair_id':pid,'condition':c,'pass':str(all(r[metric]=='True' for r in rr))})
write(O/'pair_outcomes_120.csv',pair);summary={};rng=np.random.default_rng(20261101)
for metric in ['frozen_AI_primary_pass','author_review_pass','expanded_scope_author_review_pass']:
 a={r['pair_id']:{x['condition']:x['pass']=='True' for x in pair if x['metric']==metric and x['pair_id']==r['pair_id']} for r in pair if r['metric']==metric};b=np.array([v['original_baseline'] for k,v in sorted(a.items())]);t=np.array([v['integrated_repair'] for k,v in sorted(a.items())]);diff=t.astype(int)-b.astype(int);gain=int((diff==1).sum());loss=int((diff==-1).sum());ci=np.quantile(diff[rng.integers(0,20,(100000,20))].mean(axis=1),[.025,.975]);summary[metric]={'baseline_pairs':int(b.sum()),'repair_pairs':int(t.sum()),'n_pairs':20,'improved':gain,'worsened':loss,'exact_p':binomtest(gain,gain+loss).pvalue if gain+loss else 1.,'difference':float(diff.mean()),'bootstrap_95_CI':ci.tolist(),'baseline_output_passes':sum(r[metric]=='True' and r['condition']=='original_baseline' for r in overlay),'repair_output_passes':sum(r[metric]=='True' and r['condition']=='integrated_repair' for r in overlay)}
summary['changed_rows']=[{'question_id':r['question_id'],'call_id':r['call_id'],'frozen_AI_primary_pass':r['frozen_AI_primary_pass'],'author_review_pass':r['author_review_pass']} for r in overlay if r['frozen_AI_primary_pass']!=r['author_review_pass']]
(O/'summary.json').write_text(json.dumps(summary,indent=2))
provenance={'source_file':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_preserved_unchanged':True,'ratings':36,'reviewer':'Howard Lopes Ribeiro Junior','actual_review_date':'2026-11-01','approval_basis':'Corresponding author explicitly confirmed personal review and approval of all 36 including FV012 decisions in this chat','reported_exposure':'Corresponding author reports Howard saw none of the separate AI scores, condition identities or previous assessment findings before finalizing','AI_draft_assistance':'Uploaded file explicitly labelled AI_DRAFT; author approval does not erase draft origin. Ratings were reviewed from a prepared draft rather than independently elicited.','original_44':'Corresponding author personal unblinded review remains separately attributed','human_confirmed_total':80,'independent_external_validation':False,'FV012_scope':'Corresponding author already confirmed expanded Articles17/30/31. Uploaded Uncertain/scope-pending fields preserved as raw review; not treated as reversal of that prior scope decision.','IRH051':'New coauthor citation-support failure retained in separate author overlay. Expanded-scope content coverage and citation support are distinct criteria.','original_frozen_scores_changed':False}
(O/'REVIEW_PROVENANCE.json').write_text(json.dumps(provenance,indent=2));shutil.copy2('/private/tmp/incorporate_howard36_data.py',O/'incorporate_howard36_data.py');print(json.dumps(summary,indent=2))
