from pathlib import Path
import json,csv,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.ticker import PercentFormatter
P=Path(__file__).resolve().parents[2];N=Path(__file__).resolve().parents[1];D=json.loads((N/'detailed_metrics_AI_ONLY.json').read_text());R=json.loads((N/'primary_results_AI_ONLY.json').read_text());M=D['metrics'];OUT=N/'figures'
plt.rcParams.update({'font.family':'Arial','font.size':10,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
CONDS=['RAG','NO_RETRIEVAL'];names=['RAG passages','Model only'];styles=[dict(facecolor='.72',edgecolor='black'),dict(facecolor='white',edgecolor='black',hatch='///')]
def title(ax,label,t):ax.set_title(label+'  '+t,loc='left',fontweight='bold',fontsize=12,pad=13)
def axis(ax):ax.set_xlim(0,119);ax.set_xticks([0,25,50,75,100]);ax.xaxis.set_major_formatter(PercentFormatter(100));ax.grid(axis='x',color='.9',lw=.7);ax.set_axisbelow(True)
def grouped(ax,labels,data):
 y=np.arange(len(labels))
 for i,cond in enumerate(CONDS):
  vals=data[cond];positions=y+(-.18 if i==0 else .18)
  rates=[100*k/n if n else 0 for k,n in vals];ax.barh(positions,rates,height=.30,**styles[i],zorder=3)
  for yy,(k,n),v in zip(positions,vals,rates):ax.text(v+1.6,yy,f'{k}/{n}' if n else 'NA',ha='left',va='center',fontsize=9)
 ax.set_yticks(y,labels);ax.invert_yaxis();axis(ax)
rows_audit=list(csv.DictReader((N/'question_answer_audit_80.csv').open()))
fig=plt.figure(figsize=(13.2,16.6));gs=fig.add_gridspec(4,2,left=.19,right=.96,top=.89,bottom=.12,wspace=.63,hspace=.83,height_ratios=[1,1,1,.85]);axs=np.array([[fig.add_subplot(gs[r,c]) for c in range(2)] for r in range(3)])
fig.suptitle('RAG answer quality and retrieval baseline',x=.05,y=.984,ha='left',fontsize=20,fontweight='bold');fig.text(.05,.951,'Same 40 questions per answer condition | Model only: no passages or web search | AI assessment',fontsize=11)
fig.legend(handles=[Patch(label=names[i],**styles[i]) for i in range(2)],loc='upper left',bbox_to_anchor=(.045,.938),frameon=False,ncol=2)
ax=axs[0,0];title(ax,'A','Complete supported content')
grouped(ax,['Complete supported\nanswer'],{c:[M[c]['answer_success']] for c in CONDS});ax.set_xlabel('Answers (40 per condition)')
ax.text(0,-.29,'Both languages pass: RAG 19/20 pairs; model only 4/20.',transform=ax.transAxes,fontsize=8.8)
ax.text(0,-.42,'Pair difference +75 points (bootstrap 95%: +55 to +90).',transform=ax.transAxes,fontsize=8.8)
def subgroup(field,labels):
 return {c:[(sum(r['content_pass']=='True' for r in rows_audit if r['condition']==c and r[field]==label),sum(r['condition']==c and r[field]==label for r in rows_audit)) for label in labels] for c in CONDS}
ax=axs[0,1];title(ax,'B','Success by regulatory topic');labs=[x['label'] for x in D['groups']['topic']];grouped(ax,[x.replace('Biological products','Biological\nproducts') for x in labs],subgroup('topic',labs));ax.set_xlabel('Answers within each topic subgroup')
ax=axs[1,0];title(ax,'C','Success by archived answerability');labs=[x['label'] for x in D['groups']['question_type']];grouped(ax,[{'answerable':'Fully supported','partly_answerable':'Partly supported','unanswerable':'Requested detail\nabsent'}[x] for x in labs],subgroup('category',labs));ax.set_xlabel('Answers within each support subgroup')
ax=axs[1,1];title(ax,'D','Response types');codes=['S','A','B','I','H'];hatches=['','..','///','xx','++'];labels=['Complete supported','Appropriate abstention','Blanket refusal','Incomplete attempt','Complete but material error']
for i,c in enumerate(CONDS):
 left=0
 for code,h in zip(codes,hatches):
  count=M[c]['response_classes'].get(code,0)
  if count:
   ax.barh(i,count/40*100,left=left,height=.45,color='white',edgecolor='black',hatch=h,lw=.8)
   if count>=5:ax.text(left+count/40*50,i,str(count),ha='center',va='center',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',pad=1))
   left+=count/40*100
ax.text(101,0,'1',va='center',fontsize=9,clip_on=False);ax.set_yticks([0,1],names);ax.set_ylim(1.6,-.6);ax.set_xlim(0,100);ax.xaxis.set_major_formatter(PercentFormatter());ax.set_xlabel('Answers (40 per condition; labels are counts)');ax.legend(handles=[Patch(facecolor='white',edgecolor='black',hatch=h,label=f'{c}: {l}') for c,h,l in zip(codes,hatches,labels)],loc='upper left',bbox_to_anchor=(-.05,-.28),frameon=False,fontsize=8.4,ncol=2,columnspacing=1)
ax=axs[2,0];title(ax,'E','Omissions, errors and citations');keys=['omission_answers','material_claim_flags','inappropriate_refusals','citation_present'];grouped(ax,['At least one\nomitted component','Material incorrect\nclaim flagged','Inappropriate\nblanket refusal','Article citation\npresent'],{c:[(M[c][k][0],40) for k in keys] for c in CONDS});ax.set_xlabel('Answers (40 per condition)');ax.text(0,-.27,'Refusal flags use all 40 answers here: RAG 0; model only 20.',transform=ax.transAxes,fontsize=8.1);ax.text(0,-.39,'Among cited: 1/39 incorrect for RAG; model only not estimable.',transform=ax.transAxes,fontsize=8.1)
ax=axs[2,1];title(ax,'F','Answers flagged for content repair');grouped(ax,['At least one\ncontent repair flag'],{c:[M[c]['content_repair_needed']] for c in CONDS});ax.set_xlabel('Answers (40 per condition)');ax.text(0,-.27,'Proxy only; no human time or editing effort measured.',transform=ax.transAxes,fontsize=8.5);ax.text(0,-.39,'Component-level counts are reported separately.',transform=ax.transAxes,fontsize=8.5)
rr={x['metric']:x for x in csv.DictReader((N/'retrieval_panel_source_metrics.csv').open())}
ax=fig.add_subplot(gs[3,:]);title(ax,'G','Retrieval coverage on the same archived question set')
oldconds=CONDS[:];oldstyles=styles[:];CONDS[:]=['BM25','HYBRID'];styles[:]=[dict(facecolor='white',edgecolor='black',hatch='///'),dict(facecolor='.72',edgecolor='black')]
grouped(ax,['All required articles\nin top five chunks','Full required article text\nafter article completion'],{c:[tuple(map(int,rr[k][column].split('/'))) for k in ['All required articles represented at 5','Full required article text after identical completion']] for c,column in [('BM25','BM25_only'),('HYBRID','frozen_hybrid')]});ax.set_xlabel('Eligible questions (32 per retriever; eight absent-detail questions excluded)');ax.legend(handles=[Patch(label='BM25 keyword retrieval',**styles[0]),Patch(label='Frozen hybrid plus reranking',**styles[1])],loc='center',bbox_to_anchor=(.60,.50),ncol=2,frameon=True,facecolor='white',edgecolor='none',fontsize=9)
CONDS[:]=oldconds;styles[:]=oldstyles
fig.text(.05,.027,'All answer panels use the same 40 questions per condition; B and C partition that set into labelled subgroups.\nG measures source coverage, not generated-answer quality, using the same queries and archived index for both retrievers.\nAI-only post hoc answer assessment; no human workflow or measured correction burden. Reliable hybrid superiority is unproven.',fontsize=9,linespacing=1.5)
def save(fig,stem):
 for ext in ['pdf','svg','png']:fig.savefig(OUT/(stem+'.'+ext),dpi=220 if ext=='png' else 300)
 fig.savefig(OUT/(stem+'.tif'),dpi=300,pil_kwargs={'compression':'tiff_lzw'})
save(fig,'Figure_model_comparison_detailed');plt.close(fig)
# Separate detailed task map keeps the 20 questions readable.
rows=list(csv.DictReader((N/'task_map_20.csv').open()));ordered=[]
for topic in ['Clinical trials','Pharmacovigilance','Medical devices','Biological products']:ordered.extend([x for x in rows if x['topic']==topic])
fig,ax=plt.subplots(figsize=(10.5,12.2));fig.subplots_adjust(left=.035,right=.97,top=.88,bottom=.17);ax.set_xlim(0,11);ax.axis('off');ax.set_ylim(26,-1)
fig.suptitle('Task topics and answer outcomes',x=.035,y=.98,ha='left',fontsize=20,fontweight='bold');fig.text(.035,.938,'20 bilingual pairs | PT = Portuguese; EN = English | AI-only post hoc classification',fontsize=11)
xs=[7.9,8.65,9.5,10.25];ax.text(8.27,-.7,'RAG',ha='center',fontweight='bold');ax.text(9.87,-.7,'Model only',ha='center',fontweight='bold')
for x,l in zip(xs,['PT','EN','PT','EN']):ax.text(x,-.05,l,ha='center',va='center',fontweight='bold')
ax.text(.1,-.05,'Task and subtopic',fontweight='bold');ax.text(6.4,-.05,'Type',fontweight='bold',ha='center');y=1;last=None
for r in ordered:
 if r['topic']!=last:
  ax.add_patch(Rectangle((.05,y-.3),10.65,.7,facecolor='.9',edgecolor='none'));ax.text(.12,y+.05,r['topic'],fontweight='bold',va='center');last=r['topic'];y+=1
 ax.text(.12,y,r['pair_id']+'  '+r['subtopic'],va='center',fontsize=10)
 ax.text(6.4,y,{'answerable':'Ans.','partly_answerable':'Part','unanswerable':'Unans.'}[r['question_type']],ha='center',va='center',fontsize=9)
 for x,k in zip(xs,['RAG_pt','RAG_en','NO_RETRIEVAL_pt','NO_RETRIEVAL_en']):
  code=r[k];ax.add_patch(Rectangle((x-.30,y-.36),.60,.72,facecolor='white',edgecolor='black',lw=.8));ax.text(x,y,code+('*' if code=='H' else ''),ha='center',va='center',fontweight='bold')
 ax.plot([.1,10.65],[y+.47,y+.47],color='.87',lw=.5);y+=1
fig.text(.04,.12,'Archived support: Ans. = full support; Part = partial support; Unans. = requested detail absent.\nResponse codes: S = complete supported answer; A = appropriate abstention; B = blanket refusal;\nI = incomplete attempted answer; H = complete checklist with a material incorrect claim.',fontsize=10,linespacing=1.6)
fig.text(.04,.045,'* FV_004 English: DPI incorrectly equated with an Investigator\'s Brochure. Original output and failure retained.\nThe four unanswerable pairs passed in both conditions; abstention on those questions is appropriate.\nFull questions, answers, frozen rationales and proposed repair checklists accompany the figure.',fontsize=9.5,linespacing=1.5)
fig.text(.04,.015,'Model only: stored knowledge, with no passages or web search. Archived support is not online answer availability.',fontsize=9)
save(fig,'Figure_model_comparison_task_map');plt.close(fig)
print('Created two detailed scientific figures in PDF, SVG, PNG and 300 dpi TIFF.')
