# BM25 and frozen hybrid retrieval comparison

The lexical BM25 baseline performed strongly on these archived questions. With the same saved retrieval queries and named-regulation filtering, all required gold articles appeared in the top five chunks for 30/32 questions with BM25 and 32/32 with the frozen hybrid retriever. This small comparison does not establish a reliable hybrid advantage or equivalence.

## Matched comparison
Both methods use the identical 482 repaired index chunks, metadata and the exact saved retrieval queries. English questions use the same previously generated Portuguese translation in both methods. BM25 uses the frozen lexical tokenizer and searchable text, standard BM25Okapi parameters, top 100 candidates followed by the named-regulation filter and the first five surviving chunks. It does not use dense embeddings or reranking. The comparator reuses the exact saved top five hybrid and reranked chunk IDs; the unchanged completion code was independently reconstructed and its output matched every saved hybrid context. No new model, translation or API call was made.

The targets are physical archived article occurrences, avoiding accidental pooling of repeated article labels. The expanded FV012 reference uses Articles 17, 30 and 31. Only the 32 answerable or partly answerable language items, forming 16 bilingual pairs, have positive gold retrieval targets. The eight unanswerable language items are excluded rather than assigning automatic recall credit or failure to a fact absent from the reference corpus. This is a post hoc baseline; its protocol was recorded before computing the BM25 scores.

## Results
| Metric | BM25 only | Frozen hybrid plus reranking |
| --- | --- | --- |
| Mean gold-article Recall at 5 | 95.8% | 100% |
| At least one required article found at 5 | 31/32 | 32/32 |
| All required articles represented at 5 | 30/32 | 32/32 |
| Full text of all required articles in five chunks | 29/32 | 30/32 |
| Mean reciprocal rank within top five | 0.932 | 0.964 |
| Full required article text after identical completion | 31/32 | 32/32 |
| Median returned tokens after completion | 3697 | 3953.5 |

The hybrid minus BM25 difference in mean article recall was +4.2 percentage points, with a descriptive 95% bootstrap interval of 0 to +11.5 points. For all-article presence at five it was +6.25 points, interval 0 to +15.625. For full article text after completion it was +3.125 points, interval 0 to +9.375. For mean reciprocal rank it was +0.031, interval -0.057 to +0.130. Intervals resample 16 whole bilingual pairs, not 32 independent questions. Small shared-source samples limit interpretation.

BM25 initially missed one of the three required articles for FV012 Portuguese; the same completion policy recovered it. BM25 missed the required ruminant-documentation article for FV016 English, which completion did not recover. These cases are retained, with no tuning or rerun to remove them.

## English query sensitivity
BM25 using the original English wording found all required articles for 5/16 English questions, versus 15/16 using the saved Portuguese translations and 16/16 for hybrid retrieval using those translations. This secondary contrast shows sensitivity to query language on a Portuguese corpus. It is not the primary comparison and is not evidence that hybrid retrieval beats an equally translated BM25 baseline by the same large margin.

## Limits of the measurements
Article presence and complete article text are structural source-coverage measures, not proof that the passages are semantically sufficient or that the generator answers correctly. After completion, both methods apply the same policy but return different amounts of text; five seed chunks do not imply equal final token budgets. No answer-generation comparison between BM25-supplied and hybrid-supplied contexts was conducted. No human or Google-search workflow, current-law accuracy, latency benefit or independent validation was tested. The earlier RAG-versus-model-only answer comparison remains separate.
