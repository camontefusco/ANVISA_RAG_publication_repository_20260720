from pathlib import Path
import csv,json
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
B=Path(__file__).resolve().parent;N=B;O=B/'figures';O.mkdir(exist_ok=True);H=B;r=list(csv.DictReader((H/'ratings_expanded_120_AUTHOR.csv').open()));summary=json.loads((H/'RESULTS_AUTHOR.json').read_text())
plt.rcParams.update({'font.family':'Arial','font.size':10,'text.color':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','svg.fonttype':'none','pdf.fonttype':42})
conds=['RAG','BM25','NO_RETRIEVAL'];labels=['Hybrid passages','BM25 passages','Model only'];colors=['.35','.75','white'];hatches=['','..','///']
def subset(c):return [x for x in r if x['condition']==c]
def topic(q):
 n=int(q[3:6]);return 'Clinical trials' if n in [1,2,3,4,13,17] else 'Pharmacovigilance' if n in [5,6,7,8,14,18] else 'Medical devices' if n in [9,10,11,15,19] else 'Biological products'
def chart(ax,title,groups,predicate,subgroup=None):
 ax.set_title(title,loc='left',fontweight='bold',pad=12);y=np.arange(len(groups));height=.23
 for j,c in enumerate(conds):
  nums=[];dens=[]
  for g in groups:
   s=[x for x in subset(c) if subgroup is None or subgroup(x,g)];nums.append(sum(predicate(x,g) for x in s));dens.append(len(s))
  vals=[n/d*100 for n,d in zip(nums,dens)];bars=ax.barh(y+(j-1)*height,vals,height,color=colors[j],hatch=hatches[j],edgecolor='black',linewidth=.7,label=labels[j])
  for bar,n,d in zip(bars,nums,dens):ax.text(bar.get_width()+1,bar.get_y()+height/2,f'{n}/{d}',va='center',fontsize=8)
 ax.set_yticks(y,groups);ax.invert_yaxis();ax.set_xlim(0,113);ax.set_xticks([0,25,50,75,100],['0%','25%','50%','75%','100%']);ax.spines[['right','top']].set_visible(False);ax.set_axisbelow(True);ax.grid(axis='x',alpha=.2)
fig=plt.figure(figsize=(13,16));gs=fig.add_gridspec(4,2,height_ratios=[1,1.2,1,1.1],hspace=.85,wspace=.85,left=.23,right=.94,top=.89,bottom=.12)
a=fig.add_subplot(gs[0,0]);chart(a,'A  Content and evidence-boundary success',['All answers'],lambda x,g:x['content_pass']=='True');a.set_xlabel('Same 40 answers per condition')
a=fig.add_subplot(gs[0,1]);chart(a,'B  Success by regulatory topic',['Clinical trials','Pharmacovigilance','Medical devices','Biological products'],lambda x,g:x['content_pass']=='True',lambda x,g:topic(x['id'])==g)
a=fig.add_subplot(gs[1,0]);chart(a,'C  Success by archived support',['Fully supported','Partly supported','Requested detail absent'],lambda x,g:x['content_pass']=='True',lambda x,g:x['category']=={'Fully supported':'answerable','Partly supported':'partly_answerable','Requested detail absent':'unanswerable'}[g]);a.set_xlabel('Answers within each support subgroup')
a=fig.add_subplot(gs[1,1]);chart(a,'D  Omissions and material claim flags',['At least one omission','Material claim flag'],lambda x,g:x['complete_supported_information']=='No' if g=='At least one omission' else x['no_material_incorrect_or_unsupported_claim']=='No');a.set_xlabel('Affected answers out of 40')
a=fig.add_subplot(gs[2,0]);chart(a,'E  Article citation present',['Citation present'],lambda x,g:x['article_citation_present']=='Yes');a.set_xlabel('Answers out of 40');a.text(0,-.48,'Author-rated support among citing answers:\nhybrid 39/39; BM25 37/38; model only not estimable.',transform=a.transAxes,fontsize=8,va='top')
a=fig.add_subplot(gs[2,1]);chart(a,'F  Answers flagged for correction',['Correction flag'],lambda x,g:x['content_repair_needed']=='Yes');a.set_xlabel('Answers out of 40');a.text(0,-.48,'No human time or editing effort measured.\nFlags overlap with omissions and claim errors.',transform=a.transAxes,fontsize=8,va='top')
a=fig.add_subplot(gs[3,:]);a.set_title('G  Retrieval coverage on the same archived question set',loc='left',fontweight='bold',pad=12)
for j,(lab,col,h,vv) in enumerate([('BM25 keyword retrieval','.75','..',[30,31]),('Frozen hybrid plus reranking','.35','',[32,32])]):
 yy=np.arange(2)+(j-.5)*.28;bars=a.barh(yy,np.array(vv)/32*100,.28,label=lab,color=col,hatch=h,edgecolor='black')
 for bar,v in zip(bars,vv):a.text(bar.get_width()+1,bar.get_y()+.14,f'{v}/32',va='center',fontsize=9)
a.set_yticks([0,1],['All required articles\nin five seed chunks','Full required article text\nafter article completion']);a.invert_yaxis();a.set_xlim(0,113);a.set_xticks([0,25,50,75,100],['0%','25%','50%','75%','100%']);a.spines[['top','right']].set_visible(False);a.set_xlabel('32 positive-target questions; eight absent-detail questions excluded');a.legend(loc='center',bbox_to_anchor=(.5,.5),ncol=2,frameon=False,fontsize=9)
handles=[plt.Rectangle((0,0),1,1,facecolor=colors[j],edgecolor='black',hatch=hatches[j]) for j in range(3)];fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.03,.95),ncol=3,frameon=False)
fig.text(.03,.98,'Coauthor assessed answer quality and retrieval baseline',fontsize=20,weight='bold',va='top');fig.text(.03,.953,'Same 40 questions per answer condition | Model only: no passages or web search',fontsize=10)
fig.text(.03,.047,'Pair success: hybrid 19/20; BM25 18/20; model only 4/20. Hybrid minus BM25: +5 points (95% bootstrap -10 to +20).\nAll eight absent-detail answers appropriately abstained per condition. Topic and support panels partition the same questions.\nAuthor ratings; prior project exposure and limited condition masking. Sequential BM25 extension. No established hybrid superiority.\nCitation judgments differ from the preserved AI layer. Structural retrieval coverage does not establish answer correctness.',fontsize=9,va='bottom',linespacing=1.5)
for ext in ['png','pdf','svg','tif']:fig.savefig(O/f'Figure_5_model_and_retrieval_comparison.{ext}',dpi=300,facecolor='white')
plt.close(fig)
# Six-answer task map, derived entirely from returned primary labels.
fig,ax=plt.subplots(figsize=(12,15));ax.set_xlim(0,12);ax.set_ylim(0,29);ax.axis('off');ax.text(0,28.5,'Task topics and coauthor assessed answer outcomes',fontsize=19,weight='bold');ax.text(0,27.8,'20 bilingual pairs | PT = Portuguese; EN = English | Shared archived task references',fontsize=10)
xs=[6.6,7.4,8.5,9.3,10.4,11.2];ax.text(.1,26.8,'Task and subtopic',weight='bold')
for x,l in [(7,'Hybrid'),(8.9,'BM25'),(10.8,'Model only')]:ax.text(x,27,l,ha='center',weight='bold')
for x,l in zip(xs,['PT','EN']*3):ax.text(x,26.4,l,ha='center',weight='bold')
names={1:'Human exposure',2:'DPI structure',3:'DEEC linkage',4:'Substantial modification',5:'RFV information',6:'Training records',7:'Self-inspection',8:'Pregnancy follow-up',9:'Equipment labels',10:'Nonprinted instructions',11:'Internet instructions',12:'Manufacturers and GMP',13:'Supply and reserve stock',14:'Staffing criterion',15:'Responsibility and signatures',16:'Ruminant documentation',17:'Emergency duration',18:'Report file size',19:'TLS version',20:'Panel quorum'}
y=25.5
for top,nums in [('Clinical trials',[1,2,3,4,13,17]),('Pharmacovigilance',[5,6,7,8,14,18]),('Medical devices',[9,10,11,15,19]),('Biological products',[12,16,20])]:
 ax.add_patch(plt.Rectangle((0,y-.15),12,.5,facecolor='.9',edgecolor='none'));ax.text(.1,y,top,weight='bold');y-=.8
 for n in nums:
  q=f'FV_{n:03}';ax.text(.1,y,f'{q}  {names[n]}',va='center',fontsize=10)
  for j,(c,l) in enumerate([(c,l) for c in conds for l in ['pt','en']]):
   x=next(x for x in r if x['pair_id']==q and x['condition']==c and x['language']==l)
   code='A' if x['category']=='unanswerable' and x['content_pass']=='True' else 'S' if x['content_pass']=='True' else 'H' if x['no_material_incorrect_or_unsupported_claim']=='No' else 'I'
   ax.add_patch(plt.Rectangle((xs[j]-.27,y-.23),.54,.46,facecolor='white',edgecolor='black',linewidth=.7));ax.text(xs[j],y,code,ha='center',va='center',weight='bold')
  y-=.72
 y-=.2
ax.text(0,3.5,'S: supported content success; A: appropriate abstention for absent detail;\nH: material claim flag (takes precedence); I: another content failure.\nThese display classes summarize primary criteria; citations are assessed separately.\nPrior project exposure and limited condition masking; not independent external validation.\nArchived support does not describe online availability.',fontsize=10,va='top',linespacing=1.7)
for ext in ['png','pdf','svg','tif']:fig.savefig(O/f'Supplementary_Figure_S1_task_map.{ext}',dpi=300,facecolor='white',bbox_inches='tight')
print(O)
