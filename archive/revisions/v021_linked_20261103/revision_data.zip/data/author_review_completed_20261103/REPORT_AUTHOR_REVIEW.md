# Completed coauthor comparison assessment

Received 3 November 2026. Howard personally reviewed and approved all 118 distinct answer records on 2 November 2026 and drafted the ratings himself, as confirmed by the corresponding author in this chat. The submitted provenance CSV has contradictory/truncated fields; it is preserved unchanged, with the clarification recorded separately in NORMALIZED_PROVENANCE.json.

All 118 answer IDs, question IDs and languages match the prepared pack. Every answer hash matches its frozen generation. Two exact duplicates expand the 118 personal ratings to 120 condition records; these are not 120 independent judgments or questions. Each condition contains the same 40 language-specific questions in 20 bilingual pairs.

## Results derived from Howard's returned fields

| Endpoint | Hybrid RAG | BM25 passages | Model only |
| --- | --- | --- | --- |
| Content and evidence-boundary success | 39/40 | 38/40 | 9/40 |
| Both languages successful | 19/20 | 18/20 | 4/20 |
| Answerable pairs successful | 11/12 | 11/12 | 0/12 |
| Partly answerable pairs successful | 4/4 | 3/4 | 0/4 |
| Unanswerable pairs successful | 4/4 | 4/4 | 4/4 |
| Answers with omissions | 0/40 | 1/40 | 31/40 |
| Answers with material incorrect/unsupported claim flags | 1/40 | 1/40 | 14/40 |
| Article citation present, as rated | 39/40 | 38/40 | 0/40 |
| Citation support correct among cited answers, as rated | 39/39 | 37/38 | Not estimable |
| Answers flagged for correction | 1/40 | 2/40 | 32/40 |

Primary content success excludes citation formatting and need not imply that no editing is needed. All eight absent-detail answers in each condition appropriately abstained. Correction flags do not measure actual human time or editing burden.

Hybrid minus model-only bilingual-pair success is +75 percentage points (descriptive whole-pair bootstrap 95% interval +55 to +90; 15 gains, no losses; exact p = 0.000061). Hybrid minus BM25 is +5 points (interval -10 to +20; two gains, one loss; exact p = 1.000). The latter does not establish hybrid superiority or equivalence. Both comparisons use 20 pairs, 20,000 whole-pair bootstrap draws and seed 20261102.

## Disagreements and retained failures

The human and AI primary content labels agree on 117/118 distinct rated records. This is descriptive agreement on this selected set, not independent validation. HCR_056 / NRC_002 / FV_015 English is accepted for content by Howard and failed by the AI; model-only answer success therefore becomes 9/40 rather than 8/40, while pair success stays 4/20. Howard flags this answer for correction and gives it no citation; that is compatible with the citation-secondary primary endpoint. Its hedged responsibility wording remains visible in the original answer and notes.

Howard confirms BM25 HCR_063 / BMA_015 / FV_012 Portuguese as a material unsupported checklist addition, and HCR_019 / BMA_004 / FV_016 English as incomplete. BM25 remains 38/40 answers and 18/20 pairs. The earlier AI sensitivity accepting the intermediate-manufacturer addition is retained as historical sensitivity, not adopted as the human primary result.

The FV_012 rationale requires precision: intermediate products are mentioned elsewhere in archived Article 31 paragraph 6, but are absent from the explicit name/address list in Articles 17 and 31 II. The unsupported extension concerns that explicit list; a blanket claim that intermediate products never appear in Article 31 would be incorrect. Howard's original wording and ratings remain preserved unchanged.

For FV_016 English, Howard used the common page reference rather than the actual generator context, as explicitly declared in his provenance. His label of unjustified refusal should therefore be read as missing required reference content, not proof that the generator withheld evidence it received. The saved BM25 context lacks Article 22; the AI evidence-path diagnosis remains separate from Howard's common-reference quality rating. The answer does identify the unavailable form code, although Howard rates unavailable-detail handling No because supported content is also withheld. Preserve this domain disagreement rather than infer missing retrieval from human scores alone.

There are nine additional field-level disagreements, listed in AI_Howard_disagreements.csv. These include citation counting/support and materiality judgments. Howard rates the hybrid DPI/Investigator's Brochure answer as containing a material error but its citation support as correct; the AI failed citation support as well. These separate layers should not be blended into a single apparent consensus. The final article may use Howard's returned secondary fields if explicitly identified as author ratings, with the AI layer and disagreement table retained.

## Review provenance and scope

Howard reports no exposure to AI scores, concealed condition identities or prior findings for these generated answers before finalizing. He had substantial prior project/question exposure, and answer style may reveal conditions. This is coauthor assessment with attempted condition masking, not independent external validation. The user clarified that Howard drafted these ratings himself; older AI-draft assistance disclosures for different studies remain applicable to those older records.

The technical study asks whether supplying evidence improves model answers and whether hybrid retrieval adds value over matched BM25 retrieval. The findings favor evidence provision on these archived, development-exposed tasks, but do not establish a hybrid advantage. Google search and actual human workflow benefit are outside this experiment's scope, not objectives the technical benchmark must fulfill. Current-law rebuilding, fresh independent validation, source dependence, single generations and sequential BM25 execution remain explicit limitations.

## Publication status

The human-review dependency for these 120 comparison outputs is now complete. No new model calls, remote uploads or changes to frozen AI scores were made. Manuscript/figure/response integration and final release checks remain required before publication. The 2 November submission snapshot remains an intact earlier version; this dated report supersedes its pending-human-review status for these new outputs only. It does not complete human verification of the separate historical 300-output window-pooling study.
