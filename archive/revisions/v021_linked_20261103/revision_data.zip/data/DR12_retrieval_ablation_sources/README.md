# Supplementary Tables S14 and S15

Recovered numeric source records from the completed 25 October 2026 retrieval ablation. Added to the submission archive during the 3 November table consistency sweep. No analysis was rerun and no values were changed. Original dated source files remain preserved locally.
