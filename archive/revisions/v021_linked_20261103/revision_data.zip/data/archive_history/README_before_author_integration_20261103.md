# Current submission evidence guide, 2 November 2026

Use this guide for current interpretation. Historical freeze records retain creation-time status and original reference numbering. Do not treat superseded pending-review fields as the current status, or current approvals as applying to later answers.

## Assessment layers

- Historical six-stage study: 404 outputs, 254 distinct IDs. Development stages overlap. The original 94-output coauthor review was AI-draft-assisted and unblinded.
- Frozen 40-answer assessment: Howard reviewed all 40 answers generated on 30 October; 10/20 bilingual pairs passed.
- Earlier exploratory repair comparison (Table 3/Figure 4): all 80 outputs received author review, 44 corresponding-author confirmations and 36 coauthor-reviewed AI-draft ratings on 1 November. Completed author pair results are 14/20 versus 17/20; initial AI results 14/20 versus 18/20 remain a separate layer. Expanded-scope author sensitivity is 13/20 versus 17/20.
- New common-prompt model comparison (Table 4/Figure 5/S10): 80 answers on the same 40 questions. AI-only content and evidence-boundary success is 39/40 RAG versus 8/40 model-only, including eight appropriate abstentions in each condition; bilingual success is 19/20 versus 4/20. New human confirmation is pending. Model-only has stored knowledge, no document passages and no web-search tool. This is not a comparison with a person searching Google.
- Matched lexical retrieval: 32 positive-target questions; BM25 versus hybrid all-article coverage at five chunks is 30/32 versus 32/32, and full required article text after completion is 31/32 versus 32/32. Eight absent-detail questions are excluded from retrieval recall. Coverage is not answer quality or proof of reliable hybrid superiority.
- BM25-context extension: 40 answers, from 39 new calls plus one exact-prompt cached answer, with 40 saved hybrid comparators. No BM25 answer-quality scores are reported.
- The separate Howard package contains 120 analysis records mapped to 118 distinct question-answer records after exact-text deduplication. Its new personal ratings remain pending. The concealed condition key and private coordination files are excluded from this submission.

All main answer metrics use 40 answers per condition. The frozen model-comparison metrics also retain conditional inappropriate-refusal rates among 32 positive-target answers; Figure 5 and Table 4 display the affected-answer counts over all 40. These denominators answer different questions and are explicitly labelled. The 110 reference components are nested within the same 40 questions, not 110 independent questions.

Supplementary Data S1 is historical_S1_S2/supplementary_S1_relabelled.csv; Supplementary Data S2 is historical_S1_S2/supplementary_S2_relabelled.csv. Each contains 404 rows. The literal historical judge prompt is historical_S1_S2/automated_judge_criteria_and_literal_prompt.md.

New comparisons and original figure source data are in comparative_baselines_20261102/. The revised display code and labels, reference-number map, correction log and audit evidence are in quality_sweep_20261102/. The older figure sources remain historical records.

# Submission evidence guide

This curated archive supports the final archived-corpus manuscript and Supplementary Sections S1 to S10. Original generated answers, judge scores, known problematic golds and failed controls are retained as evidence, not presented as current-law truth. No historical result was silently corrected or removed for being negative.

- historical_S1_S2: all 404 evaluated historical rows and 404 judge rows, with corrected development-stage labels, exact judge prompt and overlap audits.
- historical_author_review: original94-output review, comparison records and separate confirmation/date provenance; AI-assisted and unblinded.
- four_question_context_controls and ethics_length_and_prompt_controls: exact early control inputs, raw outputs, repeat membership and summaries.
- current_adjudication: separate archived-corpus label and refusal overlays; original labels remain available.
- Howard40_review: 40 frozen answers, selected evidence, references, ratings, date correction and derived 20-pair outcomes.
- DR11, DR13 and sibling_context: completed embedding, retrieval-rule and sibling-context analyses, including negative results and review limitations.
- partial_prompt_pilot, partial_mechanism_factorial, combined_repair_comparison, automatic_evidence_followup and residual_mechanisms: development controls, failures and raw outputs underlying Section S7.
- integrated_validation_completed_20261101: frozen new questions, references, plan/prompt hashes, 20 translations, 80 raw/processed answers and original AI assessments. Historical frozen fields stating authorization or human review was pending describe their creation time, not current status.
- integrated_scope_resolved_20261101: separate FV012 sensitivity and review provenance. All 80 earlier repair outputs have personal author review: 44 corresponding-author confirmations and 36 coauthor-reviewed AI-draft ratings. This is distinct from the new S10 comparisons awaiting human ratings. The review overlay does not imply independent validation.
- current_law_targeted_check_20261101 and DR8_clause_audit: source-status evidence and explicit applicability limits. RDC 55 Articles 22 and 30 are revoked; archived-task scores remain unchanged.
- source_provenance: source checksums and official-source links.
- reproducibility_code: source and evaluation code. Reproduction of retrieval requires the original local corpus/vector assets; these and credentials are excluded. Exact hosted-model outputs are not guaranteed reproducible.


## Remaining limitations

Current-law corpus rebuilding and reevaluation, fresh independent external validation, an official-site search comparator, measured human workflow benefit and a multilingual embedding-model comparison remain absent or incomplete. The new Codex assessment does not independently verify or rescore the historical Gemini judge; the 300-output window-pooling study is not fully human verified. New comparison scores need human confirmation and BM25 answers need scoring. Raw failures, negative results and original source exposure remain retained.

The prior active README is retained exactly at archive_history/README_before_quality_sweep_20261102.md. All other pre-sweep data entries remain unchanged. Full source/index assets, credentials and private review keys are excluded. No remote upload is asserted.
