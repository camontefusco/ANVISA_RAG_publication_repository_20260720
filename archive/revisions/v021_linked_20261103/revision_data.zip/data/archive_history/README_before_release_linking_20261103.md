# Current submission evidence guide, 3 November 2026

This active guide supersedes historical pending-review status. Original freeze records and earlier reports retain creation-time status and scores; they must not be mistaken for the current assessment layer.

## Current assessment layers

- Historical stages: 404 outputs, 254 distinct IDs, overlapping development and calibration sets. The selected 94-output review was AI-draft-assisted and unblinded; 44 sibling outputs and the separate 40-answer assessment have their own provenance.
- Earlier exploratory repair comparison (Table 3/Figure 4): all 80 outputs have author review, 44 corresponding-author confirmations and 36 coauthor-reviewed AI-draft ratings on 1 November. Author pairs are 14/20 versus 17/20, with expanded-scope sensitivity 13/20 versus 17/20. Initial AI scores 14/20 versus 18/20 remain separate.
- Common-prompt three-condition comparison (Table 4/Figure 5/S10): Howard personally drafted and approved 118 distinct ratings covering all 120 condition records on 2 November, received 3 November. Returned provenance reports no prior AI scores, condition key or findings for these outputs, with prior project/question exposure and possible style unmasking. The corresponding author clarified contradictory/truncated fields; originals remain unchanged. This is coauthor assessment, not independent external validation.
- Author content/evidence-boundary success: hybrid 39/40 answers, 19/20 pairs; BM25 38/40, 18/20; model-only 9/40, 4/20. Each condition includes eight appropriate abstentions. Model-only has stored knowledge but no passages or web search, not a person using Google.
- One primary AI/author disagreement changes model-only success from AI 8/40 to author 9/40. Pair success stays 4/20. Nine secondary field disagreements, including citation counting and support, remain explicit. Correction flags are not observed editing time.
- Matched retrieval: 32 positive-target questions, excluding eight absent-detail questions. BM25/hybrid all-article coverage at five is 30/32 versus 32/32; full text after completion is 31/32 versus 32/32. BM25 generation used 39 new calls and one cached exact-prompt answer, with sequential saved hybrid comparators. No reliable hybrid answer-quality advantage is established.

All main answer metrics use the same 40 answers per condition. The 110 component units in initial AI source data are nested within those questions, not 110 extra observations and not a new human component recount. Original conditional refusal rates among 32 positive-target answers retain their original denominator. Do not blend those with all-answer counts or the new human fields.

## File map

Supplementary Data S1: historical_S1_S2/supplementary_S1_relabelled.csv (404 rows).
Supplementary Data S2: historical_S1_S2/supplementary_S2_relabelled.csv (404 rows).
Literal original judge prompt: historical_S1_S2/automated_judge_criteria_and_literal_prompt.md.

Historical_author_review, current_adjudication and Howard40_review preserve original reviews and separate label overlays. DR11, DR13, sibling_context and mechanism/control folders retain development tests, negative results and failures. integrated_validation_completed_20261101, integrated_scope_resolved_20261101 and author_review_completion_80_20261101 retain the earlier repair experiment and review completion. current_law_targeted_check_20261101 and DR8_clause_audit record limited official-source checks, not complete current-law verification. source_provenance and reproducibility_code supply source hashes, links and implementation files; reproduction of original retrieval requires excluded local corpus/index assets.

comparative_baselines_20261102 retains frozen common-prompt outputs, original AI scores, matched retrieval and BM25 generations. quality_sweep_20261102 records the previous editorial audit and figure code. author_review_completed_20261103 contains current author outcomes, original returned files, normalized provenance, disagreements and self-contained author figure sources. Older figure code and status reports are retained as history; use the latest author figure source for the current manuscript.

## Limits and preservation

Current-law corpus rebuilding/reevaluation, fresh independent external validation and a multilingual replacement encoder comparison remain incomplete or absent. The historical 300-output window-pooling study is not fully human verified. Current-law accuracy, web-search superiority and human workflow benefit are not established. The latter two are outside this technical comparison's aim.

The prior active guide is preserved byte-for-byte under archive_history/README_before_author_integration_20261103.md. All other prior entries are unchanged. Full source/index corpora, credentials and the private condition key are excluded. The separate returned original ratings and provenance do not include the private coordination key. No remote upload is asserted.
