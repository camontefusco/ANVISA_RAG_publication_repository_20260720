# Current author-review update on 1 November 2026

All 80 exploratory outputs now have personal author review: 44 corresponding-author confirmations and 36 coauthor-reviewed AI-draft ratings. The corresponding author reports no exposure to separate AI scores, condition identities or prior assessment findings for the latter review. AI-draft origin remains disclosed. See author_review_completion_80_20261101 for the original returned file, separate provenance, public call-ID overlay and pair analyses.

Completed author review gives 14/20 baseline and 17/20 repaired pairs (four improved, one worsened; exact p = 0.375). The frozen initial AI result remains 14/20 versus 18/20. Expanded-scope author review remains 13/20 versus 17/20. IRH_051 is the new specific citation-support failure. Frozen references, raw generations and initial AI scores were not overwritten.

The earlier review_provenance_80.csv and other prior freeze/export records below describe the state BEFORE this completion and remain historical records. They must not be read as the current human-review denominator. Current-law reevaluation, the planned new held-out test, separate-family judge and independent external validation are not completed by this update.

# Submission evidence guide

This curated archive supports the final archived-corpus manuscript and Supplementary Sections S1 to S9. Original generated answers, judge scores, known problematic golds and failed controls are retained as evidence, not presented as current-law truth. No historical result was silently corrected or removed for being negative.

- historical_S1_S2: all 404 evaluated historical rows and 404 judge rows, with corrected development-stage labels, exact judge prompt and overlap audits.
- historical_author_review: original94-output review, comparison records and separate confirmation/date provenance; AI-assisted and unblinded.
- four_question_context_controls and ethics_length_and_prompt_controls: exact early control inputs, raw outputs, repeat membership and summaries.
- current_adjudication: separate archived-corpus label and refusal overlays; original labels remain available.
- Howard40_review: 40 frozen answers, selected evidence, references, ratings, date correction and derived 20-pair outcomes.
- DR11, DR13 and sibling_context: completed embedding, retrieval-rule and sibling-context analyses, including negative results and review limitations.
- partial_prompt_pilot, partial_mechanism_factorial, combined_repair_comparison, automatic_evidence_followup and residual_mechanisms: development controls, failures and raw outputs underlying Section S7.
- integrated_validation_completed_20261101: frozen new questions, references, plan/prompt hashes, 20 translations, 80 raw/processed answers and original AI assessments. Historical frozen fields stating authorization or human review was pending describe their creation time, not current status.
- integrated_scope_resolved_20261101: separate FV012 sensitivity and review provenance. 44 outputs received personal author confirmation; 36 received AI review only. The review overlay does not imply independent validation.
- current_law_targeted_check_20261101 and DR8_clause_audit: source-status evidence and explicit applicability limits. RDC 55 Articles 22 and 30 are revoked; archived-task scores remain unchanged.
- source_provenance: source checksums and official-source links.
- reproducibility_code: source and evaluation code. Reproduction of retrieval requires the original local corpus/vector assets; these and credentials are excluded. Exact hosted-model outputs are not guaranteed reproducible.

Current-law corpus rebuilding and reevaluation, independent external validation and additional answer baselines remain incomplete or absent. Negative results, raw format failures and original source exposure are deliberately retained. Superseded authoring templates, pending-run instructions, draft replacement references and duplicate document/report build files are excluded; the full research history remains in the preserved local archive and repository history.
