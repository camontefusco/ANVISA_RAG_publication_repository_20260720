from pathlib import Path
import os,json,csv
os.environ['MPLCONFIGDIR']='/private/tmp/anvisa_final_results_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from scipy.stats import beta,binomtest
N=Path(__file__).resolve().parent;F=N/'figures';F.mkdir(exist_ok=True)
j=json.loads((N/'latest_verified_display_data.json').read_text());assert binomtest(4,5,.5).pvalue==j['exact_p']
for p in Path('/System/Library/Fonts/Supplemental').glob('Arial*.ttf'):font_manager.fontManager.addfont(str(p))
plt.rcParams.update({'font.family':'Arial','font.size':11,'text.color':'black','axes.labelcolor':'black','axes.edgecolor':'black','xtick.color':'black','ytick.color':'black','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,(a,b)=plt.subplots(2,1,figsize=(9.4,8.8),gridspec_kw={'height_ratios':[1.6,1]});fig.subplots_adjust(left=.23,right=.93,top=.89,bottom=.13,hspace=.56)
labels=['Overall','Answerable','Partly answerable','Unanswerable'];nums=[20,12,4,4];base=[14,10,0,4];repair=[17,11,2,4];out=[]
for idx,(name,values,marker,offset,face) in enumerate([('Baseline',base,'o',-.13,'white'),('Integrated repair',repair,'s',.13,'black')]):
 for i,(k,n) in enumerate(zip(values,nums)):
  lo=float(beta.ppf(.025,k,n-k+1)) if k else 0.;hi=float(beta.ppf(.975,k+1,n-k)) if k<n else 1.;p=k/n
  a.errorbar(p,i+offset,xerr=[[p-lo],[hi-p]],fmt=marker,markersize=6.5,mfc=face,mec='black',ecolor='black',color='black',capsize=3,lw=1,label=name if i==0 else None)
  out.append({'category':labels[i],'condition':name,'successful_pairs':k,'pairs':n,'proportion':p,'exact_95_lower':lo,'exact_95_upper':hi})
for i,(x,y,n) in enumerate(zip(base,repair,nums)):a.text(1.045,i,f'{x}/{n} | {y}/{n}',va='center',fontsize=10)
a.set(yticks=range(4),yticklabels=labels,xlim=(-.03,1.24),xticks=[0,.25,.5,.75,1],xticklabels=['0','25','50','75','100'],xlabel='Bilingual pairs meeting all task criteria (%)');a.invert_yaxis();a.grid(axis='x',alpha=.18);a.set_title('A  Completed author review',loc='left',fontweight='bold',pad=42);a.legend(loc='lower left',bbox_to_anchor=(0,1.015),ncol=2,frameon=False,fontsize=10);a.text(1.045,-.63,'Base | Repair',fontsize=9)
counts=[13,4,1,2];b.bar(range(4),counts,color=['.75','.3','.3','.75'],edgecolor='black',width=.58);b.set(xticks=range(4),xticklabels=['Passed both','Improved','Worsened','Failed both'],ylim=(0,16),yticks=[0,4,8,12,16],ylabel='Bilingual pairs');b.set_title('B  Paired outcomes on the same 20 pairs',loc='left',fontweight='bold',pad=14)
for i,k in enumerate(counts):b.text(i,k+.35,str(k),ha='center')
fig.text(.5,.055,'Paired difference +15.0 percentage points (95% interval -5.0 to +35.0); exact p = 0.375',ha='center',fontsize=10)
fig.text(.5,.025,'Exploratory archived-corpus comparison; improvement remains unproven.',ha='center',fontsize=10)
for ext in ['pdf','png','tif']:
 fig.savefig(F/('Figure_4_completed_author_comparison.'+ext),dpi=400,bbox_inches='tight',**({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tif' else {}))
plt.close(fig)
with (N/'Figure_4_source_values.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print('Verified and plotted eight author-reviewed category proportions, exact intervals and paired transitions.')
